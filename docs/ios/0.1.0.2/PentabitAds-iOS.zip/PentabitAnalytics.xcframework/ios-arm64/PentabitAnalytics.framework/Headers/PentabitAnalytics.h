#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class PentabitAnalyticsAdError, PentabitAnalyticsAdErrorCode, PentabitAnalyticsAdFormat, PentabitAnalyticsAdFormatCompanion, PentabitAnalyticsAdRequest, PentabitAnalyticsAdRequestCompanion, PentabitAnalyticsAdResponse, PentabitAnalyticsAdResponseCompanion, PentabitAnalyticsAdResultFailure, PentabitAnalyticsAdResultSuccess<__covariant T>, PentabitAnalyticsAdSessionCompanion, PentabitAnalyticsAdSource, PentabitAnalyticsAdSourceCompanion, PentabitAnalyticsAdStage, PentabitAnalyticsAnalyticsOptions, PentabitAnalyticsApiClient, PentabitAnalyticsAppInfo, PentabitAnalyticsAppInfoCompanion, PentabitAnalyticsAudienceProfile, PentabitAnalyticsCachedAsset, PentabitAnalyticsCircuitBreaker, PentabitAnalyticsConfigParser, PentabitAnalyticsConfigRepository, PentabitAnalyticsConsentPolicy, PentabitAnalyticsConsentSignals, PentabitAnalyticsCoreOptions, PentabitAnalyticsCreative, PentabitAnalyticsCreativeAsset, PentabitAnalyticsCreativeAssetCompanion, PentabitAnalyticsCreativeCompanion, PentabitAnalyticsCreativeHtml, PentabitAnalyticsCreativeType, PentabitAnalyticsCreativeTypeCompanion, PentabitAnalyticsDeepLink, PentabitAnalyticsDeepLinkResolver, PentabitAnalyticsDeviceContext, PentabitAnalyticsDeviceContextCompanion, PentabitAnalyticsEvent, PentabitAnalyticsEventConfig, PentabitAnalyticsEventConfigCompanion, PentabitAnalyticsEventContext, PentabitAnalyticsEventContextCompanion, PentabitAnalyticsEventFlusher, PentabitAnalyticsEventNames, PentabitAnalyticsEventTracker, PentabitAnalyticsEventUploader, PentabitAnalyticsFakeAssetStore, PentabitAnalyticsFakeClock, PentabitAnalyticsFakeConnectivity, PentabitAnalyticsFakeDeviceInfo, PentabitAnalyticsFakeHttp, PentabitAnalyticsFlushOutcome, PentabitAnalyticsHttpRequest, PentabitAnalyticsHttpResponse, PentabitAnalyticsInMemoryEventStore, PentabitAnalyticsInMemoryKeyValueStore, PentabitAnalyticsKotlinAbstractCoroutineContextElement, PentabitAnalyticsKotlinAbstractCoroutineContextKey<B, E>, PentabitAnalyticsKotlinArray<T>, PentabitAnalyticsKotlinByteArray, PentabitAnalyticsKotlinByteIterator, PentabitAnalyticsKotlinEnum<E>, PentabitAnalyticsKotlinEnumCompanion, PentabitAnalyticsKotlinException, PentabitAnalyticsKotlinIllegalStateException, PentabitAnalyticsKotlinNothing, PentabitAnalyticsKotlinRuntimeException, PentabitAnalyticsKotlinThrowable, PentabitAnalyticsKotlinUnit, PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcher, PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcherKey, PentabitAnalyticsKotlinx_serialization_coreSerialKind, PentabitAnalyticsKotlinx_serialization_coreSerializersModule, PentabitAnalyticsKotlinx_serialization_jsonClassDiscriminatorMode, PentabitAnalyticsKotlinx_serialization_jsonJson, PentabitAnalyticsKotlinx_serialization_jsonJsonConfiguration, PentabitAnalyticsKotlinx_serialization_jsonJsonDefault, PentabitAnalyticsKotlinx_serialization_jsonJsonElement, PentabitAnalyticsKotlinx_serialization_jsonJsonElementCompanion, PentabitAnalyticsKv, PentabitAnalyticsLoadedAd, PentabitAnalyticsMediaSelector, PentabitAnalyticsMraidControllerCompanion, PentabitAnalyticsMraidMessageClose, PentabitAnalyticsMraidMessageOpen, PentabitAnalyticsMraidMessageOrientation, PentabitAnalyticsMraidMessagePlayableComplete, PentabitAnalyticsMraidMessagePlayableCta, PentabitAnalyticsMraidMessagePlayableError, PentabitAnalyticsMraidMessagePlayableReady, PentabitAnalyticsMraidMessageUnload, PentabitAnalyticsMraidPlacement, PentabitAnalyticsMraidScript, PentabitAnalyticsMraidState, PentabitAnalyticsNativeAssets, PentabitAnalyticsNativeAssetsCompanion, PentabitAnalyticsNetworkExceptionKind, PentabitAnalyticsNoopLogger, PentabitAnalyticsPentabitAnalytics, PentabitAnalyticsPentabitDatabaseCompanion, PentabitAnalyticsPentabitEndpoints, PentabitAnalyticsPentabitEvent, PentabitAnalyticsPentabitEventCompanion, PentabitAnalyticsPentabitQueries, PentabitAnalyticsPentabitVersion, PentabitAnalyticsPixelClient, PentabitAnalyticsPlacementConfig, PentabitAnalyticsPlacementConfigCompanion, PentabitAnalyticsPlatformContext, PentabitAnalyticsPrivacyContext, PentabitAnalyticsPrivacyContextCompanion, PentabitAnalyticsPrivacyMode, PentabitAnalyticsPrivacyState, PentabitAnalyticsResolvedVast, PentabitAnalyticsRetryPolicy, PentabitAnalyticsRewardSpec, PentabitAnalyticsRewardSpecCompanion, PentabitAnalyticsRuntimeAfterVersion, PentabitAnalyticsRuntimeBaseTransacterImpl, PentabitAnalyticsRuntimeExecutableQuery<__covariant RowType>, PentabitAnalyticsRuntimeQuery<__covariant RowType>, PentabitAnalyticsRuntimeTransacterImpl, PentabitAnalyticsRuntimeTransacterTransaction, PentabitAnalyticsSdkConfig, PentabitAnalyticsSdkConfigCompanion, PentabitAnalyticsSdkDefaults, PentabitAnalyticsSdkInfo, PentabitAnalyticsSdkInfoCompanion, PentabitAnalyticsSdkScope, PentabitAnalyticsSimidHost, PentabitAnalyticsSimidSessionCompanion, PentabitAnalyticsSimidSessionCreativeData, PentabitAnalyticsSimidSessionEnvironment, PentabitAnalyticsSimidSessionMediaState, PentabitAnalyticsStoredEvent, PentabitAnalyticsSystemIds, PentabitAnalyticsTriState, PentabitAnalyticsUrlPolicy, PentabitAnalyticsVastAd, PentabitAnalyticsVastCompanion, PentabitAnalyticsVastEvents, PentabitAnalyticsVastInteractive, PentabitAnalyticsVastLinear, PentabitAnalyticsVastMedia, PentabitAnalyticsVastParser, PentabitAnalyticsVastParserCompanion, PentabitAnalyticsVastResolver, PentabitAnalyticsVastTracking;

@protocol PentabitAnalyticsAdResult, PentabitAnalyticsAssetStore, PentabitAnalyticsClock, PentabitAnalyticsConnectivityMonitor, PentabitAnalyticsDeviceInfo, PentabitAnalyticsDispatcherProvider, PentabitAnalyticsEventStore, PentabitAnalyticsHttpClientPort, PentabitAnalyticsIdGenerator, PentabitAnalyticsKeyValueStore, PentabitAnalyticsKotlinAnnotation, PentabitAnalyticsKotlinComparable, PentabitAnalyticsKotlinContinuation, PentabitAnalyticsKotlinContinuationInterceptor, PentabitAnalyticsKotlinCoroutineContext, PentabitAnalyticsKotlinCoroutineContextElement, PentabitAnalyticsKotlinCoroutineContextKey, PentabitAnalyticsKotlinFunction, PentabitAnalyticsKotlinIterator, PentabitAnalyticsKotlinKAnnotatedElement, PentabitAnalyticsKotlinKClass, PentabitAnalyticsKotlinKClassifier, PentabitAnalyticsKotlinKDeclarationContainer, PentabitAnalyticsKotlinSuspendFunction0, PentabitAnalyticsKotlinSuspendFunction1, PentabitAnalyticsKotlinx_coroutines_coreCoroutineScope, PentabitAnalyticsKotlinx_coroutines_coreFlow, PentabitAnalyticsKotlinx_coroutines_coreFlowCollector, PentabitAnalyticsKotlinx_coroutines_coreRunnable, PentabitAnalyticsKotlinx_coroutines_coreSharedFlow, PentabitAnalyticsKotlinx_coroutines_coreStateFlow, PentabitAnalyticsKotlinx_serialization_coreCompositeDecoder, PentabitAnalyticsKotlinx_serialization_coreCompositeEncoder, PentabitAnalyticsKotlinx_serialization_coreDecoder, PentabitAnalyticsKotlinx_serialization_coreDeserializationStrategy, PentabitAnalyticsKotlinx_serialization_coreEncoder, PentabitAnalyticsKotlinx_serialization_coreKSerializer, PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor, PentabitAnalyticsKotlinx_serialization_coreSerialFormat, PentabitAnalyticsKotlinx_serialization_coreSerializationStrategy, PentabitAnalyticsKotlinx_serialization_coreSerializersModuleCollector, PentabitAnalyticsKotlinx_serialization_coreStringFormat, PentabitAnalyticsKotlinx_serialization_jsonJsonNamingStrategy, PentabitAnalyticsLogger, PentabitAnalyticsMraidListener, PentabitAnalyticsMraidMessage, PentabitAnalyticsPentabitDatabase, PentabitAnalyticsPlatformModule, PentabitAnalyticsRuntimeCloseable, PentabitAnalyticsRuntimeQueryListener, PentabitAnalyticsRuntimeQueryResult, PentabitAnalyticsRuntimeSqlCursor, PentabitAnalyticsRuntimeSqlDriver, PentabitAnalyticsRuntimeSqlPreparedStatement, PentabitAnalyticsRuntimeSqlSchema, PentabitAnalyticsRuntimeTransacter, PentabitAnalyticsRuntimeTransacterBase, PentabitAnalyticsRuntimeTransactionCallbacks, PentabitAnalyticsRuntimeTransactionWithReturn, PentabitAnalyticsRuntimeTransactionWithoutReturn, PentabitAnalyticsSimidSessionListener;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface PentabitAnalyticsBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface PentabitAnalyticsBase (PentabitAnalyticsBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface PentabitAnalyticsMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface PentabitAnalyticsMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorPentabitAnalyticsKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface PentabitAnalyticsNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface PentabitAnalyticsByte : PentabitAnalyticsNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface PentabitAnalyticsUByte : PentabitAnalyticsNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface PentabitAnalyticsShort : PentabitAnalyticsNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface PentabitAnalyticsUShort : PentabitAnalyticsNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface PentabitAnalyticsInt : PentabitAnalyticsNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface PentabitAnalyticsUInt : PentabitAnalyticsNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface PentabitAnalyticsLong : PentabitAnalyticsNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface PentabitAnalyticsULong : PentabitAnalyticsNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface PentabitAnalyticsFloat : PentabitAnalyticsNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface PentabitAnalyticsDouble : PentabitAnalyticsNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface PentabitAnalyticsBoolean : PentabitAnalyticsNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AnalyticsOptions")))
@interface PentabitAnalyticsAnalyticsOptions : PentabitAnalyticsBase
- (instancetype)initWithAppKey:(NSString *)appKey audience:(PentabitAnalyticsAudienceProfile *)audience debug:(BOOL)debug __attribute__((swift_name("init(appKey:audience:debug:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsAnalyticsOptions *)doCopyAppKey:(NSString *)appKey audience:(PentabitAnalyticsAudienceProfile *)audience debug:(BOOL)debug __attribute__((swift_name("doCopy(appKey:audience:debug:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *appKey __attribute__((swift_name("appKey")));

/** Declare the audience once. CHILD_DIRECTED stops all action tracking. */
@property (readonly) PentabitAnalyticsAudienceProfile *audience __attribute__((swift_name("audience")));

/**
 * Debug builds. Actions are flagged as test traffic (the backend must not attribute or bill them) and
 * logging is turned on. Pass `BuildConfig.DEBUG` on Android. Must be false in release builds.
 */
@property (readonly) BOOL debug __attribute__((swift_name("debug")));
@end


/** A link that opened the app from a Pentabit-served ad. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeepLink")))
@interface PentabitAnalyticsDeepLink : PentabitAnalyticsBase
- (instancetype)initWithUrl:(NSString *)url path:(NSString *)path campaign:(NSString * _Nullable)campaign clickId:(NSString * _Nullable)clickId params:(NSDictionary<NSString *, NSString *> *)params __attribute__((swift_name("init(url:path:campaign:clickId:params:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsDeepLink *)doCopyUrl:(NSString *)url path:(NSString *)path campaign:(NSString * _Nullable)campaign clickId:(NSString * _Nullable)clickId params:(NSDictionary<NSString *, NSString *> *)params __attribute__((swift_name("doCopy(url:path:campaign:clickId:params:)")));

/** A link that opened the app from a Pentabit-served ad. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** A link that opened the app from a Pentabit-served ad. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** A link that opened the app from a Pentabit-served ad. */
- (NSString *)description __attribute__((swift_name("description()")));

/** Campaign identifier added by the Pentabit backend (`aks_campaign`). */
@property (readonly) NSString * _Nullable campaign __attribute__((swift_name("campaign")));

/** Click identifier added by the Pentabit backend (`aks_cid`). */
@property (readonly) NSString * _Nullable clickId __attribute__((swift_name("clickId")));

/** All other query parameters. */
@property (readonly) NSDictionary<NSString *, NSString *> *params __attribute__((swift_name("params")));
@property (readonly) NSString *path __attribute__((swift_name("path")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end


/** Reads a deep link without any platform code. Anything that is not a valid link gives null. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeepLinkResolver")))
@interface PentabitAnalyticsDeepLinkResolver : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));

/** Reads a deep link without any platform code. Anything that is not a valid link gives null. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)deepLinkResolver __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsDeepLinkResolver *shared __attribute__((swift_name("shared")));
- (PentabitAnalyticsDeepLink * _Nullable)parseUrl:(NSString *)url __attribute__((swift_name("parse(url:)")));
@end


/**
 * Pentabit Analytics: the small SDK for apps that are advertised. It reports the actions advertisers pay for
 * (installs, sign-ups, purchases and so on). Call [initialize] once at app start; every other call
 * returns at once and never throws.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PentabitAnalytics")))
@interface PentabitAnalyticsPentabitAnalytics : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Pentabit Analytics: the small SDK for apps that are advertised. It reports the actions advertisers pay for
 * (installs, sign-ups, purchases and so on). Call [initialize] once at app start; every other call
 * returns at once and never throws.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)pentabitAnalytics __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsPentabitAnalytics *shared __attribute__((swift_name("shared")));

/**
 * Call with the URL that opened the app. If it carries Pentabit campaign data, a deep_link_open event
 * is reported. Returns the parsed link, or null if it is not a usable link.
 */
- (PentabitAnalyticsDeepLink * _Nullable)handleDeepLinkUrl:(NSString *)url __attribute__((swift_name("handleDeepLink(url:)")));
- (void)initializeContext:(PentabitAnalyticsPlatformContext *)context options:(PentabitAnalyticsAnalyticsOptions *)options __attribute__((swift_name("initialize(context:options:)")));

/** Pass the user's consent and age signals. Call again whenever they change. */
- (void)setConsentSignals:(PentabitAnalyticsConsentSignals *)signals __attribute__((swift_name("setConsent(signals:)")));
- (void)shutdown __attribute__((swift_name("shutdown()")));

/**
 * Reports a custom action. [name] is lower-case letters, digits and underscores (max 40).
 * Returns false if the SDK is not started or the arguments are invalid.
 */
- (BOOL)trackName:(NSString *)name params:(NSDictionary<NSString *, NSString *> *)params value:(PentabitAnalyticsDouble * _Nullable)value currency:(NSString * _Nullable)currency __attribute__((swift_name("track(name:params:value:currency:)")));
- (BOOL)trackFeatureUsedFeature:(NSString *)feature __attribute__((swift_name("trackFeatureUsed(feature:)")));
- (BOOL)trackLevelReachedLevel:(int32_t)level __attribute__((swift_name("trackLevelReached(level:)")));
- (BOOL)trackPurchaseRevenue:(double)revenue currency:(NSString *)currency productId:(NSString * _Nullable)productId __attribute__((swift_name("trackPurchase(revenue:currency:productId:)")));
- (BOOL)trackRegistrationMethod:(NSString * _Nullable)method __attribute__((swift_name("trackRegistration(method:)")));
- (BOOL)trackSubscribeRevenue:(double)revenue currency:(NSString *)currency productId:(NSString * _Nullable)productId __attribute__((swift_name("trackSubscribe(revenue:currency:productId:)")));
- (BOOL)trackTutorialComplete __attribute__((swift_name("trackTutorialComplete()")));
@property (readonly) BOOL isInitialized __attribute__((swift_name("isInitialized")));
@end


/**
 * The composition root for everything both SDKs share. Nothing outside this class (and the
 * module graphs built on it) constructs a platform or network class.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CoreGraph")))
@interface PentabitAnalyticsCoreGraph : PentabitAnalyticsBase
- (instancetype)initWithPlatform:(id<PentabitAnalyticsPlatformModule>)platform options:(PentabitAnalyticsCoreOptions *)options onUploadReply:(id<PentabitAnalyticsKotlinSuspendFunction1> _Nullable)onUploadReply __attribute__((swift_name("init(platform:options:onUploadReply:)"))) __attribute__((objc_designated_initializer));
- (void)shutdown __attribute__((swift_name("shutdown()")));

/** Loads the cached config, refreshes it in the background and starts the event timer. Returns at once. */
- (void)start __attribute__((swift_name("start()")));
@property (readonly) PentabitAnalyticsApiClient *api __attribute__((swift_name("api")));
@property (readonly) PentabitAnalyticsConfigRepository *config __attribute__((swift_name("config")));
@property (readonly) PentabitAnalyticsEventTracker *events __attribute__((swift_name("events")));
@property (readonly) PentabitAnalyticsEventFlusher *flusher __attribute__((swift_name("flusher")));
@property (readonly) PentabitAnalyticsCoreOptions *options __attribute__((swift_name("options")));
@property (readonly) PentabitAnalyticsPixelClient *pixels __attribute__((swift_name("pixels")));
@property (readonly) id<PentabitAnalyticsPlatformModule> platform __attribute__((swift_name("platform")));
@property (readonly) PentabitAnalyticsPrivacyState *privacy __attribute__((swift_name("privacy")));
@property (readonly) PentabitAnalyticsSdkInfo *sdkInfo __attribute__((swift_name("sdkInfo")));
@property (readonly) PentabitAnalyticsSdkScope *sdkScope __attribute__((swift_name("sdkScope")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CoreOptions")))
@interface PentabitAnalyticsCoreOptions : PentabitAnalyticsBase
- (instancetype)initWithAppKey:(NSString *)appKey baseUrl:(NSString *)baseUrl audience:(PentabitAnalyticsAudienceProfile *)audience sdkName:(NSString *)sdkName sdkVersion:(NSString *)sdkVersion debug:(BOOL)debug eventsPath:(NSString *)eventsPath reportUrl:(NSString *)reportUrl __attribute__((swift_name("init(appKey:baseUrl:audience:sdkName:sdkVersion:debug:eventsPath:reportUrl:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsCoreOptions *)doCopyAppKey:(NSString *)appKey baseUrl:(NSString *)baseUrl audience:(PentabitAnalyticsAudienceProfile *)audience sdkName:(NSString *)sdkName sdkVersion:(NSString *)sdkVersion debug:(BOOL)debug eventsPath:(NSString *)eventsPath reportUrl:(NSString *)reportUrl __attribute__((swift_name("doCopy(appKey:baseUrl:audience:sdkName:sdkVersion:debug:eventsPath:reportUrl:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *appKey __attribute__((swift_name("appKey")));
@property (readonly) PentabitAnalyticsAudienceProfile *audience __attribute__((swift_name("audience")));
@property (readonly) NSString *baseUrl __attribute__((swift_name("baseUrl")));
@property (readonly) BOOL debug __attribute__((swift_name("debug")));

/** Where queued events are posted. */
@property (readonly) NSString *eventsPath __attribute__((swift_name("eventsPath")));

/** Where events and actions are sent. Defaults to [baseUrl] (one backend). */
@property (readonly) NSString *reportUrl __attribute__((swift_name("reportUrl")));
@property (readonly) NSString *sdkName __attribute__((swift_name("sdkName")));
@property (readonly) NSString *sdkVersion __attribute__((swift_name("sdkVersion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PentabitEndpoints")))
@interface PentabitAnalyticsPentabitEndpoints : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)pentabitEndpoints __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsPentabitEndpoints *shared __attribute__((swift_name("shared")));

/** Ads backend: app config and ad requests. */
@property (readonly) NSString *BASE_URL __attribute__((swift_name("BASE_URL")));

/** Reporting backend: ad events (impressions, clicks) and in-app actions (installs, purchases). */
@property (readonly) NSString *REPORT_URL __attribute__((swift_name("REPORT_URL")));
@end


/** Keep in step with `pentabit.version` in gradle.properties. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PentabitVersion")))
@interface PentabitAnalyticsPentabitVersion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));

/** Keep in step with `pentabit.version` in gradle.properties. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)pentabitVersion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsPentabitVersion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *VERSION __attribute__((swift_name("VERSION")));
@end


/**
 * Fixed SDK limits. The SDK makes no decisions: what to show, for how long, whether a reward is
 * granted and what a conversion is worth all come from the server, per ad or per reply.
 * These numbers only protect the device (timeouts, sizes, batching).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkDefaults")))
@interface PentabitAnalyticsSdkDefaults : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Fixed SDK limits. The SDK makes no decisions: what to show, for how long, whether a reward is
 * granted and what a conversion is worth all come from the server, per ad or per reply.
 * These numbers only protect the device (timeouts, sizes, batching).
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sdkDefaults __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsSdkDefaults *shared __attribute__((swift_name("shared")));
@property (readonly) int32_t EVENT_BATCH_SIZE __attribute__((swift_name("EVENT_BATCH_SIZE")));
@property (readonly) int32_t EVENT_FLUSH_SECONDS __attribute__((swift_name("EVENT_FLUSH_SECONDS")));
@property (readonly) int32_t EVENT_MAX_AGE_HOURS __attribute__((swift_name("EVENT_MAX_AGE_HOURS")));
@property (readonly) int32_t EVENT_QUEUE_MAX __attribute__((swift_name("EVENT_QUEUE_MAX")));
@property (readonly) int64_t MAX_ASSET_BYTES __attribute__((swift_name("MAX_ASSET_BYTES")));
@property (readonly) int32_t MAX_CLOSE_DELAY_SECONDS __attribute__((swift_name("MAX_CLOSE_DELAY_SECONDS")));
@property (readonly) int32_t MAX_TTL_SECONDS __attribute__((swift_name("MAX_TTL_SECONDS")));
@property (readonly) int32_t MIN_TTL_SECONDS __attribute__((swift_name("MIN_TTL_SECONDS")));
@property (readonly) int64_t REQUEST_TIMEOUT_MS __attribute__((swift_name("REQUEST_TIMEOUT_MS")));
@property (readonly) int32_t VAST_MAX_BITRATE_KBPS __attribute__((swift_name("VAST_MAX_BITRATE_KBPS")));
@property (readonly) int32_t VAST_MAX_WRAPPER_DEPTH __attribute__((swift_name("VAST_MAX_WRAPPER_DEPTH")));
@property (readonly) int64_t VAST_TIMEOUT_MS __attribute__((swift_name("VAST_TIMEOUT_MS")));
@property (readonly) int32_t VIEWABLE_AREA_PERCENT __attribute__((swift_name("VIEWABLE_AREA_PERCENT")));
@property (readonly) int64_t VIEWABLE_MS __attribute__((swift_name("VIEWABLE_MS")));
@property (readonly) int64_t VIEWABLE_VIDEO_MS __attribute__((swift_name("VIEWABLE_VIDEO_MS")));
@end


/**
 * Turns a placement ID into a loaded ad: checks config and consent, asks the backend, resolves
 * VAST if needed and downloads assets. Runs entirely off the main thread (the caller picks the
 * dispatcher; network and disk hops switch to io inside the ports).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdLoader")))
@interface PentabitAnalyticsAdLoader : PentabitAnalyticsBase
- (instancetype)initWithConfig:(PentabitAnalyticsConfigRepository *)config privacy:(PentabitAnalyticsPrivacyState *)privacy deviceInfo:(id<PentabitAnalyticsDeviceInfo>)deviceInfo api:(PentabitAnalyticsApiClient *)api assets:(id<PentabitAnalyticsAssetStore>)assets vastFactory:(PentabitAnalyticsVastResolver *(^)(PentabitAnalyticsInt *, PentabitAnalyticsLong *, PentabitAnalyticsInt *))vastFactory clock:(id<PentabitAnalyticsClock>)clock ids:(id<PentabitAnalyticsIdGenerator>)ids events:(PentabitAnalyticsEventTracker *)events sdk:(PentabitAnalyticsSdkInfo *)sdk testMode:(BOOL)testMode __attribute__((swift_name("init(config:privacy:deviceInfo:api:assets:vastFactory:clock:ids:events:sdk:testMode:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)loadPlacementId:(NSString *)placementId format:(PentabitAnalyticsAdFormat *)format bannerSize:(NSString * _Nullable)bannerSize completionHandler:(void (^)(id<PentabitAnalyticsAdResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("load(placementId:format:bannerSize:completionHandler:)")));
@end


/**
 * One ad, driven by an explicit state machine. A move is only allowed from certain states, which
 * prevents double shows, shows after expiry and leaks.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdSession")))
@interface PentabitAnalyticsAdSession : PentabitAnalyticsBase
- (instancetype)initWithId:(NSString *)id __attribute__((swift_name("init(id:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsAdSessionCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isExpiredNowMillis:(int64_t)nowMillis __attribute__((swift_name("isExpired(nowMillis:)")));
- (BOOL)markFailedError:(PentabitAnalyticsAdError *)error __attribute__((swift_name("markFailed(error:)")));
- (BOOL)markLoadedAd:(PentabitAnalyticsLoadedAd *)ad __attribute__((swift_name("markLoaded(ad:)")));

/** Returns false (and changes nothing) when the move is not allowed. */
- (BOOL)transitionTo:(PentabitAnalyticsAdStage *)to __attribute__((swift_name("transition(to:)")));
@property (readonly) PentabitAnalyticsAdError * _Nullable error __attribute__((swift_name("error")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) PentabitAnalyticsLoadedAd * _Nullable loaded __attribute__((swift_name("loaded")));
@property (readonly) id<PentabitAnalyticsKotlinx_coroutines_coreStateFlow> stage __attribute__((swift_name("stage")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdSession.Companion")))
@interface PentabitAnalyticsAdSessionCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsAdSessionCompanion *shared __attribute__((swift_name("shared")));
- (NSSet<PentabitAnalyticsAdStage *> *)allowedFromFrom:(PentabitAnalyticsAdStage *)from __attribute__((swift_name("allowedFrom(from:)")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol PentabitAnalyticsKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface PentabitAnalyticsKotlinEnum<E> : PentabitAnalyticsBase <PentabitAnalyticsKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdStage")))
@interface PentabitAnalyticsAdStage : PentabitAnalyticsKotlinEnum<PentabitAnalyticsAdStage *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAnalyticsAdStage *idle __attribute__((swift_name("idle")));
@property (class, readonly) PentabitAnalyticsAdStage *loading __attribute__((swift_name("loading")));
@property (class, readonly) PentabitAnalyticsAdStage *ready __attribute__((swift_name("ready")));
@property (class, readonly) PentabitAnalyticsAdStage *showing __attribute__((swift_name("showing")));
@property (class, readonly) PentabitAnalyticsAdStage *completed __attribute__((swift_name("completed")));
@property (class, readonly) PentabitAnalyticsAdStage *expired __attribute__((swift_name("expired")));
@property (class, readonly) PentabitAnalyticsAdStage *failed __attribute__((swift_name("failed")));
@property (class, readonly) PentabitAnalyticsAdStage *destroyed __attribute__((swift_name("destroyed")));
+ (PentabitAnalyticsKotlinArray<PentabitAnalyticsAdStage *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAnalyticsAdStage *> *entries __attribute__((swift_name("entries")));
@end


/** Everything needed to show an ad that has finished loading. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoadedAd")))
@interface PentabitAnalyticsLoadedAd : PentabitAnalyticsBase
- (instancetype)initWithSessionId:(NSString *)sessionId placementId:(NSString *)placementId format:(PentabitAnalyticsAdFormat *)format response:(PentabitAnalyticsAdResponse *)response assets:(NSDictionary<NSString *, PentabitAnalyticsCachedAsset *> *)assets vast:(PentabitAnalyticsResolvedVast * _Nullable)vast videoAsset:(PentabitAnalyticsCachedAsset * _Nullable)videoAsset endCardMarkup:(NSString * _Nullable)endCardMarkup loadedAtMillis:(int64_t)loadedAtMillis expiresAtMillis:(int64_t)expiresAtMillis privacyMode:(PentabitAnalyticsPrivacyMode *)privacyMode __attribute__((swift_name("init(sessionId:placementId:format:response:assets:vast:videoAsset:endCardMarkup:loadedAtMillis:expiresAtMillis:privacyMode:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSDictionary<NSString *, PentabitAnalyticsCachedAsset *> *assets __attribute__((swift_name("assets")));
@property (readonly) NSString * _Nullable endCardMarkup __attribute__((swift_name("endCardMarkup")));
@property (readonly) int64_t expiresAtMillis __attribute__((swift_name("expiresAtMillis")));
@property (readonly) PentabitAnalyticsAdFormat *format __attribute__((swift_name("format")));
@property (readonly) int64_t loadedAtMillis __attribute__((swift_name("loadedAtMillis")));
@property (readonly) NSString *placementId __attribute__((swift_name("placementId")));
@property (readonly) PentabitAnalyticsPrivacyMode *privacyMode __attribute__((swift_name("privacyMode")));
@property (readonly) NSString *requestId __attribute__((swift_name("requestId")));
@property (readonly) PentabitAnalyticsAdResponse *response __attribute__((swift_name("response")));
@property (readonly) NSString *sessionId __attribute__((swift_name("sessionId")));
@property (readonly) PentabitAnalyticsResolvedVast * _Nullable vast __attribute__((swift_name("vast")));
@property (readonly) PentabitAnalyticsCachedAsset * _Nullable videoAsset __attribute__((swift_name("videoAsset")));
@end


/** All dispatchers come from here so tests can replace them with one test dispatcher. */
__attribute__((swift_name("DispatcherProvider")))
@protocol PentabitAnalyticsDispatcherProvider
@required
@property (readonly, getter=default) PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcher *default_ __attribute__((swift_name("default_")));
@property (readonly) PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcher *io __attribute__((swift_name("io")));
@property (readonly) PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcher *main __attribute__((swift_name("main")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultDispatcherProvider")))
@interface PentabitAnalyticsDefaultDispatcherProvider : PentabitAnalyticsBase <PentabitAnalyticsDispatcherProvider>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (readonly, getter=default) PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcher *default_ __attribute__((swift_name("default_")));
@property (readonly) PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcher *io __attribute__((swift_name("io")));
@property (readonly) PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcher *main __attribute__((swift_name("main")));
@end


/** One scope for the whole SDK. A failing child never cancels its siblings. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkScope")))
@interface PentabitAnalyticsSdkScope : PentabitAnalyticsBase
- (instancetype)initWithDispatchers:(id<PentabitAnalyticsDispatcherProvider>)dispatchers onUncaught:(void (^)(PentabitAnalyticsKotlinThrowable *))onUncaught __attribute__((swift_name("init(dispatchers:onUncaught:)"))) __attribute__((objc_designated_initializer));

/** A scope for one ad. Cancelling it never affects the SDK scope. */
- (id<PentabitAnalyticsKotlinx_coroutines_coreCoroutineScope>)child __attribute__((swift_name("child()")));
- (void)shutdown __attribute__((swift_name("shutdown()")));
@property (readonly) id<PentabitAnalyticsKotlinx_coroutines_coreCoroutineScope> scope __attribute__((swift_name("scope")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConfigParser")))
@interface PentabitAnalyticsConfigParser : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)configParser __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsConfigParser *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsAdResult>)parseText:(NSString *)text __attribute__((swift_name("parse(text:)")));
- (id<PentabitAnalyticsAdResult>)validateConfig:(PentabitAnalyticsSdkConfig *)config __attribute__((swift_name("validate(config:)")));
@end


/**
 * Holds the current config. The last good config is kept on disk, so the SDK works offline.
 * An invalid config is rejected and the previous one stays.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConfigRepository")))
@interface PentabitAnalyticsConfigRepository : PentabitAnalyticsBase
- (instancetype)initWithApi:(PentabitAnalyticsApiClient *)api store:(id<PentabitAnalyticsKeyValueStore>)store clock:(id<PentabitAnalyticsClock>)clock logger:(id<PentabitAnalyticsLogger>)logger __attribute__((swift_name("init(api:store:clock:logger:)"))) __attribute__((objc_designated_initializer));
- (id<PentabitAnalyticsAdResult>)findPlacementId:(NSString *)id __attribute__((swift_name("findPlacement(id:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)loadCachedWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("loadCached(completionHandler:)")));

/** Called on HTTP 401/403 from any ad or config call: forget the config so nothing can load.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)markUnauthorizedWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("markUnauthorized(completionHandler:)")));

/** Fetches a new config unless one was fetched recently.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)refreshForce:(BOOL)force completionHandler:(void (^)(id<PentabitAnalyticsAdResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("refresh(force:completionHandler:)")));
@property (readonly) id<PentabitAnalyticsKotlinx_coroutines_coreStateFlow> current __attribute__((swift_name("current")));

/** True while the backend rejects this app key for this app. No ads are shown and no actions are sent. */
@property (readonly) id<PentabitAnalyticsKotlinx_coroutines_coreStateFlow> unauthorized __attribute__((swift_name("unauthorized")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventConfig")))
@interface PentabitAnalyticsEventConfig : PentabitAnalyticsBase
- (instancetype)initWithBatchSize:(int32_t)batchSize flushIntervalSeconds:(int32_t)flushIntervalSeconds __attribute__((swift_name("init(batchSize:flushIntervalSeconds:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsEventConfigCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAnalyticsEventConfig *)doCopyBatchSize:(int32_t)batchSize flushIntervalSeconds:(int32_t)flushIntervalSeconds __attribute__((swift_name("doCopy(batchSize:flushIntervalSeconds:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t batchSize __attribute__((swift_name("batchSize")));
@property (readonly) int32_t flushIntervalSeconds __attribute__((swift_name("flushIntervalSeconds")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventConfig.Companion")))
@interface PentabitAnalyticsEventConfigCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsEventConfigCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/** One ad slot the app may use. Everything else about an ad comes with the ad itself.
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlacementConfig")))
@interface PentabitAnalyticsPlacementConfig : PentabitAnalyticsBase
- (instancetype)initWithId:(NSString *)id format:(PentabitAnalyticsAdFormat *)format enabled:(BOOL)enabled __attribute__((swift_name("init(id:format:enabled:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsPlacementConfigCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAnalyticsPlacementConfig *)doCopyId:(NSString *)id format:(PentabitAnalyticsAdFormat *)format enabled:(BOOL)enabled __attribute__((swift_name("doCopy(id:format:enabled:)")));

/** One ad slot the app may use. Everything else about an ad comes with the ad itself. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** One ad slot the app may use. Everything else about an ad comes with the ad itself. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** One ad slot the app may use. Everything else about an ad comes with the ad itself. */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL enabled __attribute__((swift_name("enabled")));
@property (readonly) PentabitAnalyticsAdFormat *format __attribute__((swift_name("format")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@end


/** One ad slot the app may use. Everything else about an ad comes with the ad itself. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlacementConfig.Companion")))
@interface PentabitAnalyticsPlacementConfigCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));

/** One ad slot the app may use. Everything else about an ad comes with the ad itself. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsPlacementConfigCompanion *shared __attribute__((swift_name("shared")));

/** One ad slot the app may use. Everything else about an ad comes with the ad itself. */
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/** The slim config: what the SDK must know before it asks for an ad.
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkConfig")))
@interface PentabitAnalyticsSdkConfig : PentabitAnalyticsBase
- (instancetype)initWithVersion:(int64_t)version killSwitch:(BOOL)killSwitch refreshIntervalSeconds:(int32_t)refreshIntervalSeconds placements:(NSArray<PentabitAnalyticsPlacementConfig *> *)placements events:(PentabitAnalyticsEventConfig *)events __attribute__((swift_name("init(version:killSwitch:refreshIntervalSeconds:placements:events:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsSdkConfigCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAnalyticsSdkConfig *)doCopyVersion:(int64_t)version killSwitch:(BOOL)killSwitch refreshIntervalSeconds:(int32_t)refreshIntervalSeconds placements:(NSArray<PentabitAnalyticsPlacementConfig *> *)placements events:(PentabitAnalyticsEventConfig *)events __attribute__((swift_name("doCopy(version:killSwitch:refreshIntervalSeconds:placements:events:)")));

/** The slim config: what the SDK must know before it asks for an ad. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** The slim config: what the SDK must know before it asks for an ad. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** The slim config: what the SDK must know before it asks for an ad. */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PentabitAnalyticsEventConfig *events __attribute__((swift_name("events")));
@property (readonly) BOOL killSwitch __attribute__((swift_name("killSwitch")));
@property (readonly) NSArray<PentabitAnalyticsPlacementConfig *> *placements __attribute__((swift_name("placements")));
@property (readonly) int32_t refreshIntervalSeconds __attribute__((swift_name("refreshIntervalSeconds")));
@property (readonly) int64_t version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkConfig.Companion")))
@interface PentabitAnalyticsSdkConfigCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsSdkConfigCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));

/** Safe default: no placements, so no ad can be requested until a real config arrives. */
@property (readonly) PentabitAnalyticsSdkConfig *SAFE_DEFAULT __attribute__((swift_name("SAFE_DEFAULT")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdError")))
@interface PentabitAnalyticsAdError : PentabitAnalyticsBase
- (instancetype)initWithCode:(PentabitAnalyticsAdErrorCode *)code message:(NSString *)message __attribute__((swift_name("init(code:message:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsAdError *)doCopyCode:(PentabitAnalyticsAdErrorCode *)code message:(NSString *)message __attribute__((swift_name("doCopy(code:message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PentabitAnalyticsAdErrorCode *code __attribute__((swift_name("code")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end


/** Stable error codes. Publishers can rely on these never changing meaning. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdErrorCode")))
@interface PentabitAnalyticsAdErrorCode : PentabitAnalyticsKotlinEnum<PentabitAnalyticsAdErrorCode *>
+ (instancetype)alloc __attribute__((unavailable));

/** Stable error codes. Publishers can rely on these never changing meaning. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAnalyticsAdErrorCode *notInitialized __attribute__((swift_name("notInitialized")));
@property (class, readonly) PentabitAnalyticsAdErrorCode *placementNotFound __attribute__((swift_name("placementNotFound")));
@property (class, readonly) PentabitAnalyticsAdErrorCode *placementDisabled __attribute__((swift_name("placementDisabled")));
@property (class, readonly) PentabitAnalyticsAdErrorCode *killSwitch __attribute__((swift_name("killSwitch")));
@property (class, readonly) PentabitAnalyticsAdErrorCode *appNotAuthorized __attribute__((swift_name("appNotAuthorized")));
@property (class, readonly) PentabitAnalyticsAdErrorCode *consentBlocked __attribute__((swift_name("consentBlocked")));
@property (class, readonly) PentabitAnalyticsAdErrorCode *noFill __attribute__((swift_name("noFill")));
@property (class, readonly) PentabitAnalyticsAdErrorCode *timeout __attribute__((swift_name("timeout")));
@property (class, readonly) PentabitAnalyticsAdErrorCode *network __attribute__((swift_name("network")));
@property (class, readonly) PentabitAnalyticsAdErrorCode *assetFailed __attribute__((swift_name("assetFailed")));
@property (class, readonly) PentabitAnalyticsAdErrorCode *expired __attribute__((swift_name("expired")));
@property (class, readonly) PentabitAnalyticsAdErrorCode *internal __attribute__((swift_name("internal")));
+ (PentabitAnalyticsKotlinArray<PentabitAnalyticsAdErrorCode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAnalyticsAdErrorCode *> *entries __attribute__((swift_name("entries")));
@end


/** Result type used across the SDK instead of exceptions. */
__attribute__((swift_name("AdResult")))
@protocol PentabitAnalyticsAdResult
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdResultFailure")))
@interface PentabitAnalyticsAdResultFailure : PentabitAnalyticsBase <PentabitAnalyticsAdResult>
- (instancetype)initWithError:(PentabitAnalyticsAdError *)error __attribute__((swift_name("init(error:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsAdResultFailure *)doCopyError:(PentabitAnalyticsAdError *)error __attribute__((swift_name("doCopy(error:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PentabitAnalyticsAdError *error __attribute__((swift_name("error")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdResultSuccess")))
@interface PentabitAnalyticsAdResultSuccess<__covariant T> : PentabitAnalyticsBase <PentabitAnalyticsAdResult>
- (instancetype)initWithValue:(T _Nullable)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsAdResultSuccess<T> *)doCopyValue:(T _Nullable)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) T _Nullable value __attribute__((swift_name("value")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventContext")))
@interface PentabitAnalyticsEventContext : PentabitAnalyticsBase
- (instancetype)initWithApp:(PentabitAnalyticsAppInfo *)app device:(PentabitAnalyticsDeviceContext *)device privacy:(PentabitAnalyticsPrivacyContext *)privacy sdk:(PentabitAnalyticsSdkInfo *)sdk sessionId:(NSString *)sessionId clockOffsetMs:(PentabitAnalyticsLong * _Nullable)clockOffsetMs testMode:(BOOL)testMode __attribute__((swift_name("init(app:device:privacy:sdk:sessionId:clockOffsetMs:testMode:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsEventContextCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAnalyticsEventContext *)doCopyApp:(PentabitAnalyticsAppInfo *)app device:(PentabitAnalyticsDeviceContext *)device privacy:(PentabitAnalyticsPrivacyContext *)privacy sdk:(PentabitAnalyticsSdkInfo *)sdk sessionId:(NSString *)sessionId clockOffsetMs:(PentabitAnalyticsLong * _Nullable)clockOffsetMs testMode:(BOOL)testMode __attribute__((swift_name("doCopy(app:device:privacy:sdk:sessionId:clockOffsetMs:testMode:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PentabitAnalyticsAppInfo *app __attribute__((swift_name("app")));

/** Device clock minus last seen server time, when known. */
@property (readonly) PentabitAnalyticsLong * _Nullable clockOffsetMs __attribute__((swift_name("clockOffsetMs")));
@property (readonly) PentabitAnalyticsDeviceContext *device __attribute__((swift_name("device")));
@property (readonly) PentabitAnalyticsPrivacyContext *privacy __attribute__((swift_name("privacy")));
@property (readonly) PentabitAnalyticsSdkInfo *sdk __attribute__((swift_name("sdk")));

/** Random per-process ID. Used instead of a persistent ID when the privacy mode forbids one. */
@property (readonly) NSString *sessionId __attribute__((swift_name("sessionId")));

/** True for debug builds: the backend must keep this traffic out of live reporting and billing. */
@property (readonly) BOOL testMode __attribute__((swift_name("testMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventContext.Companion")))
@interface PentabitAnalyticsEventContextCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsEventContextCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/** Runs the flush timer, with backoff after failures. Only one flush runs at a time. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventFlusher")))
@interface PentabitAnalyticsEventFlusher : PentabitAnalyticsBase
- (instancetype)initWithUploader:(PentabitAnalyticsEventUploader *)uploader scope:(id<PentabitAnalyticsKotlinx_coroutines_coreCoroutineScope>)scope flushIntervalSeconds:(PentabitAnalyticsInt *(^)(void))flushIntervalSeconds retry:(PentabitAnalyticsRetryPolicy *)retry __attribute__((swift_name("init(uploader:scope:flushIntervalSeconds:retry:)"))) __attribute__((objc_designated_initializer));

/** Call when the app goes to the background so queued events are sent before the process may stop.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)flushAndWaitWithCompletionHandler:(void (^)(PentabitAnalyticsFlushOutcome * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("flushAndWait(completionHandler:)")));
- (void)flushNow __attribute__((swift_name("flushNow()")));
- (void)start __attribute__((swift_name("start()")));
- (void)stop __attribute__((swift_name("stop()")));
@end


/** Standard event names used by both SDKs. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventNames")))
@interface PentabitAnalyticsEventNames : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));

/** Standard event names used by both SDKs. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)eventNames __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsEventNames *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *CLICK __attribute__((swift_name("CLICK")));
@property (readonly) NSString *CLOSE __attribute__((swift_name("CLOSE")));
@property (readonly) NSString *DEEP_LINK_OPEN __attribute__((swift_name("DEEP_LINK_OPEN")));
@property (readonly) NSString *END_CARD_SHOWN __attribute__((swift_name("END_CARD_SHOWN")));
@property (readonly) NSString *ERROR __attribute__((swift_name("ERROR")));
@property (readonly) NSString *FEATURE_USED __attribute__((swift_name("FEATURE_USED")));
@property (readonly) NSString *FIRST_OPEN __attribute__((swift_name("FIRST_OPEN")));

/** Events sent at once instead of waiting for the next batch. */
@property (readonly) NSSet<NSString *> *IMMEDIATE __attribute__((swift_name("IMMEDIATE")));
@property (readonly) NSString *IMPRESSION __attribute__((swift_name("IMPRESSION")));
@property (readonly) NSString *LEVEL_REACHED __attribute__((swift_name("LEVEL_REACHED")));
@property (readonly) NSString *PLAYABLE_COMPLETE __attribute__((swift_name("PLAYABLE_COMPLETE")));
@property (readonly) NSString *PURCHASE __attribute__((swift_name("PURCHASE")));
@property (readonly) NSString *REGISTRATION __attribute__((swift_name("REGISTRATION")));
@property (readonly) NSString *REWARD_EARNED __attribute__((swift_name("REWARD_EARNED")));
@property (readonly) NSString *SKIP __attribute__((swift_name("SKIP")));
@property (readonly) NSString *SUBSCRIBE __attribute__((swift_name("SUBSCRIBE")));
@property (readonly) NSString *TUTORIAL_COMPLETE __attribute__((swift_name("TUTORIAL_COMPLETE")));
@property (readonly) NSString *VIDEO_COMPLETE __attribute__((swift_name("VIDEO_COMPLETE")));
@property (readonly) NSString *VIDEO_MID __attribute__((swift_name("VIDEO_MID")));
@property (readonly) NSString *VIDEO_Q1 __attribute__((swift_name("VIDEO_Q1")));
@property (readonly) NSString *VIDEO_Q3 __attribute__((swift_name("VIDEO_Q3")));
@property (readonly) NSString *VIDEO_START __attribute__((swift_name("VIDEO_START")));
@property (readonly) NSString *VIEWABLE_IMPRESSION __attribute__((swift_name("VIEWABLE_IMPRESSION")));
@end


/**
 * Single entry point for events. It never blocks the caller: the event is written to the durable
 * queue on a background coroutine, then flushed in a batch (or at once for important events).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventTracker")))
@interface PentabitAnalyticsEventTracker : PentabitAnalyticsBase
- (instancetype)initWithStore:(id<PentabitAnalyticsEventStore>)store clock:(id<PentabitAnalyticsClock>)clock ids:(id<PentabitAnalyticsIdGenerator>)ids scope:(id<PentabitAnalyticsKotlinx_coroutines_coreCoroutineScope>)scope logger:(id<PentabitAnalyticsLogger>)logger __attribute__((swift_name("init(store:clock:ids:scope:logger:)"))) __attribute__((objc_designated_initializer));
- (void)attachFlusher:(PentabitAnalyticsEventFlusher *)flusher __attribute__((swift_name("attach(flusher:)")));
- (void)trackName:(NSString *)name requestId:(NSString * _Nullable)requestId placementId:(NSString * _Nullable)placementId params:(NSDictionary<NSString *, NSString *> *)params value:(PentabitAnalyticsDouble * _Nullable)value currency:(NSString * _Nullable)currency __attribute__((swift_name("track(name:requestId:placementId:params:value:currency:)")));
@end


/**
 * Reads batches from the durable queue and posts them. An event is deleted only after the backend
 * confirmed it (2xx) or rejected it as invalid (4xx). Retries are safe because the backend
 * de-duplicates by event ID.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventUploader")))
@interface PentabitAnalyticsEventUploader : PentabitAnalyticsBase
- (instancetype)initWithApi:(PentabitAnalyticsApiClient *)api store:(id<PentabitAnalyticsEventStore>)store clock:(id<PentabitAnalyticsClock>)clock logger:(id<PentabitAnalyticsLogger>)logger contextProvider:(id<PentabitAnalyticsKotlinSuspendFunction0>)contextProvider maxBatchesPerFlush:(int32_t)maxBatchesPerFlush path:(NSString *)path batchSize:(PentabitAnalyticsInt *(^)(void))batchSize onReply:(id<PentabitAnalyticsKotlinSuspendFunction1> _Nullable)onReply __attribute__((swift_name("init(api:store:clock:logger:contextProvider:maxBatchesPerFlush:path:batchSize:onReply:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)flushOnceWithCompletionHandler:(void (^)(PentabitAnalyticsFlushOutcome * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("flushOnce(completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FlushOutcome")))
@interface PentabitAnalyticsFlushOutcome : PentabitAnalyticsKotlinEnum<PentabitAnalyticsFlushOutcome *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAnalyticsFlushOutcome *nothingToSend __attribute__((swift_name("nothingToSend")));
@property (class, readonly) PentabitAnalyticsFlushOutcome *sent __attribute__((swift_name("sent")));
@property (class, readonly) PentabitAnalyticsFlushOutcome *retryLater __attribute__((swift_name("retryLater")));
@property (class, readonly) PentabitAnalyticsFlushOutcome *blocked __attribute__((swift_name("blocked")));
+ (PentabitAnalyticsKotlinArray<PentabitAnalyticsFlushOutcome *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAnalyticsFlushOutcome *> *entries __attribute__((swift_name("entries")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PentabitEvent")))
@interface PentabitAnalyticsPentabitEvent : PentabitAnalyticsBase
- (instancetype)initWithId:(NSString *)id name:(NSString *)name timestamp:(int64_t)timestamp requestId:(NSString * _Nullable)requestId placementId:(NSString * _Nullable)placementId params:(NSDictionary<NSString *, NSString *> *)params value:(PentabitAnalyticsDouble * _Nullable)value currency:(NSString * _Nullable)currency __attribute__((swift_name("init(id:name:timestamp:requestId:placementId:params:value:currency:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsPentabitEventCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAnalyticsPentabitEvent *)doCopyId:(NSString *)id name:(NSString *)name timestamp:(int64_t)timestamp requestId:(NSString * _Nullable)requestId placementId:(NSString * _Nullable)placementId params:(NSDictionary<NSString *, NSString *> *)params value:(PentabitAnalyticsDouble * _Nullable)value currency:(NSString * _Nullable)currency __attribute__((swift_name("doCopy(id:name:timestamp:requestId:placementId:params:value:currency:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable currency __attribute__((swift_name("currency")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSDictionary<NSString *, NSString *> *params __attribute__((swift_name("params")));
@property (readonly) NSString * _Nullable placementId __attribute__((swift_name("placementId")));
@property (readonly) NSString * _Nullable requestId __attribute__((swift_name("requestId")));
@property (readonly) int64_t timestamp __attribute__((swift_name("timestamp")));
@property (readonly) PentabitAnalyticsDouble * _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PentabitEvent.Companion")))
@interface PentabitAnalyticsPentabitEventCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsPentabitEventCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Counts an impression once, when at least [minAreaPercent] of the ad has been visible for
 * [minDurationMs] without a break. The defaults live in SdkDefaults.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ViewabilityTracker")))
@interface PentabitAnalyticsViewabilityTracker : PentabitAnalyticsBase
- (instancetype)initWithMinAreaPercent:(int32_t)minAreaPercent minDurationMs:(int64_t)minDurationMs __attribute__((swift_name("init(minAreaPercent:minDurationMs:)"))) __attribute__((objc_designated_initializer));

/** True while the ad is above the area threshold but the time has not elapsed yet. */
- (BOOL)isPending __attribute__((swift_name("isPending()")));
- (int64_t)millisUntilCountedNowMillis:(int64_t)nowMillis __attribute__((swift_name("millisUntilCounted(nowMillis:)")));

/** Feed exposure readings. Returns true exactly once, when the rule is first met. */
- (BOOL)onExposurePercent:(double)percent nowMillis:(int64_t)nowMillis __attribute__((swift_name("onExposure(percent:nowMillis:)")));
@property (readonly) BOOL isCounted __attribute__((swift_name("isCounted")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdFormat")))
@interface PentabitAnalyticsAdFormat : PentabitAnalyticsKotlinEnum<PentabitAnalyticsAdFormat *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) PentabitAnalyticsAdFormatCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) PentabitAnalyticsAdFormat *banner __attribute__((swift_name("banner")));
@property (class, readonly) PentabitAnalyticsAdFormat *native __attribute__((swift_name("native")));
@property (class, readonly) PentabitAnalyticsAdFormat *icon __attribute__((swift_name("icon")));
@property (class, readonly) PentabitAnalyticsAdFormat *interstitial __attribute__((swift_name("interstitial")));
@property (class, readonly) PentabitAnalyticsAdFormat *rewarded __attribute__((swift_name("rewarded")));
@property (class, readonly) PentabitAnalyticsAdFormat *appOpen __attribute__((swift_name("appOpen")));
+ (PentabitAnalyticsKotlinArray<PentabitAnalyticsAdFormat *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAnalyticsAdFormat *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdFormat.Companion")))
@interface PentabitAnalyticsAdFormatCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsAdFormatCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(PentabitAnalyticsKotlinArray<id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdRequest")))
@interface PentabitAnalyticsAdRequest : PentabitAnalyticsBase
- (instancetype)initWithRequestId:(NSString *)requestId placementId:(NSString *)placementId format:(PentabitAnalyticsAdFormat *)format app:(PentabitAnalyticsAppInfo *)app device:(PentabitAnalyticsDeviceContext *)device privacy:(PentabitAnalyticsPrivacyContext *)privacy sdk:(PentabitAnalyticsSdkInfo *)sdk testMode:(BOOL)testMode bannerSize:(NSString * _Nullable)bannerSize __attribute__((swift_name("init(requestId:placementId:format:app:device:privacy:sdk:testMode:bannerSize:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsAdRequestCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAnalyticsAdRequest *)doCopyRequestId:(NSString *)requestId placementId:(NSString *)placementId format:(PentabitAnalyticsAdFormat *)format app:(PentabitAnalyticsAppInfo *)app device:(PentabitAnalyticsDeviceContext *)device privacy:(PentabitAnalyticsPrivacyContext *)privacy sdk:(PentabitAnalyticsSdkInfo *)sdk testMode:(BOOL)testMode bannerSize:(NSString * _Nullable)bannerSize __attribute__((swift_name("doCopy(requestId:placementId:format:app:device:privacy:sdk:testMode:bannerSize:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PentabitAnalyticsAppInfo *app __attribute__((swift_name("app")));

/** Banner requests only, "320x50": the backend returns a banner of exactly this size or no ad. */
@property (readonly) NSString * _Nullable bannerSize __attribute__((swift_name("bannerSize")));
@property (readonly) PentabitAnalyticsDeviceContext *device __attribute__((swift_name("device")));
@property (readonly) PentabitAnalyticsAdFormat *format __attribute__((swift_name("format")));
@property (readonly) NSString *placementId __attribute__((swift_name("placementId")));
@property (readonly) PentabitAnalyticsPrivacyContext *privacy __attribute__((swift_name("privacy")));
@property (readonly) NSString *requestId __attribute__((swift_name("requestId")));
@property (readonly) PentabitAnalyticsSdkInfo *sdk __attribute__((swift_name("sdk")));

/** True for debug builds: the backend returns a Pentabit test ad and does not count or bill it. */
@property (readonly) BOOL testMode __attribute__((swift_name("testMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdRequest.Companion")))
@interface PentabitAnalyticsAdRequestCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsAdRequestCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdResponse")))
@interface PentabitAnalyticsAdResponse : PentabitAnalyticsBase
- (instancetype)initWithRequestId:(NSString *)requestId ttlSeconds:(int32_t)ttlSeconds creative:(PentabitAnalyticsCreative *)creative reward:(PentabitAnalyticsRewardSpec * _Nullable)reward closeDelaySeconds:(int32_t)closeDelaySeconds paidMicros:(int64_t)paidMicros paidCurrency:(NSString *)paidCurrency adSource:(PentabitAnalyticsAdSource *)adSource __attribute__((swift_name("init(requestId:ttlSeconds:creative:reward:closeDelaySeconds:paidMicros:paidCurrency:adSource:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsAdResponseCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAnalyticsAdResponse *)doCopyRequestId:(NSString *)requestId ttlSeconds:(int32_t)ttlSeconds creative:(PentabitAnalyticsCreative *)creative reward:(PentabitAnalyticsRewardSpec * _Nullable)reward closeDelaySeconds:(int32_t)closeDelaySeconds paidMicros:(int64_t)paidMicros paidCurrency:(NSString *)paidCurrency adSource:(PentabitAnalyticsAdSource *)adSource __attribute__((swift_name("doCopy(requestId:ttlSeconds:creative:reward:closeDelaySeconds:paidMicros:paidCurrency:adSource:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/** Whether this ad is a paid advertiser or your own cross-promotion. Test ads count as advertising. */
@property (readonly) PentabitAnalyticsAdSource *adSource __attribute__((swift_name("adSource")));

/** Seconds before the close control shows (server decides; the SDK caps it at 15). A rewarded ad grants its reward when this time has run (web ads) or the video completes. */
@property (readonly) int32_t closeDelaySeconds __attribute__((swift_name("closeDelaySeconds")));
@property (readonly) PentabitAnalyticsCreative *creative __attribute__((swift_name("creative")));
@property (readonly) NSString *paidCurrency __attribute__((swift_name("paidCurrency")));

/** What this impression earned the publisher, in millionths of [paidCurrency]. 0 for cross-promotion. */
@property (readonly) int64_t paidMicros __attribute__((swift_name("paidMicros")));
@property (readonly) NSString *requestId __attribute__((swift_name("requestId")));
@property (readonly) PentabitAnalyticsRewardSpec * _Nullable reward __attribute__((swift_name("reward")));
@property (readonly) int32_t ttlSeconds __attribute__((swift_name("ttlSeconds")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdResponse.Companion")))
@interface PentabitAnalyticsAdResponseCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsAdResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/** Who the winning campaign belongs to: a paying advertiser, or the publisher's own cross-promotion (in-house).
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdSource")))
@interface PentabitAnalyticsAdSource : PentabitAnalyticsKotlinEnum<PentabitAnalyticsAdSource *>
+ (instancetype)alloc __attribute__((unavailable));

/** Who the winning campaign belongs to: a paying advertiser, or the publisher's own cross-promotion (in-house). */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) PentabitAnalyticsAdSourceCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) PentabitAnalyticsAdSource *advertising __attribute__((swift_name("advertising")));
@property (class, readonly) PentabitAnalyticsAdSource *crossPromotion __attribute__((swift_name("crossPromotion")));
+ (PentabitAnalyticsKotlinArray<PentabitAnalyticsAdSource *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAnalyticsAdSource *> *entries __attribute__((swift_name("entries")));
@end


/** Who the winning campaign belongs to: a paying advertiser, or the publisher's own cross-promotion (in-house). */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdSource.Companion")))
@interface PentabitAnalyticsAdSourceCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));

/** Who the winning campaign belongs to: a paying advertiser, or the publisher's own cross-promotion (in-house). */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsAdSourceCompanion *shared __attribute__((swift_name("shared")));

/** Who the winning campaign belongs to: a paying advertiser, or the publisher's own cross-promotion (in-house). */
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));

/** Who the winning campaign belongs to: a paying advertiser, or the publisher's own cross-promotion (in-house). */
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(PentabitAnalyticsKotlinArray<id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AppInfo")))
@interface PentabitAnalyticsAppInfo : PentabitAnalyticsBase
- (instancetype)initWithId:(NSString *)id version:(NSString *)version __attribute__((swift_name("init(id:version:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsAppInfoCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAnalyticsAppInfo *)doCopyId:(NSString *)id version:(NSString *)version __attribute__((swift_name("doCopy(id:version:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString *version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AppInfo.Companion")))
@interface PentabitAnalyticsAppInfoCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsAppInfoCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Creative")))
@interface PentabitAnalyticsCreative : PentabitAnalyticsBase
- (instancetype)initWithType:(PentabitAnalyticsCreativeType *)type markup:(NSString * _Nullable)markup vastXml:(NSString * _Nullable)vastXml vastUrl:(NSString * _Nullable)vastUrl clickUrl:(NSString * _Nullable)clickUrl assets:(NSArray<PentabitAnalyticsCreativeAsset *> *)assets native:(PentabitAnalyticsNativeAssets * _Nullable)native width:(PentabitAnalyticsInt * _Nullable)width height:(PentabitAnalyticsInt * _Nullable)height orientation:(NSString * _Nullable)orientation __attribute__((swift_name("init(type:markup:vastXml:vastUrl:clickUrl:assets:native:width:height:orientation:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsCreativeCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAnalyticsCreative *)doCopyType:(PentabitAnalyticsCreativeType *)type markup:(NSString * _Nullable)markup vastXml:(NSString * _Nullable)vastXml vastUrl:(NSString * _Nullable)vastUrl clickUrl:(NSString * _Nullable)clickUrl assets:(NSArray<PentabitAnalyticsCreativeAsset *> *)assets native:(PentabitAnalyticsNativeAssets * _Nullable)native width:(PentabitAnalyticsInt * _Nullable)width height:(PentabitAnalyticsInt * _Nullable)height orientation:(NSString * _Nullable)orientation __attribute__((swift_name("doCopy(type:markup:vastXml:vastUrl:clickUrl:assets:native:width:height:orientation:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<PentabitAnalyticsCreativeAsset *> *assets __attribute__((swift_name("assets")));
@property (readonly) NSString * _Nullable clickUrl __attribute__((swift_name("clickUrl")));
@property (readonly) PentabitAnalyticsInt * _Nullable height __attribute__((swift_name("height")));
@property (readonly) NSString * _Nullable markup __attribute__((swift_name("markup")));
@property (readonly) PentabitAnalyticsNativeAssets * _Nullable native __attribute__((swift_name("native")));
@property (readonly) NSString * _Nullable orientation __attribute__((swift_name("orientation")));
@property (readonly) PentabitAnalyticsCreativeType *type __attribute__((swift_name("type")));
@property (readonly) NSString * _Nullable vastUrl __attribute__((swift_name("vastUrl")));
@property (readonly) NSString * _Nullable vastXml __attribute__((swift_name("vastXml")));
@property (readonly) PentabitAnalyticsInt * _Nullable width __attribute__((swift_name("width")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Creative.Companion")))
@interface PentabitAnalyticsCreativeCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsCreativeCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreativeAsset")))
@interface PentabitAnalyticsCreativeAsset : PentabitAnalyticsBase
- (instancetype)initWithKey:(NSString *)key url:(NSString *)url mime:(NSString * _Nullable)mime sizeBytes:(PentabitAnalyticsLong * _Nullable)sizeBytes sha256:(NSString * _Nullable)sha256 role:(NSString * _Nullable)role __attribute__((swift_name("init(key:url:mime:sizeBytes:sha256:role:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsCreativeAssetCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAnalyticsCreativeAsset *)doCopyKey:(NSString *)key url:(NSString *)url mime:(NSString * _Nullable)mime sizeBytes:(PentabitAnalyticsLong * _Nullable)sizeBytes sha256:(NSString * _Nullable)sha256 role:(NSString * _Nullable)role __attribute__((swift_name("doCopy(key:url:mime:sizeBytes:sha256:role:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *key __attribute__((swift_name("key")));
@property (readonly) NSString * _Nullable mime __attribute__((swift_name("mime")));
@property (readonly) NSString * _Nullable role __attribute__((swift_name("role")));
@property (readonly) NSString * _Nullable sha256 __attribute__((swift_name("sha256")));
@property (readonly) PentabitAnalyticsLong * _Nullable sizeBytes __attribute__((swift_name("sizeBytes")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreativeAsset.Companion")))
@interface PentabitAnalyticsCreativeAssetCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsCreativeAssetCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreativeType")))
@interface PentabitAnalyticsCreativeType : PentabitAnalyticsKotlinEnum<PentabitAnalyticsCreativeType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) PentabitAnalyticsCreativeTypeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) PentabitAnalyticsCreativeType *html __attribute__((swift_name("html")));
@property (class, readonly) PentabitAnalyticsCreativeType *image __attribute__((swift_name("image")));
@property (class, readonly) PentabitAnalyticsCreativeType *vast __attribute__((swift_name("vast")));
@property (class, readonly) PentabitAnalyticsCreativeType *native __attribute__((swift_name("native")));
+ (PentabitAnalyticsKotlinArray<PentabitAnalyticsCreativeType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAnalyticsCreativeType *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreativeType.Companion")))
@interface PentabitAnalyticsCreativeTypeCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsCreativeTypeCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(PentabitAnalyticsKotlinArray<id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeviceContext")))
@interface PentabitAnalyticsDeviceContext : PentabitAnalyticsBase
- (instancetype)initWithPlatform:(NSString *)platform osVersion:(NSString *)osVersion deviceClass:(NSString *)deviceClass country:(NSString * _Nullable)country language:(NSString * _Nullable)language advertisingId:(NSString * _Nullable)advertisingId appInstanceId:(NSString * _Nullable)appInstanceId deviceId:(NSString * _Nullable)deviceId __attribute__((swift_name("init(platform:osVersion:deviceClass:country:language:advertisingId:appInstanceId:deviceId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsDeviceContextCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAnalyticsDeviceContext *)doCopyPlatform:(NSString *)platform osVersion:(NSString *)osVersion deviceClass:(NSString *)deviceClass country:(NSString * _Nullable)country language:(NSString * _Nullable)language advertisingId:(NSString * _Nullable)advertisingId appInstanceId:(NSString * _Nullable)appInstanceId deviceId:(NSString * _Nullable)deviceId __attribute__((swift_name("doCopy(platform:osVersion:deviceClass:country:language:advertisingId:appInstanceId:deviceId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/** Present only when the privacy mode allows it. */
@property (readonly) NSString * _Nullable advertisingId __attribute__((swift_name("advertisingId")));

/** Present only in NORMAL mode. */
@property (readonly) NSString * _Nullable appInstanceId __attribute__((swift_name("appInstanceId")));
@property (readonly) NSString * _Nullable country __attribute__((swift_name("country")));
@property (readonly) NSString *deviceClass __attribute__((swift_name("deviceClass")));

/** Device-level ID (ANDROID_ID / identifierForVendor). Present only in NORMAL mode. */
@property (readonly) NSString * _Nullable deviceId __attribute__((swift_name("deviceId")));
@property (readonly) NSString * _Nullable language __attribute__((swift_name("language")));
@property (readonly) NSString *osVersion __attribute__((swift_name("osVersion")));
@property (readonly) NSString *platform __attribute__((swift_name("platform")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeviceContext.Companion")))
@interface PentabitAnalyticsDeviceContextCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsDeviceContextCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NativeAssets")))
@interface PentabitAnalyticsNativeAssets : PentabitAnalyticsBase
- (instancetype)initWithTitle:(NSString * _Nullable)title body:(NSString * _Nullable)body callToAction:(NSString * _Nullable)callToAction iconAssetKey:(NSString * _Nullable)iconAssetKey imageAssetKey:(NSString * _Nullable)imageAssetKey sponsoredLabel:(NSString * _Nullable)sponsoredLabel privacyUrl:(NSString * _Nullable)privacyUrl __attribute__((swift_name("init(title:body:callToAction:iconAssetKey:imageAssetKey:sponsoredLabel:privacyUrl:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsNativeAssetsCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAnalyticsNativeAssets *)doCopyTitle:(NSString * _Nullable)title body:(NSString * _Nullable)body callToAction:(NSString * _Nullable)callToAction iconAssetKey:(NSString * _Nullable)iconAssetKey imageAssetKey:(NSString * _Nullable)imageAssetKey sponsoredLabel:(NSString * _Nullable)sponsoredLabel privacyUrl:(NSString * _Nullable)privacyUrl __attribute__((swift_name("doCopy(title:body:callToAction:iconAssetKey:imageAssetKey:sponsoredLabel:privacyUrl:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable body __attribute__((swift_name("body")));
@property (readonly) NSString * _Nullable callToAction __attribute__((swift_name("callToAction")));
@property (readonly) NSString * _Nullable iconAssetKey __attribute__((swift_name("iconAssetKey")));
@property (readonly) NSString * _Nullable imageAssetKey __attribute__((swift_name("imageAssetKey")));

/** Where the (i) button leads. Defaults to the Pentabit privacy policy. */
@property (readonly) NSString * _Nullable privacyUrl __attribute__((swift_name("privacyUrl")));
@property (readonly) NSString * _Nullable sponsoredLabel __attribute__((swift_name("sponsoredLabel")));
@property (readonly) NSString * _Nullable title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NativeAssets.Companion")))
@interface PentabitAnalyticsNativeAssetsCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsNativeAssetsCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrivacyContext")))
@interface PentabitAnalyticsPrivacyContext : PentabitAnalyticsBase
- (instancetype)initWithMode:(NSString *)mode tcfString:(NSString * _Nullable)tcfString gppString:(NSString * _Nullable)gppString underAge:(PentabitAnalyticsBoolean * _Nullable)underAge usOptOut:(BOOL)usOptOut userId:(NSString * _Nullable)userId __attribute__((swift_name("init(mode:tcfString:gppString:underAge:usOptOut:userId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsPrivacyContextCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAnalyticsPrivacyContext *)doCopyMode:(NSString *)mode tcfString:(NSString * _Nullable)tcfString gppString:(NSString * _Nullable)gppString underAge:(PentabitAnalyticsBoolean * _Nullable)underAge usOptOut:(BOOL)usOptOut userId:(NSString * _Nullable)userId __attribute__((swift_name("doCopy(mode:tcfString:gppString:underAge:usOptOut:userId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable gppString __attribute__((swift_name("gppString")));
@property (readonly) NSString *mode __attribute__((swift_name("mode")));
@property (readonly) NSString * _Nullable tcfString __attribute__((swift_name("tcfString")));
@property (readonly) PentabitAnalyticsBoolean * _Nullable underAge __attribute__((swift_name("underAge")));
@property (readonly) BOOL usOptOut __attribute__((swift_name("usOptOut")));
@property (readonly) NSString * _Nullable userId __attribute__((swift_name("userId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrivacyContext.Companion")))
@interface PentabitAnalyticsPrivacyContextCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsPrivacyContextCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RewardSpec")))
@interface PentabitAnalyticsRewardSpec : PentabitAnalyticsBase
- (instancetype)initWithType:(NSString *)type amount:(int32_t)amount __attribute__((swift_name("init(type:amount:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsRewardSpecCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAnalyticsRewardSpec *)doCopyType:(NSString *)type amount:(int32_t)amount __attribute__((swift_name("doCopy(type:amount:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t amount __attribute__((swift_name("amount")));
@property (readonly) NSString *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RewardSpec.Companion")))
@interface PentabitAnalyticsRewardSpecCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsRewardSpecCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkInfo")))
@interface PentabitAnalyticsSdkInfo : PentabitAnalyticsBase
- (instancetype)initWithName:(NSString *)name version:(NSString *)version __attribute__((swift_name("init(name:version:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsSdkInfoCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAnalyticsSdkInfo *)doCopyName:(NSString *)name version:(NSString *)version __attribute__((swift_name("doCopy(name:version:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkInfo.Companion")))
@interface PentabitAnalyticsSdkInfoCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsSdkInfoCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/** Builds the HTML the WebView loads. Creatives must be self-contained, so the CSP blocks everything else. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreativeHtml")))
@interface PentabitAnalyticsCreativeHtml : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));

/** Builds the HTML the WebView loads. Creatives must be self-contained, so the CSP blocks everything else. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)creativeHtml __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsCreativeHtml *shared __attribute__((swift_name("shared")));

/** Replaces `[AKS_ASSET:key]` in creative markup with the URL the platform serves that cached asset from. */
- (NSString *)expandAssetsMarkup:(NSString *)markup assetBase:(NSString *)assetBase __attribute__((swift_name("expandAssets(markup:assetBase:)")));

/**
 * Injects the MRAID script, a viewport tag and the content security policy into [markup].
 * [assetOrigins] lists the origins serving cached assets, for example
 * `https://aks-assets.invalid aks-asset://aks-assets.invalid`.
 */
- (NSString *)prepareMarkup:(NSString *)markup assetOrigins:(NSString *)assetOrigins __attribute__((swift_name("prepare(markup:assetOrigins:)")));

/**
 * A static image creative becomes a tiny HTML page, so every creative uses the same MRAID path. The page carries the (i) button:
 * small in the top-right corner of a banner ([compact]), bottom-left on a full-screen ad. A tap opens [PRIVACY_URL] and not the store.
 */
- (NSString *)staticImagePageImageUrl:(NSString *)imageUrl clickUrl:(NSString * _Nullable)clickUrl compact:(BOOL)compact __attribute__((swift_name("staticImagePage(imageUrl:clickUrl:compact:)")));

/** Host used for locally served assets. The platform intercepts requests to it. */
@property (readonly) NSString *ASSET_HOST __attribute__((swift_name("ASSET_HOST")));

/** The page the (i) button opens. Opening it is not a click on the ad. */
@property (readonly) NSString *PRIVACY_URL __attribute__((swift_name("PRIVACY_URL")));
@end


/**
 * The MRAID state machine and message handling, shared by Android and iOS. The platform only
 * injects the script, forwards raw messages here and runs the scripts this class returns.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidController")))
@interface PentabitAnalyticsMraidController : PentabitAnalyticsBase
- (instancetype)initWithPlacement:(PentabitAnalyticsMraidPlacement *)placement listener:(id<PentabitAnalyticsMraidListener>)listener __attribute__((swift_name("init(placement:listener:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsMraidControllerCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)exposureScriptPercent:(double)percent __attribute__((swift_name("exposureScript(percent:)")));
- (void)handleMsg:(id<PentabitAnalyticsMraidMessage>)msg __attribute__((swift_name("handle(msg:)")));
- (id<PentabitAnalyticsMraidMessage> _Nullable)handleRawRaw:(NSString *)raw __attribute__((swift_name("handleRaw(raw:)")));
- (NSString *)hiddenScript __attribute__((swift_name("hiddenScript()")));

/** Scripts to run once the page has loaded. Moves the state from loading to default. */
- (NSArray<NSString *> *)readyScriptsMaxWidth:(int32_t)maxWidth maxHeight:(int32_t)maxHeight screenWidth:(int32_t)screenWidth screenHeight:(int32_t)screenHeight __attribute__((swift_name("readyScripts(maxWidth:maxHeight:screenWidth:screenHeight:)")));
- (NSString *)viewableScriptViewable:(BOOL)viewable __attribute__((swift_name("viewableScript(viewable:)")));
@property (readonly) PentabitAnalyticsMraidState *state __attribute__((swift_name("state")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidController.Companion")))
@interface PentabitAnalyticsMraidControllerCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsMraidControllerCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsMraidMessage> _Nullable)parseRaw:(NSString *)raw __attribute__((swift_name("parse(raw:)")));
@end

__attribute__((swift_name("MraidListener")))
@protocol PentabitAnalyticsMraidListener
@required
- (void)onClose __attribute__((swift_name("onClose()")));
- (void)onCreativeErrorMessage:(NSString *)message __attribute__((swift_name("onCreativeError(message:)")));
- (void)onOpenUrl:(NSString *)url __attribute__((swift_name("onOpen(url:)")));
- (void)onOrientationAllowChange:(BOOL)allowChange force:(NSString *)force __attribute__((swift_name("onOrientation(allowChange:force:)")));
- (void)onPlayableComplete __attribute__((swift_name("onPlayableComplete()")));
- (void)onPlayableCta __attribute__((swift_name("onPlayableCta()")));
- (void)onPlayableReady __attribute__((swift_name("onPlayableReady()")));
@end


/** Messages the creative can send to the host. */
__attribute__((swift_name("MraidMessage")))
@protocol PentabitAnalyticsMraidMessage
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidMessageClose")))
@interface PentabitAnalyticsMraidMessageClose : PentabitAnalyticsBase <PentabitAnalyticsMraidMessage>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)close __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsMraidMessageClose *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidMessageOpen")))
@interface PentabitAnalyticsMraidMessageOpen : PentabitAnalyticsBase <PentabitAnalyticsMraidMessage>
- (instancetype)initWithUrl:(NSString *)url __attribute__((swift_name("init(url:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsMraidMessageOpen *)doCopyUrl:(NSString *)url __attribute__((swift_name("doCopy(url:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidMessageOrientation")))
@interface PentabitAnalyticsMraidMessageOrientation : PentabitAnalyticsBase <PentabitAnalyticsMraidMessage>
- (instancetype)initWithAllowChange:(BOOL)allowChange force:(NSString *)force __attribute__((swift_name("init(allowChange:force:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsMraidMessageOrientation *)doCopyAllowChange:(BOOL)allowChange force:(NSString *)force __attribute__((swift_name("doCopy(allowChange:force:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL allowChange __attribute__((swift_name("allowChange")));
@property (readonly) NSString *force __attribute__((swift_name("force")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidMessagePlayableComplete")))
@interface PentabitAnalyticsMraidMessagePlayableComplete : PentabitAnalyticsBase <PentabitAnalyticsMraidMessage>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)playableComplete __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsMraidMessagePlayableComplete *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidMessagePlayableCta")))
@interface PentabitAnalyticsMraidMessagePlayableCta : PentabitAnalyticsBase <PentabitAnalyticsMraidMessage>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)playableCta __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsMraidMessagePlayableCta *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidMessagePlayableError")))
@interface PentabitAnalyticsMraidMessagePlayableError : PentabitAnalyticsBase <PentabitAnalyticsMraidMessage>
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsMraidMessagePlayableError *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidMessagePlayableReady")))
@interface PentabitAnalyticsMraidMessagePlayableReady : PentabitAnalyticsBase <PentabitAnalyticsMraidMessage>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)playableReady __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsMraidMessagePlayableReady *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidMessageUnload")))
@interface PentabitAnalyticsMraidMessageUnload : PentabitAnalyticsBase <PentabitAnalyticsMraidMessage>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unload __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsMraidMessageUnload *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidPlacement")))
@interface PentabitAnalyticsMraidPlacement : PentabitAnalyticsKotlinEnum<PentabitAnalyticsMraidPlacement *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAnalyticsMraidPlacement *inline_ __attribute__((swift_name("inline_")));
@property (class, readonly) PentabitAnalyticsMraidPlacement *interstitial __attribute__((swift_name("interstitial")));
+ (PentabitAnalyticsKotlinArray<PentabitAnalyticsMraidPlacement *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAnalyticsMraidPlacement *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *wire __attribute__((swift_name("wire")));
@end


/**
 * The mraid.js the SDK injects into every web creative, plus the small `aks` object used by
 * playables. Native code talks to it through `window.__aks`. Written for MRAID 3.0 without
 * expand and resize, which report an error event.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidScript")))
@interface PentabitAnalyticsMraidScript : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * The mraid.js the SDK injects into every web creative, plus the small `aks` object used by
 * playables. Native code talks to it through `window.__aks`. Written for MRAID 3.0 without
 * expand and resize, which report an error event.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)mraidScript __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsMraidScript *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *JS __attribute__((swift_name("JS")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidState")))
@interface PentabitAnalyticsMraidState : PentabitAnalyticsKotlinEnum<PentabitAnalyticsMraidState *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAnalyticsMraidState *loading __attribute__((swift_name("loading")));
@property (class, readonly) PentabitAnalyticsMraidState *default_ __attribute__((swift_name("default_")));
@property (class, readonly) PentabitAnalyticsMraidState *hidden __attribute__((swift_name("hidden")));
+ (PentabitAnalyticsKotlinArray<PentabitAnalyticsMraidState *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAnalyticsMraidState *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *wire __attribute__((swift_name("wire")));
@end


/** Only these schemes may be opened from a creative. Everything else is ignored. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UrlPolicy")))
@interface PentabitAnalyticsUrlPolicy : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));

/** Only these schemes may be opened from a creative. Everything else is ignored. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)urlPolicy __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsUrlPolicy *shared __attribute__((swift_name("shared")));
- (BOOL)isAllowedOpenUrlUrl:(NSString *)url __attribute__((swift_name("isAllowedOpenUrl(url:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiClient")))
@interface PentabitAnalyticsApiClient : PentabitAnalyticsBase
- (instancetype)initWithHttp:(id<PentabitAnalyticsHttpClientPort>)http baseUrl:(NSString *)baseUrl clock:(id<PentabitAnalyticsClock>)clock connectivity:(id<PentabitAnalyticsConnectivityMonitor>)connectivity dispatchers:(id<PentabitAnalyticsDispatcherProvider>)dispatchers headers:(NSDictionary<NSString *, NSString *> *(^)(void))headers retry:(PentabitAnalyticsRetryPolicy *)retry breaker:(PentabitAnalyticsCircuitBreaker *)breaker random:(PentabitAnalyticsDouble *(^)(void))random sleep:(id<PentabitAnalyticsKotlinSuspendFunction1>)sleep __attribute__((swift_name("init(http:baseUrl:clock:connectivity:dispatchers:headers:retry:breaker:random:sleep:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getPath:(NSString *)path timeoutMs:(int64_t)timeoutMs retryable:(BOOL)retryable completionHandler:(void (^)(id<PentabitAnalyticsAdResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("get(path:timeoutMs:retryable:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)postPath:(NSString *)path body:(NSString *)body timeoutMs:(int64_t)timeoutMs retryable:(BOOL)retryable extraHeaders:(NSDictionary<NSString *, NSString *> *)extraHeaders completionHandler:(void (^)(id<PentabitAnalyticsAdResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("post(path:body:timeoutMs:retryable:extraHeaders:completionHandler:)")));

/**
 * Returns any HTTP response (including 4xx and 5xx) as Success once retries are used up.
 * Transport problems become Failure with NETWORK or TIMEOUT.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)sendMethod:(NSString *)method path:(NSString *)path body:(NSString * _Nullable)body timeoutMs:(int64_t)timeoutMs retryable:(BOOL)retryable extraHeaders:(NSDictionary<NSString *, NSString *> *)extraHeaders completionHandler:(void (^)(id<PentabitAnalyticsAdResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("send(method:path:body:timeoutMs:retryable:extraHeaders:completionHandler:)")));
@end


/** After repeated failures, calls fail fast for a cool-down so an outage does not drain battery. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CircuitBreaker")))
@interface PentabitAnalyticsCircuitBreaker : PentabitAnalyticsBase
- (instancetype)initWithClock:(id<PentabitAnalyticsClock>)clock failureThreshold:(int32_t)failureThreshold cooldownMs:(int64_t)cooldownMs __attribute__((swift_name("init(clock:failureThreshold:cooldownMs:)"))) __attribute__((objc_designated_initializer));
- (BOOL)isOpen __attribute__((swift_name("isOpen()")));
- (void)recordFailure __attribute__((swift_name("recordFailure()")));
- (void)recordSuccess __attribute__((swift_name("recordSuccess()")));
@end


/** Fires tracking URLs (VAST and creative trackers) on a best-effort basis with one retry. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PixelClient")))
@interface PentabitAnalyticsPixelClient : PentabitAnalyticsBase
- (instancetype)initWithHttp:(id<PentabitAnalyticsHttpClientPort>)http scope:(id<PentabitAnalyticsKotlinx_coroutines_coreCoroutineScope>)scope clock:(id<PentabitAnalyticsClock>)clock logger:(id<PentabitAnalyticsLogger>)logger __attribute__((swift_name("init(http:scope:clock:logger:)"))) __attribute__((objc_designated_initializer));
- (void)fireUrls:(NSArray<NSString *> *)urls macros:(NSDictionary<NSString *, NSString *> *)macros __attribute__((swift_name("fire(urls:macros:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RetryPolicy")))
@interface PentabitAnalyticsRetryPolicy : PentabitAnalyticsBase
- (instancetype)initWithMaxAttempts:(int32_t)maxAttempts baseDelayMs:(int64_t)baseDelayMs maxDelayMs:(int64_t)maxDelayMs __attribute__((swift_name("init(maxAttempts:baseDelayMs:maxDelayMs:)"))) __attribute__((objc_designated_initializer));

/** Exponential backoff with jitter. [attempt] starts at 0 for the first retry. [random] is in 0..1. */
- (int64_t)delayMillisAttempt:(int32_t)attempt random:(double)random __attribute__((swift_name("delayMillis(attempt:random:)")));
@property (readonly) int32_t maxAttempts __attribute__((swift_name("maxAttempts")));
@end

__attribute__((swift_name("AssetStore")))
@protocol PentabitAnalyticsAssetStore
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)downloadUrl:(NSString *)url key:(NSString *)key maxBytes:(int64_t)maxBytes sha256:(NSString * _Nullable)sha256 completionHandler:(void (^)(id<PentabitAnalyticsAdResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("download(url:key:maxBytes:sha256:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getKey:(NSString *)key completionHandler:(void (^)(PentabitAnalyticsCachedAsset * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("get(key:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)releaseKey:(NSString *)key completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("release(key:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)trimToMaxBytes:(int64_t)maxBytes completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("trimTo(maxBytes:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CachedAsset")))
@interface PentabitAnalyticsCachedAsset : PentabitAnalyticsBase
- (instancetype)initWithKey:(NSString *)key path:(NSString *)path sizeBytes:(int64_t)sizeBytes __attribute__((swift_name("init(key:path:sizeBytes:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsCachedAsset *)doCopyKey:(NSString *)key path:(NSString *)path sizeBytes:(int64_t)sizeBytes __attribute__((swift_name("doCopy(key:path:sizeBytes:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *key __attribute__((swift_name("key")));
@property (readonly) NSString *path __attribute__((swift_name("path")));
@property (readonly) int64_t sizeBytes __attribute__((swift_name("sizeBytes")));
@end

__attribute__((swift_name("Clock")))
@protocol PentabitAnalyticsClock
@required
- (int64_t)nowMillis __attribute__((swift_name("nowMillis()")));
@end

__attribute__((swift_name("ConnectivityMonitor")))
@protocol PentabitAnalyticsConnectivityMonitor
@required
- (BOOL)isOnline __attribute__((swift_name("isOnline()")));
@end

__attribute__((swift_name("DeviceInfo")))
@protocol PentabitAnalyticsDeviceInfo
@required

/** The advertising ID, or null when unavailable, denied or zeroed. Callers must check the privacy mode first.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)advertisingIdWithCompletionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("advertisingId(completionHandler:)")));

/** A random per-install ID kept in app-private storage.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)appInstanceIdWithCompletionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("appInstanceId(completionHandler:)")));

/**
 * A device-level ID: Android's ANDROID_ID, iOS's identifierForVendor. Null when unavailable. Callers must check the privacy mode
 * first, and send it only in NORMAL mode.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deviceIdWithCompletionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("deviceId(completionHandler:)")));
@property (readonly) NSString *appId __attribute__((swift_name("appId")));
@property (readonly) NSString *appVersion __attribute__((swift_name("appVersion")));
@property (readonly) NSString * _Nullable country __attribute__((swift_name("country")));
@property (readonly) NSString *deviceClass __attribute__((swift_name("deviceClass")));
@property (readonly) BOOL isLowPowerMode __attribute__((swift_name("isLowPowerMode")));
@property (readonly) NSString * _Nullable language __attribute__((swift_name("language")));
@property (readonly) NSString *osVersion __attribute__((swift_name("osVersion")));
@property (readonly) NSString *platform __attribute__((swift_name("platform")));
@end

__attribute__((swift_name("EventStore")))
@protocol PentabitAnalyticsEventStore
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)countWithCompletionHandler:(void (^)(PentabitAnalyticsLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("count(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteIds:(NSArray<NSString *> *)ids completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("delete(ids:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteOlderThanTimestampMillis:(int64_t)timestampMillis completionHandler:(void (^)(PentabitAnalyticsInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("deleteOlderThan(timestampMillis:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertEvents:(NSArray<PentabitAnalyticsStoredEvent *> *)events completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("insert(events:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readBatchLimit:(int32_t)limit completionHandler:(void (^)(NSArray<PentabitAnalyticsStoredEvent *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readBatch(limit:completionHandler:)")));

/** Keeps only the newest [maxCount] events. Returns how many were removed.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)trimToMaxCount:(int32_t)maxCount completionHandler:(void (^)(PentabitAnalyticsInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("trimTo(maxCount:completionHandler:)")));
@end

__attribute__((swift_name("HttpClientPort")))
@protocol PentabitAnalyticsHttpClientPort
@required

/** Throws [NetworkException] for transport failures; any HTTP status is returned as a response.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeRequest:(PentabitAnalyticsHttpRequest *)request completionHandler:(void (^)(PentabitAnalyticsHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(request:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("HttpRequest")))
@interface PentabitAnalyticsHttpRequest : PentabitAnalyticsBase
- (instancetype)initWithUrl:(NSString *)url method:(NSString *)method headers:(NSDictionary<NSString *, NSString *> *)headers body:(NSString * _Nullable)body timeoutMillis:(int64_t)timeoutMillis __attribute__((swift_name("init(url:method:headers:body:timeoutMillis:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsHttpRequest *)doCopyUrl:(NSString *)url method:(NSString *)method headers:(NSDictionary<NSString *, NSString *> *)headers body:(NSString * _Nullable)body timeoutMillis:(int64_t)timeoutMillis __attribute__((swift_name("doCopy(url:method:headers:body:timeoutMillis:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable body __attribute__((swift_name("body")));
@property (readonly) NSDictionary<NSString *, NSString *> *headers __attribute__((swift_name("headers")));
@property (readonly) NSString *method __attribute__((swift_name("method")));
@property (readonly) int64_t timeoutMillis __attribute__((swift_name("timeoutMillis")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("HttpResponse")))
@interface PentabitAnalyticsHttpResponse : PentabitAnalyticsBase
- (instancetype)initWithStatus:(int32_t)status headers:(NSDictionary<NSString *, NSString *> *)headers body:(NSString *)body __attribute__((swift_name("init(status:headers:body:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsHttpResponse *)doCopyStatus:(int32_t)status headers:(NSDictionary<NSString *, NSString *> *)headers body:(NSString *)body __attribute__((swift_name("doCopy(status:headers:body:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *body __attribute__((swift_name("body")));
@property (readonly) NSDictionary<NSString *, NSString *> *headers __attribute__((swift_name("headers")));
@property (readonly) int32_t status __attribute__((swift_name("status")));
@end

__attribute__((swift_name("IdGenerator")))
@protocol PentabitAnalyticsIdGenerator
@required
- (NSString *)doNewId __attribute__((swift_name("doNewId()")));
@end

__attribute__((swift_name("KeyValueStore")))
@protocol PentabitAnalyticsKeyValueStore
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getStringKey:(NSString *)key completionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getString(key:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)putStringKey:(NSString *)key value:(NSString *)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("putString(key:value:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeKey:(NSString *)key completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("remove(key:completionHandler:)")));
@end

__attribute__((swift_name("Logger")))
@protocol PentabitAnalyticsLogger
@required
- (void)debugTag:(NSString *)tag message:(NSString *)message __attribute__((swift_name("debug(tag:message:)")));
- (void)errorTag:(NSString *)tag message:(NSString *)message error:(PentabitAnalyticsKotlinThrowable * _Nullable)error __attribute__((swift_name("error(tag:message:error:)")));
- (void)warnTag:(NSString *)tag message:(NSString *)message error:(PentabitAnalyticsKotlinThrowable * _Nullable)error __attribute__((swift_name("warn(tag:message:error:)")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface PentabitAnalyticsKotlinThrowable : PentabitAnalyticsBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(PentabitAnalyticsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(PentabitAnalyticsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (PentabitAnalyticsKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PentabitAnalyticsKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface PentabitAnalyticsKotlinException : PentabitAnalyticsKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(PentabitAnalyticsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(PentabitAnalyticsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NetworkException")))
@interface PentabitAnalyticsNetworkException : PentabitAnalyticsKotlinException
- (instancetype)initWithKind:(PentabitAnalyticsNetworkExceptionKind *)kind message:(NSString *)message __attribute__((swift_name("init(kind:message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(PentabitAnalyticsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(PentabitAnalyticsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (readonly) PentabitAnalyticsNetworkExceptionKind *kind __attribute__((swift_name("kind")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NetworkException.Kind")))
@interface PentabitAnalyticsNetworkExceptionKind : PentabitAnalyticsKotlinEnum<PentabitAnalyticsNetworkExceptionKind *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAnalyticsNetworkExceptionKind *timeout __attribute__((swift_name("timeout")));
@property (class, readonly) PentabitAnalyticsNetworkExceptionKind *noConnection __attribute__((swift_name("noConnection")));
@property (class, readonly) PentabitAnalyticsNetworkExceptionKind *other __attribute__((swift_name("other")));
+ (PentabitAnalyticsKotlinArray<PentabitAnalyticsNetworkExceptionKind *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAnalyticsNetworkExceptionKind *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NoopLogger")))
@interface PentabitAnalyticsNoopLogger : PentabitAnalyticsBase <PentabitAnalyticsLogger>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)noopLogger __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsNoopLogger *shared __attribute__((swift_name("shared")));
- (void)debugTag:(NSString *)tag message:(NSString *)message __attribute__((swift_name("debug(tag:message:)")));
- (void)errorTag:(NSString *)tag message:(NSString *)message error:(PentabitAnalyticsKotlinThrowable * _Nullable)error __attribute__((swift_name("error(tag:message:error:)")));
- (void)warnTag:(NSString *)tag message:(NSString *)message error:(PentabitAnalyticsKotlinThrowable * _Nullable)error __attribute__((swift_name("warn(tag:message:error:)")));
@end


/** Everything the platform layer provides. Core never imports a platform class. */
__attribute__((swift_name("PlatformModule")))
@protocol PentabitAnalyticsPlatformModule
@required
@property (readonly) id<PentabitAnalyticsAssetStore> assetStore __attribute__((swift_name("assetStore")));
@property (readonly) id<PentabitAnalyticsClock> clock __attribute__((swift_name("clock")));
@property (readonly) id<PentabitAnalyticsConnectivityMonitor> connectivity __attribute__((swift_name("connectivity")));
@property (readonly) id<PentabitAnalyticsDeviceInfo> deviceInfo __attribute__((swift_name("deviceInfo")));
@property (readonly) id<PentabitAnalyticsDispatcherProvider> dispatchers __attribute__((swift_name("dispatchers")));
@property (readonly) id<PentabitAnalyticsEventStore> eventStore __attribute__((swift_name("eventStore")));
@property (readonly) id<PentabitAnalyticsHttpClientPort> http __attribute__((swift_name("http")));
@property (readonly) id<PentabitAnalyticsIdGenerator> ids __attribute__((swift_name("ids")));
@property (readonly) id<PentabitAnalyticsKeyValueStore> keyValueStore __attribute__((swift_name("keyValueStore")));
@property (readonly) id<PentabitAnalyticsLogger> logger __attribute__((swift_name("logger")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StoredEvent")))
@interface PentabitAnalyticsStoredEvent : PentabitAnalyticsBase
- (instancetype)initWithId:(NSString *)id createdAtMillis:(int64_t)createdAtMillis payload:(NSString *)payload __attribute__((swift_name("init(id:createdAtMillis:payload:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsStoredEvent *)doCopyId:(NSString *)id createdAtMillis:(int64_t)createdAtMillis payload:(NSString *)payload __attribute__((swift_name("doCopy(id:createdAtMillis:payload:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t createdAtMillis __attribute__((swift_name("createdAtMillis")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString *payload __attribute__((swift_name("payload")));
@end


/** Who the app is made for. Declared once by the app at initialize. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AudienceProfile")))
@interface PentabitAnalyticsAudienceProfile : PentabitAnalyticsKotlinEnum<PentabitAnalyticsAudienceProfile *>
+ (instancetype)alloc __attribute__((unavailable));

/** Who the app is made for. Declared once by the app at initialize. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAnalyticsAudienceProfile *childDirected __attribute__((swift_name("childDirected")));
@property (class, readonly) PentabitAnalyticsAudienceProfile *mixedAudience __attribute__((swift_name("mixedAudience")));
@property (class, readonly) PentabitAnalyticsAudienceProfile *general __attribute__((swift_name("general")));
+ (PentabitAnalyticsKotlinArray<PentabitAnalyticsAudienceProfile *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAnalyticsAudienceProfile *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConsentPolicy")))
@interface PentabitAnalyticsConsentPolicy : PentabitAnalyticsBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/** Returns a reason when nothing may be requested or sent, or null when allowed. */
- (NSString * _Nullable)blockReasonSignals:(PentabitAnalyticsConsentSignals *)signals mode:(PentabitAnalyticsPrivacyMode *)mode __attribute__((swift_name("blockReason(signals:mode:)")));

/**
 * Unknown or missing signals fall to the stricter mode, never the looser one.
 */
- (PentabitAnalyticsPrivacyMode *)modeProfile:(PentabitAnalyticsAudienceProfile *)profile signals:(PentabitAnalyticsConsentSignals *)signals advertisingIdAvailable:(BOOL)advertisingIdAvailable __attribute__((swift_name("mode(profile:signals:advertisingIdAvailable:)")));
@end


/** Signals the publisher (or advertiser) supplies from its own consent and age tools. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConsentSignals")))
@interface PentabitAnalyticsConsentSignals : PentabitAnalyticsBase
- (instancetype)initWithPersonalizedAdsAllowed:(PentabitAnalyticsTriState *)personalizedAdsAllowed gdprApplies:(PentabitAnalyticsTriState *)gdprApplies tcfString:(NSString * _Nullable)tcfString gppString:(NSString * _Nullable)gppString usPrivacyOptOut:(BOOL)usPrivacyOptOut isUnderAgeOfConsent:(PentabitAnalyticsTriState *)isUnderAgeOfConsent userId:(NSString * _Nullable)userId __attribute__((swift_name("init(personalizedAdsAllowed:gdprApplies:tcfString:gppString:usPrivacyOptOut:isUnderAgeOfConsent:userId:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsConsentSignals *)doCopyPersonalizedAdsAllowed:(PentabitAnalyticsTriState *)personalizedAdsAllowed gdprApplies:(PentabitAnalyticsTriState *)gdprApplies tcfString:(NSString * _Nullable)tcfString gppString:(NSString * _Nullable)gppString usPrivacyOptOut:(BOOL)usPrivacyOptOut isUnderAgeOfConsent:(PentabitAnalyticsTriState *)isUnderAgeOfConsent userId:(NSString * _Nullable)userId __attribute__((swift_name("doCopy(personalizedAdsAllowed:gdprApplies:tcfString:gppString:usPrivacyOptOut:isUnderAgeOfConsent:userId:)")));

/** Signals the publisher (or advertiser) supplies from its own consent and age tools. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** Signals the publisher (or advertiser) supplies from its own consent and age tools. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** Signals the publisher (or advertiser) supplies from its own consent and age tools. */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PentabitAnalyticsTriState *gdprApplies __attribute__((swift_name("gdprApplies")));
@property (readonly) NSString * _Nullable gppString __attribute__((swift_name("gppString")));
@property (readonly) PentabitAnalyticsTriState *isUnderAgeOfConsent __attribute__((swift_name("isUnderAgeOfConsent")));
@property (readonly) PentabitAnalyticsTriState *personalizedAdsAllowed __attribute__((swift_name("personalizedAdsAllowed")));
@property (readonly) NSString * _Nullable tcfString __attribute__((swift_name("tcfString")));
@property (readonly) BOOL usPrivacyOptOut __attribute__((swift_name("usPrivacyOptOut")));
@property (readonly) NSString * _Nullable userId __attribute__((swift_name("userId")));
@end


/** What the SDK may collect, send and show for the current user. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrivacyMode")))
@interface PentabitAnalyticsPrivacyMode : PentabitAnalyticsKotlinEnum<PentabitAnalyticsPrivacyMode *>
+ (instancetype)alloc __attribute__((unavailable));

/** What the SDK may collect, send and show for the current user. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAnalyticsPrivacyMode *normal __attribute__((swift_name("normal")));
@property (class, readonly) PentabitAnalyticsPrivacyMode *nonPersonalized __attribute__((swift_name("nonPersonalized")));
@property (class, readonly) PentabitAnalyticsPrivacyMode *childDirected __attribute__((swift_name("childDirected")));
+ (PentabitAnalyticsKotlinArray<PentabitAnalyticsPrivacyMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAnalyticsPrivacyMode *> *entries __attribute__((swift_name("entries")));
@property (readonly) BOOL allowAdvertisingId __attribute__((swift_name("allowAdvertisingId")));
@property (readonly) BOOL allowUserId __attribute__((swift_name("allowUserId")));
@property (readonly) BOOL analyticsActionsAllowed __attribute__((swift_name("analyticsActionsAllowed")));
@property (readonly) BOOL persistentEventId __attribute__((swift_name("persistentEventId")));
@property (readonly) BOOL personalized __attribute__((swift_name("personalized")));
@end


/** Holds the current audience profile and consent signals, and computes the mode on demand. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrivacyState")))
@interface PentabitAnalyticsPrivacyState : PentabitAnalyticsBase
- (instancetype)initWithProfile:(PentabitAnalyticsAudienceProfile *)profile deviceInfo:(id<PentabitAnalyticsDeviceInfo>)deviceInfo policy:(PentabitAnalyticsConsentPolicy *)policy __attribute__((swift_name("init(profile:deviceInfo:policy:)"))) __attribute__((objc_designated_initializer));
- (NSString * _Nullable)blockReasonMode:(PentabitAnalyticsPrivacyMode *)mode __attribute__((swift_name("blockReason(mode:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)currentModeWithCompletionHandler:(void (^)(PentabitAnalyticsPrivacyMode * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("currentMode(completionHandler:)")));
- (void)updateSignals:(PentabitAnalyticsConsentSignals *)signals __attribute__((swift_name("update(signals:)")));
@property (readonly) PentabitAnalyticsAudienceProfile *profile __attribute__((swift_name("profile")));
@property (readonly) id<PentabitAnalyticsKotlinx_coroutines_coreStateFlow> signals __attribute__((swift_name("signals")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TriState")))
@interface PentabitAnalyticsTriState : PentabitAnalyticsKotlinEnum<PentabitAnalyticsTriState *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAnalyticsTriState *true_ __attribute__((swift_name("true_")));
@property (class, readonly) PentabitAnalyticsTriState *false_ __attribute__((swift_name("false_")));
@property (class, readonly) PentabitAnalyticsTriState *unknown __attribute__((swift_name("unknown")));
+ (PentabitAnalyticsKotlinArray<PentabitAnalyticsTriState *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAnalyticsTriState *> *entries __attribute__((swift_name("entries")));
@end


/**
 * The page the platform WebView loads over a video: a transparent document with one sandboxed iframe holding the SIMID creative.
 * Messages the creative posts are passed to the platform as "simid:" + the raw JSON (through the same AksNative / webkit "aks" bridge the
 * MRAID pages use), and the platform sends player messages back by running [deliver].
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SimidHost")))
@interface PentabitAnalyticsSimidHost : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * The page the platform WebView loads over a video: a transparent document with one sandboxed iframe holding the SIMID creative.
 * Messages the creative posts are passed to the platform as "simid:" + the raw JSON (through the same AksNative / webkit "aks" bridge the
 * MRAID pages use), and the platform sends player messages back by running [deliver].
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)simidHost __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsSimidHost *shared __attribute__((swift_name("shared")));

/** JavaScript that delivers [json] to the creative. */
- (NSString *)deliverJson:(NSString *)json __attribute__((swift_name("deliver(json:)")));

/** [iframeSrc] is the cached overlay page served from the asset host. The sandbox gives the creative an opaque origin (cross-origin, as SIMID requires). */
- (NSString *)pageIframeSrc:(NSString *)iframeSrc __attribute__((swift_name("page(iframeSrc:)")));
@property (readonly) NSString *PREFIX __attribute__((swift_name("PREFIX")));
@end


/**
 * The player (host) side of SIMID for one video ad. The platform screen shows an iframe over the video, hands every message the iframe posts to
 * [onRaw] and delivers everything [send] emits to the iframe. All decisions live here, so Android and iOS behave the same and it can be tested.
 *
 * UNVERIFIED against SIMID 1.2 section 8 (messaging protocol) when written: the envelope {sessionId, messageId, type, timestamp, args}, the
 * createSession handshake (the creative creates the session and the player answers `resolve`), and the resolve/reject shape
 * (args = {messageId: <id answered>, value}) follow the author's recollection of the spec. The message names and their arguments
 * (Player:init, startCreative, adStopped, adSkipped, Creative:requestNavigation, clickThru, getMediaState, ...) come from the spec text
 * read for this work. Check the envelope against section 8 before relying on third-party SIMID creatives.
 *
 * Not implemented: SIMID:Media:* events, requestPause/Play/ChangeVolume/Fullscreen/Resize/ChangeAdDuration/expandNonlinear (all rejected,
 * because variableDurationAllowed and fullscreenAllowed are false).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SimidSession")))
@interface PentabitAnalyticsSimidSession : PentabitAnalyticsBase
- (instancetype)initWithEnv:(PentabitAnalyticsSimidSessionEnvironment *)env creativeData:(PentabitAnalyticsSimidSessionCreativeData *)creativeData now:(PentabitAnalyticsLong *(^)(void))now send:(void (^)(NSString *))send mediaState:(PentabitAnalyticsSimidSessionMediaState *(^)(void))mediaState listener:(id<PentabitAnalyticsSimidSessionListener>)listener __attribute__((swift_name("init(env:creativeData:now:send:mediaState:listener:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAnalyticsSimidSessionCompanion *companion __attribute__((swift_name("companion")));

/** The user skipped with the player's Skip control. */
- (void)adSkipped __attribute__((swift_name("adSkipped()")));

/** The ad ended for another reason. Codes: 1 user close, 2 media complete, 3 player closed before completion, 4 creative closed. */
- (void)adStoppedCode:(int32_t)code __attribute__((swift_name("adStopped(code:)")));
- (void)appBackgrounded __attribute__((swift_name("appBackgrounded()")));
- (void)appForegrounded __attribute__((swift_name("appForegrounded()")));

/** Call when the first video frame is on screen. */
- (void)mediaStarted __attribute__((swift_name("mediaStarted()")));
- (void)onRawRaw:(NSString *)raw __attribute__((swift_name("onRaw(raw:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SimidSession.Companion")))
@interface PentabitAnalyticsSimidSessionCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsSimidSessionCompanion *shared __attribute__((swift_name("shared")));

/** Formats a skip offset in ms as HH:MM:SS.mmm (SIMID environmentData.skipoffset). */
- (NSString *)clockMs:(int64_t)ms __attribute__((swift_name("clock(ms:)")));

/** The key the cached overlay page is served under to the host page (".html" so it is served as text/html). */
@property (readonly) NSString *ASSET_KEY __attribute__((swift_name("ASSET_KEY")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SimidSession.CreativeData")))
@interface PentabitAnalyticsSimidSessionCreativeData : PentabitAnalyticsBase
- (instancetype)initWithAdParameters:(NSString *)adParameters clickThruUrl:(NSString * _Nullable)clickThruUrl __attribute__((swift_name("init(adParameters:clickThruUrl:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *adParameters __attribute__((swift_name("adParameters")));
@property (readonly) NSString * _Nullable clickThruUrl __attribute__((swift_name("clickThruUrl")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SimidSession.Environment")))
@interface PentabitAnalyticsSimidSessionEnvironment : PentabitAnalyticsBase
- (instancetype)initWithAppId:(NSString *)appId videoWidth:(int32_t)videoWidth videoHeight:(int32_t)videoHeight creativeX:(int32_t)creativeX creativeY:(int32_t)creativeY creativeWidth:(int32_t)creativeWidth creativeHeight:(int32_t)creativeHeight skippableState:(NSString *)skippableState skipOffset:(NSString * _Nullable)skipOffset version:(NSString *)version __attribute__((swift_name("init(appId:videoWidth:videoHeight:creativeX:creativeY:creativeWidth:creativeHeight:skippableState:skipOffset:version:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *appId __attribute__((swift_name("appId")));
@property (readonly) int32_t creativeHeight __attribute__((swift_name("creativeHeight")));
@property (readonly) int32_t creativeWidth __attribute__((swift_name("creativeWidth")));
@property (readonly) int32_t creativeX __attribute__((swift_name("creativeX")));
@property (readonly) int32_t creativeY __attribute__((swift_name("creativeY")));
@property (readonly) NSString * _Nullable skipOffset __attribute__((swift_name("skipOffset")));

/** "playerHandles" when the player draws a skip control (a skipoffset exists), else "notSkippable". */
@property (readonly) NSString *skippableState __attribute__((swift_name("skippableState")));
@property (readonly) NSString *version __attribute__((swift_name("version")));
@property (readonly) int32_t videoHeight __attribute__((swift_name("videoHeight")));
@property (readonly) int32_t videoWidth __attribute__((swift_name("videoWidth")));
@end

__attribute__((swift_name("SimidSessionListener")))
@protocol PentabitAnalyticsSimidSessionListener
@required

/** The creative rejected init or startCreative, or sent a fatalError: remove the iframe; the video goes on. */
- (void)onFailedReason:(NSString *)reason __attribute__((swift_name("onFailed(reason:)")));

/** The creative asked the player to open [uri] after a user tap (SIMID:Creative:requestNavigation or clickThru with playerHandles). */
- (void)onNavigateUri:(NSString *)uri __attribute__((swift_name("onNavigate(uri:)")));

/** The creative resolved startCreative: show the iframe now. */
- (void)onShow __attribute__((swift_name("onShow()")));

/** SIMID:Creative:reportTracking. */
- (void)onTrackUrls:(NSArray<NSString *> *)urls __attribute__((swift_name("onTrack(urls:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SimidSession.MediaState")))
@interface PentabitAnalyticsSimidSessionMediaState : PentabitAnalyticsBase
- (instancetype)initWithCurrentTimeSec:(double)currentTimeSec durationSec:(double)durationSec ended:(BOOL)ended paused:(BOOL)paused muted:(BOOL)muted volume:(double)volume __attribute__((swift_name("init(currentTimeSec:durationSec:ended:paused:muted:volume:)"))) __attribute__((objc_designated_initializer));
@property (readonly) double currentTimeSec __attribute__((swift_name("currentTimeSec")));
@property (readonly) double durationSec __attribute__((swift_name("durationSec")));
@property (readonly) BOOL ended __attribute__((swift_name("ended")));
@property (readonly) BOOL muted __attribute__((swift_name("muted")));
@property (readonly) BOOL paused __attribute__((swift_name("paused")));
@property (readonly) double volume __attribute__((swift_name("volume")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FakeAssetStore")))
@interface PentabitAnalyticsFakeAssetStore : PentabitAnalyticsBase <PentabitAnalyticsAssetStore>
- (instancetype)initWithFailWith:(NSString * _Nullable)failWith __attribute__((swift_name("init(failWith:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)downloadUrl:(NSString *)url key:(NSString *)key maxBytes:(int64_t)maxBytes sha256:(NSString * _Nullable)sha256 completionHandler:(void (^)(id<PentabitAnalyticsAdResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("download(url:key:maxBytes:sha256:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getKey:(NSString *)key completionHandler:(void (^)(PentabitAnalyticsCachedAsset * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("get(key:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)releaseKey:(NSString *)key completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("release(key:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)trimToMaxBytes:(int64_t)maxBytes completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("trimTo(maxBytes:completionHandler:)")));
@property (readonly) NSMutableArray<NSString *> *downloaded __attribute__((swift_name("downloaded")));
@property NSString * _Nullable failWith __attribute__((swift_name("failWith")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FakeClock")))
@interface PentabitAnalyticsFakeClock : PentabitAnalyticsBase <PentabitAnalyticsClock>
- (instancetype)initWithNow:(int64_t)now __attribute__((swift_name("init(now:)"))) __attribute__((objc_designated_initializer));
- (void)advanceMs:(int64_t)ms __attribute__((swift_name("advance(ms:)")));
- (int64_t)nowMillis __attribute__((swift_name("nowMillis()")));
@property int64_t now __attribute__((swift_name("now")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FakeConnectivity")))
@interface PentabitAnalyticsFakeConnectivity : PentabitAnalyticsBase <PentabitAnalyticsConnectivityMonitor>
- (instancetype)initWithOnline:(BOOL)online __attribute__((swift_name("init(online:)"))) __attribute__((objc_designated_initializer));
- (BOOL)isOnline __attribute__((swift_name("isOnline()")));
@property BOOL online __attribute__((swift_name("online")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FakeDeviceInfo")))
@interface PentabitAnalyticsFakeDeviceInfo : PentabitAnalyticsBase <PentabitAnalyticsDeviceInfo>
- (instancetype)initWithAdId:(NSString * _Nullable)adId platform:(NSString *)platform __attribute__((swift_name("init(adId:platform:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)advertisingIdWithCompletionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("advertisingId(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)appInstanceIdWithCompletionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("appInstanceId(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deviceIdWithCompletionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("deviceId(completionHandler:)")));
@property NSString * _Nullable adId __attribute__((swift_name("adId")));
@property (readonly) NSString *appId __attribute__((swift_name("appId")));
@property (readonly) NSString *appVersion __attribute__((swift_name("appVersion")));
@property (readonly) NSString * _Nullable country __attribute__((swift_name("country")));
@property (readonly) NSString *deviceClass __attribute__((swift_name("deviceClass")));
@property (readonly) BOOL isLowPowerMode __attribute__((swift_name("isLowPowerMode")));
@property (readonly) NSString * _Nullable language __attribute__((swift_name("language")));
@property (readonly) NSString *osVersion __attribute__((swift_name("osVersion")));
@property (readonly) NSString *platform __attribute__((swift_name("platform")));
@end


/** A scriptable HTTP client. [handler] decides each response; throw [NetworkException] to simulate transport errors. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FakeHttp")))
@interface PentabitAnalyticsFakeHttp : PentabitAnalyticsBase <PentabitAnalyticsHttpClientPort>
- (instancetype)initWithHandler:(PentabitAnalyticsHttpResponse *(^)(PentabitAnalyticsHttpRequest *))handler __attribute__((swift_name("init(handler:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeRequest:(PentabitAnalyticsHttpRequest *)request completionHandler:(void (^)(PentabitAnalyticsHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(request:completionHandler:)")));
@property PentabitAnalyticsHttpResponse *(^handler)(PentabitAnalyticsHttpRequest *) __attribute__((swift_name("handler")));
@property (readonly) NSMutableArray<PentabitAnalyticsHttpRequest *> *requests __attribute__((swift_name("requests")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FakePlatform")))
@interface PentabitAnalyticsFakePlatform : PentabitAnalyticsBase <PentabitAnalyticsPlatformModule>
- (instancetype)initWithDispatcher:(PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher clock:(PentabitAnalyticsFakeClock *)clock http:(PentabitAnalyticsFakeHttp *)http eventStore:(PentabitAnalyticsInMemoryEventStore *)eventStore keyValueStore:(PentabitAnalyticsInMemoryKeyValueStore *)keyValueStore assetStore:(PentabitAnalyticsFakeAssetStore *)assetStore connectivity:(PentabitAnalyticsFakeConnectivity *)connectivity deviceInfo:(PentabitAnalyticsFakeDeviceInfo *)deviceInfo __attribute__((swift_name("init(dispatcher:clock:http:eventStore:keyValueStore:assetStore:connectivity:deviceInfo:)"))) __attribute__((objc_designated_initializer));
@property (readonly) PentabitAnalyticsFakeAssetStore *assetStore __attribute__((swift_name("assetStore")));
@property (readonly) PentabitAnalyticsFakeClock *clock __attribute__((swift_name("clock")));
@property (readonly) PentabitAnalyticsFakeConnectivity *connectivity __attribute__((swift_name("connectivity")));
@property (readonly) PentabitAnalyticsFakeDeviceInfo *deviceInfo __attribute__((swift_name("deviceInfo")));
@property (readonly) id<PentabitAnalyticsDispatcherProvider> dispatchers __attribute__((swift_name("dispatchers")));
@property (readonly) PentabitAnalyticsInMemoryEventStore *eventStore __attribute__((swift_name("eventStore")));
@property (readonly) PentabitAnalyticsFakeHttp *http __attribute__((swift_name("http")));
@property (readonly) id<PentabitAnalyticsIdGenerator> ids __attribute__((swift_name("ids")));
@property (readonly) PentabitAnalyticsInMemoryKeyValueStore *keyValueStore __attribute__((swift_name("keyValueStore")));
@property (readonly) id<PentabitAnalyticsLogger> logger __attribute__((swift_name("logger")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InMemoryEventStore")))
@interface PentabitAnalyticsInMemoryEventStore : PentabitAnalyticsBase <PentabitAnalyticsEventStore>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)countWithCompletionHandler:(void (^)(PentabitAnalyticsLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("count(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteIds:(NSArray<NSString *> *)ids completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("delete(ids:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteOlderThanTimestampMillis:(int64_t)timestampMillis completionHandler:(void (^)(PentabitAnalyticsInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("deleteOlderThan(timestampMillis:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertEvents:(NSArray<PentabitAnalyticsStoredEvent *> *)events completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("insert(events:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readBatchLimit:(int32_t)limit completionHandler:(void (^)(NSArray<PentabitAnalyticsStoredEvent *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readBatch(limit:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)trimToMaxCount:(int32_t)maxCount completionHandler:(void (^)(PentabitAnalyticsInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("trimTo(maxCount:completionHandler:)")));
@property (readonly) NSMutableArray<PentabitAnalyticsStoredEvent *> *rows __attribute__((swift_name("rows")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InMemoryKeyValueStore")))
@interface PentabitAnalyticsInMemoryKeyValueStore : PentabitAnalyticsBase <PentabitAnalyticsKeyValueStore>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getStringKey:(NSString *)key completionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getString(key:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)putStringKey:(NSString *)key value:(NSString *)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("putString(key:value:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeKey:(NSString *)key completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("remove(key:completionHandler:)")));
@property (readonly) PentabitAnalyticsMutableDictionary<NSString *, NSString *> *map __attribute__((swift_name("map")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SequentialIds")))
@interface PentabitAnalyticsSequentialIds : PentabitAnalyticsBase <PentabitAnalyticsIdGenerator>
- (instancetype)initWithPrefix:(NSString *)prefix __attribute__((swift_name("init(prefix:)"))) __attribute__((objc_designated_initializer));
- (NSString *)doNewId __attribute__((swift_name("doNewId()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TestDispatchers")))
@interface PentabitAnalyticsTestDispatchers : PentabitAnalyticsBase <PentabitAnalyticsDispatcherProvider>
- (instancetype)initWithDispatcher:(PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher __attribute__((swift_name("init(dispatcher:)"))) __attribute__((objc_designated_initializer));
@property (readonly, getter=default) PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcher *default_ __attribute__((swift_name("default_")));
@property (readonly) PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcher *io __attribute__((swift_name("io")));
@property (readonly) PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcher *main __attribute__((swift_name("main")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SystemIds")))
@interface PentabitAnalyticsSystemIds : PentabitAnalyticsBase <PentabitAnalyticsIdGenerator>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)systemIds __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsSystemIds *shared __attribute__((swift_name("shared")));
- (NSString *)doNewId __attribute__((swift_name("doNewId()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MediaSelector")))
@interface PentabitAnalyticsMediaSelector : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)mediaSelector __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsMediaSelector *shared __attribute__((swift_name("shared")));

/** MP4 only in v1. Prefers the highest bitrate at or below the cap, else the lowest available. */
- (PentabitAnalyticsVastMedia * _Nullable)pickFiles:(NSArray<PentabitAnalyticsVastMedia *> *)files maxBitrateKbps:(int32_t)maxBitrateKbps __attribute__((swift_name("pick(files:maxBitrateKbps:)")));
@end


/** A wrapper chain collapsed into one playable ad. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ResolvedVast")))
@interface PentabitAnalyticsResolvedVast : PentabitAnalyticsBase
- (instancetype)initWithImpressions:(NSArray<NSString *> *)impressions errors:(NSArray<NSString *> *)errors durationMs:(int64_t)durationMs skipOffsetMs:(PentabitAnalyticsLong * _Nullable)skipOffsetMs media:(PentabitAnalyticsVastMedia *)media tracking:(NSArray<PentabitAnalyticsVastTracking *> *)tracking clickThrough:(NSString * _Nullable)clickThrough clickTracking:(NSArray<NSString *> *)clickTracking companion:(PentabitAnalyticsVastCompanion * _Nullable)companion interactive:(PentabitAnalyticsVastInteractive * _Nullable)interactive __attribute__((swift_name("init(impressions:errors:durationMs:skipOffsetMs:media:tracking:clickThrough:clickTracking:companion:interactive:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsResolvedVast *)doCopyImpressions:(NSArray<NSString *> *)impressions errors:(NSArray<NSString *> *)errors durationMs:(int64_t)durationMs skipOffsetMs:(PentabitAnalyticsLong * _Nullable)skipOffsetMs media:(PentabitAnalyticsVastMedia *)media tracking:(NSArray<PentabitAnalyticsVastTracking *> *)tracking clickThrough:(NSString * _Nullable)clickThrough clickTracking:(NSArray<NSString *> *)clickTracking companion:(PentabitAnalyticsVastCompanion * _Nullable)companion interactive:(PentabitAnalyticsVastInteractive * _Nullable)interactive __attribute__((swift_name("doCopy(impressions:errors:durationMs:skipOffsetMs:media:tracking:clickThrough:clickTracking:companion:interactive:)")));

/** A wrapper chain collapsed into one playable ad. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** A wrapper chain collapsed into one playable ad. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** A wrapper chain collapsed into one playable ad. */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable clickThrough __attribute__((swift_name("clickThrough")));
@property (readonly) NSArray<NSString *> *clickTracking __attribute__((swift_name("clickTracking")));
@property (readonly) PentabitAnalyticsVastCompanion * _Nullable companion __attribute__((swift_name("companion")));
@property (readonly) int64_t durationMs __attribute__((swift_name("durationMs")));
@property (readonly) NSArray<NSString *> *errors __attribute__((swift_name("errors")));
@property (readonly) NSArray<NSString *> *impressions __attribute__((swift_name("impressions")));
@property (readonly) PentabitAnalyticsVastInteractive * _Nullable interactive __attribute__((swift_name("interactive")));
@property (readonly) PentabitAnalyticsVastMedia *media __attribute__((swift_name("media")));
@property (readonly) PentabitAnalyticsLong * _Nullable skipOffsetMs __attribute__((swift_name("skipOffsetMs")));
@property (readonly) NSArray<PentabitAnalyticsVastTracking *> *tracking __attribute__((swift_name("tracking")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastAd")))
@interface PentabitAnalyticsVastAd : PentabitAnalyticsBase
- (instancetype)initWithIsWrapper:(BOOL)isWrapper wrapperUrl:(NSString * _Nullable)wrapperUrl impressions:(NSArray<NSString *> *)impressions errors:(NSArray<NSString *> *)errors linear:(PentabitAnalyticsVastLinear * _Nullable)linear companions:(NSArray<PentabitAnalyticsVastCompanion *> *)companions __attribute__((swift_name("init(isWrapper:wrapperUrl:impressions:errors:linear:companions:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsVastAd *)doCopyIsWrapper:(BOOL)isWrapper wrapperUrl:(NSString * _Nullable)wrapperUrl impressions:(NSArray<NSString *> *)impressions errors:(NSArray<NSString *> *)errors linear:(PentabitAnalyticsVastLinear * _Nullable)linear companions:(NSArray<PentabitAnalyticsVastCompanion *> *)companions __attribute__((swift_name("doCopy(isWrapper:wrapperUrl:impressions:errors:linear:companions:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<PentabitAnalyticsVastCompanion *> *companions __attribute__((swift_name("companions")));
@property (readonly) NSArray<NSString *> *errors __attribute__((swift_name("errors")));
@property (readonly) NSArray<NSString *> *impressions __attribute__((swift_name("impressions")));
@property (readonly) BOOL isWrapper __attribute__((swift_name("isWrapper")));
@property (readonly) PentabitAnalyticsVastLinear * _Nullable linear __attribute__((swift_name("linear")));
@property (readonly) NSString * _Nullable wrapperUrl __attribute__((swift_name("wrapperUrl")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastCompanion")))
@interface PentabitAnalyticsVastCompanion : PentabitAnalyticsBase
- (instancetype)initWithWidth:(int32_t)width height:(int32_t)height resourceType:(NSString *)resourceType resource:(NSString *)resource creativeType:(NSString * _Nullable)creativeType clickThrough:(NSString * _Nullable)clickThrough clickTracking:(NSArray<NSString *> *)clickTracking tracking:(NSArray<PentabitAnalyticsVastTracking *> *)tracking __attribute__((swift_name("init(width:height:resourceType:resource:creativeType:clickThrough:clickTracking:tracking:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsVastCompanion *)doCopyWidth:(int32_t)width height:(int32_t)height resourceType:(NSString *)resourceType resource:(NSString *)resource creativeType:(NSString * _Nullable)creativeType clickThrough:(NSString * _Nullable)clickThrough clickTracking:(NSArray<NSString *> *)clickTracking tracking:(NSArray<PentabitAnalyticsVastTracking *> *)tracking __attribute__((swift_name("doCopy(width:height:resourceType:resource:creativeType:clickThrough:clickTracking:tracking:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable clickThrough __attribute__((swift_name("clickThrough")));
@property (readonly) NSArray<NSString *> *clickTracking __attribute__((swift_name("clickTracking")));
@property (readonly) NSString * _Nullable creativeType __attribute__((swift_name("creativeType")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) NSString *resource __attribute__((swift_name("resource")));

/** "html", "static" or "iframe". */
@property (readonly) NSString *resourceType __attribute__((swift_name("resourceType")));
@property (readonly) NSArray<PentabitAnalyticsVastTracking *> *tracking __attribute__((swift_name("tracking")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end


/** Names of VAST tracking events the player reports. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastEvents")))
@interface PentabitAnalyticsVastEvents : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));

/** Names of VAST tracking events the player reports. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)vastEvents __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsVastEvents *shared __attribute__((swift_name("shared")));

/** The Pentabit event that matches a VAST event, if any. */
- (NSString * _Nullable)toPentabitEventVastEvent:(NSString *)vastEvent __attribute__((swift_name("toPentabitEvent(vastEvent:)")));
@property (readonly) NSString *CLOSE __attribute__((swift_name("CLOSE")));
@property (readonly) NSString *COMPLETE __attribute__((swift_name("COMPLETE")));
@property (readonly) NSString *CREATIVE_VIEW __attribute__((swift_name("CREATIVE_VIEW")));
@property (readonly) NSString *FIRST_QUARTILE __attribute__((swift_name("FIRST_QUARTILE")));
@property (readonly) NSString *MIDPOINT __attribute__((swift_name("MIDPOINT")));
@property (readonly) NSString *MUTE __attribute__((swift_name("MUTE")));
@property (readonly) NSString *PAUSE __attribute__((swift_name("PAUSE")));
@property (readonly) NSString *RESUME __attribute__((swift_name("RESUME")));
@property (readonly) NSString *SKIP __attribute__((swift_name("SKIP")));
@property (readonly) NSString *START __attribute__((swift_name("START")));
@property (readonly) NSString *THIRD_QUARTILE __attribute__((swift_name("THIRD_QUARTILE")));
@property (readonly) NSString *UNMUTE __attribute__((swift_name("UNMUTE")));
@end


/** A SIMID interactive creative from <InteractiveCreativeFile>: HTML the player runs in an iframe over the video. [adParameters] is the VAST <AdParameters> text. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastInteractive")))
@interface PentabitAnalyticsVastInteractive : PentabitAnalyticsBase
- (instancetype)initWithUrl:(NSString *)url apiFramework:(NSString *)apiFramework variableDuration:(BOOL)variableDuration adParameters:(NSString * _Nullable)adParameters __attribute__((swift_name("init(url:apiFramework:variableDuration:adParameters:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsVastInteractive *)doCopyUrl:(NSString *)url apiFramework:(NSString *)apiFramework variableDuration:(BOOL)variableDuration adParameters:(NSString * _Nullable)adParameters __attribute__((swift_name("doCopy(url:apiFramework:variableDuration:adParameters:)")));

/** A SIMID interactive creative from <InteractiveCreativeFile>: HTML the player runs in an iframe over the video. [adParameters] is the VAST <AdParameters> text. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** A SIMID interactive creative from <InteractiveCreativeFile>: HTML the player runs in an iframe over the video. [adParameters] is the VAST <AdParameters> text. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** A SIMID interactive creative from <InteractiveCreativeFile>: HTML the player runs in an iframe over the video. [adParameters] is the VAST <AdParameters> text. */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable adParameters __attribute__((swift_name("adParameters")));
@property (readonly) NSString *apiFramework __attribute__((swift_name("apiFramework")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@property (readonly) BOOL variableDuration __attribute__((swift_name("variableDuration")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastLinear")))
@interface PentabitAnalyticsVastLinear : PentabitAnalyticsBase
- (instancetype)initWithDurationMs:(PentabitAnalyticsLong * _Nullable)durationMs skipOffset:(NSString * _Nullable)skipOffset mediaFiles:(NSArray<PentabitAnalyticsVastMedia *> *)mediaFiles tracking:(NSArray<PentabitAnalyticsVastTracking *> *)tracking clickThrough:(NSString * _Nullable)clickThrough clickTracking:(NSArray<NSString *> *)clickTracking interactive:(PentabitAnalyticsVastInteractive * _Nullable)interactive __attribute__((swift_name("init(durationMs:skipOffset:mediaFiles:tracking:clickThrough:clickTracking:interactive:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsVastLinear *)doCopyDurationMs:(PentabitAnalyticsLong * _Nullable)durationMs skipOffset:(NSString * _Nullable)skipOffset mediaFiles:(NSArray<PentabitAnalyticsVastMedia *> *)mediaFiles tracking:(NSArray<PentabitAnalyticsVastTracking *> *)tracking clickThrough:(NSString * _Nullable)clickThrough clickTracking:(NSArray<NSString *> *)clickTracking interactive:(PentabitAnalyticsVastInteractive * _Nullable)interactive __attribute__((swift_name("doCopy(durationMs:skipOffset:mediaFiles:tracking:clickThrough:clickTracking:interactive:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable clickThrough __attribute__((swift_name("clickThrough")));
@property (readonly) NSArray<NSString *> *clickTracking __attribute__((swift_name("clickTracking")));
@property (readonly) PentabitAnalyticsLong * _Nullable durationMs __attribute__((swift_name("durationMs")));
@property (readonly) PentabitAnalyticsVastInteractive * _Nullable interactive __attribute__((swift_name("interactive")));
@property (readonly) NSArray<PentabitAnalyticsVastMedia *> *mediaFiles __attribute__((swift_name("mediaFiles")));
@property (readonly) NSString * _Nullable skipOffset __attribute__((swift_name("skipOffset")));
@property (readonly) NSArray<PentabitAnalyticsVastTracking *> *tracking __attribute__((swift_name("tracking")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastMedia")))
@interface PentabitAnalyticsVastMedia : PentabitAnalyticsBase
- (instancetype)initWithUrl:(NSString *)url mime:(NSString *)mime width:(int32_t)width height:(int32_t)height bitrateKbps:(PentabitAnalyticsInt * _Nullable)bitrateKbps delivery:(NSString *)delivery __attribute__((swift_name("init(url:mime:width:height:bitrateKbps:delivery:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsVastMedia *)doCopyUrl:(NSString *)url mime:(NSString *)mime width:(int32_t)width height:(int32_t)height bitrateKbps:(PentabitAnalyticsInt * _Nullable)bitrateKbps delivery:(NSString *)delivery __attribute__((swift_name("doCopy(url:mime:width:height:bitrateKbps:delivery:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PentabitAnalyticsInt * _Nullable bitrateKbps __attribute__((swift_name("bitrateKbps")));
@property (readonly) NSString *delivery __attribute__((swift_name("delivery")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) NSString *mime __attribute__((swift_name("mime")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end


/** Parses one VAST 2.0 to 4.x document into its first ad. Ad pods are not used in v1. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastParser")))
@interface PentabitAnalyticsVastParser : PentabitAnalyticsBase

/** Parses one VAST 2.0 to 4.x document into its first ad. Ad pods are not used in v1. */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/** Parses one VAST 2.0 to 4.x document into its first ad. Ad pods are not used in v1. */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) PentabitAnalyticsVastParserCompanion *companion __attribute__((swift_name("companion")));
- (id<PentabitAnalyticsAdResult>)parseXml:(NSString *)xml __attribute__((swift_name("parse(xml:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastParser.Companion")))
@interface PentabitAnalyticsVastParserCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsVastParserCompanion *shared __attribute__((swift_name("shared")));

/** Parses "HH:MM:SS" or "HH:MM:SS.mmm" into milliseconds. */
- (PentabitAnalyticsLong * _Nullable)parseTimeMsValue:(NSString *)value __attribute__((swift_name("parseTimeMs(value:)")));
@end


/**
 * Follows a wrapper chain with a depth limit and an overall timeout, then returns one playable ad.
 * Impressions, errors and tracking from every wrapper are merged into the final ad.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastResolver")))
@interface PentabitAnalyticsVastResolver : PentabitAnalyticsBase
- (instancetype)initWithHttp:(id<PentabitAnalyticsHttpClientPort>)http parser:(PentabitAnalyticsVastParser *)parser pixels:(PentabitAnalyticsPixelClient *)pixels maxDepth:(int32_t)maxDepth timeoutMs:(int64_t)timeoutMs maxBitrateKbps:(int32_t)maxBitrateKbps __attribute__((swift_name("init(http:parser:pixels:maxDepth:timeoutMs:maxBitrateKbps:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)resolveXml:(NSString * _Nullable)xml url:(NSString * _Nullable)url completionHandler:(void (^)(id<PentabitAnalyticsAdResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("resolve(xml:url:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastTracking")))
@interface PentabitAnalyticsVastTracking : PentabitAnalyticsBase
- (instancetype)initWithEvent:(NSString *)event url:(NSString *)url offset:(NSString * _Nullable)offset __attribute__((swift_name("init(event:url:offset:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsVastTracking *)doCopyEvent:(NSString *)event url:(NSString *)url offset:(NSString * _Nullable)offset __attribute__((swift_name("doCopy(event:url:offset:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *event __attribute__((swift_name("event")));
@property (readonly) NSString * _Nullable offset __attribute__((swift_name("offset")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end


/**
 * Turns real playback position into quartile events. Each milestone fires once. Pausing or
 * seeking back never fires a milestone twice, and seeking past one fires it at the next update.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VideoProgressTracker")))
@interface PentabitAnalyticsVideoProgressTracker : PentabitAnalyticsBase
- (instancetype)initWithDurationMs:(int64_t)durationMs emit:(void (^)(NSString *))emit __attribute__((swift_name("init(durationMs:emit:)"))) __attribute__((objc_designated_initializer));
- (void)onCompleted __attribute__((swift_name("onCompleted()")));
- (void)onPositionPositionMs:(int64_t)positionMs __attribute__((swift_name("onPosition(positionMs:)")));
@property (readonly) BOOL isCompleted __attribute__((swift_name("isCompleted")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlatformContext")))
@interface PentabitAnalyticsPlatformContext : PentabitAnalyticsBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Event")))
@interface PentabitAnalyticsEvent : PentabitAnalyticsBase
- (instancetype)initWithId:(NSString *)id created_at:(int64_t)created_at payload:(NSString *)payload __attribute__((swift_name("init(id:created_at:payload:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsEvent *)doCopyId:(NSString *)id created_at:(int64_t)created_at payload:(NSString *)payload __attribute__((swift_name("doCopy(id:created_at:payload:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t created_at __attribute__((swift_name("created_at")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString *payload __attribute__((swift_name("payload")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kv")))
@interface PentabitAnalyticsKv : PentabitAnalyticsBase
- (instancetype)initWithK:(NSString *)k v:(NSString *)v __attribute__((swift_name("init(k:v:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsKv *)doCopyK:(NSString *)k v:(NSString *)v __attribute__((swift_name("doCopy(k:v:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *k __attribute__((swift_name("k")));
@property (readonly) NSString *v __attribute__((swift_name("v")));
@end

__attribute__((swift_name("RuntimeTransacterBase")))
@protocol PentabitAnalyticsRuntimeTransacterBase
@required
@end

__attribute__((swift_name("RuntimeTransacter")))
@protocol PentabitAnalyticsRuntimeTransacter <PentabitAnalyticsRuntimeTransacterBase>
@required
- (void)transactionNoEnclosing:(BOOL)noEnclosing body:(void (^)(id<PentabitAnalyticsRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(noEnclosing:body:)")));
- (id _Nullable)transactionWithResultNoEnclosing:(BOOL)noEnclosing bodyWithReturn:(id _Nullable (^)(id<PentabitAnalyticsRuntimeTransactionWithReturn>))bodyWithReturn __attribute__((swift_name("transactionWithResult(noEnclosing:bodyWithReturn:)")));
@end

__attribute__((swift_name("PentabitDatabase")))
@protocol PentabitAnalyticsPentabitDatabase <PentabitAnalyticsRuntimeTransacter>
@required
@property (readonly) PentabitAnalyticsPentabitQueries *pentabitQueries __attribute__((swift_name("pentabitQueries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PentabitDatabaseCompanion")))
@interface PentabitAnalyticsPentabitDatabaseCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsPentabitDatabaseCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsPentabitDatabase>)invokeDriver:(id<PentabitAnalyticsRuntimeSqlDriver>)driver __attribute__((swift_name("invoke(driver:)")));
@property (readonly) id<PentabitAnalyticsRuntimeSqlSchema> Schema __attribute__((swift_name("Schema")));
@end

__attribute__((swift_name("RuntimeBaseTransacterImpl")))
@interface PentabitAnalyticsRuntimeBaseTransacterImpl : PentabitAnalyticsBase
- (instancetype)initWithDriver:(id<PentabitAnalyticsRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (NSString *)createArgumentsCount:(int32_t)count __attribute__((swift_name("createArguments(count:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)notifyQueriesIdentifier:(int32_t)identifier tableProvider:(void (^)(PentabitAnalyticsKotlinUnit *(^)(NSString *)))tableProvider __attribute__((swift_name("notifyQueries(identifier:tableProvider:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (id _Nullable)postTransactionCleanupTransaction:(PentabitAnalyticsRuntimeTransacterTransaction *)transaction enclosing:(PentabitAnalyticsRuntimeTransacterTransaction * _Nullable)enclosing thrownException:(PentabitAnalyticsKotlinThrowable * _Nullable)thrownException returnValue:(id _Nullable)returnValue __attribute__((swift_name("postTransactionCleanup(transaction:enclosing:thrownException:returnValue:)")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) id<PentabitAnalyticsRuntimeSqlDriver> driver __attribute__((swift_name("driver")));
@end

__attribute__((swift_name("RuntimeTransacterImpl")))
@interface PentabitAnalyticsRuntimeTransacterImpl : PentabitAnalyticsRuntimeBaseTransacterImpl <PentabitAnalyticsRuntimeTransacter>
- (instancetype)initWithDriver:(id<PentabitAnalyticsRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer));
- (void)transactionNoEnclosing:(BOOL)noEnclosing body:(void (^)(id<PentabitAnalyticsRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(noEnclosing:body:)")));
- (id _Nullable)transactionWithResultNoEnclosing:(BOOL)noEnclosing bodyWithReturn:(id _Nullable (^)(id<PentabitAnalyticsRuntimeTransactionWithReturn>))bodyWithReturn __attribute__((swift_name("transactionWithResult(noEnclosing:bodyWithReturn:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PentabitQueries")))
@interface PentabitAnalyticsPentabitQueries : PentabitAnalyticsRuntimeTransacterImpl
- (instancetype)initWithDriver:(id<PentabitAnalyticsRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer));
- (PentabitAnalyticsRuntimeExecutableQuery<PentabitAnalyticsLong *> *)changes __attribute__((swift_name("changes()")));
- (PentabitAnalyticsRuntimeQuery<PentabitAnalyticsLong *> *)countEvents __attribute__((swift_name("countEvents()")));

/**
 * @return The number of rows updated.
 */
- (id<PentabitAnalyticsRuntimeQueryResult>)deleteEventId:(NSString *)id __attribute__((swift_name("deleteEvent(id:)")));

/**
 * @return The number of rows updated.
 */
- (id<PentabitAnalyticsRuntimeQueryResult>)deleteKvK:(NSString *)k __attribute__((swift_name("deleteKv(k:)")));

/**
 * @return The number of rows updated.
 */
- (id<PentabitAnalyticsRuntimeQueryResult>)deleteOlderThanCreated_at:(int64_t)created_at __attribute__((swift_name("deleteOlderThan(created_at:)")));

/**
 * @return The number of rows updated.
 */
- (id<PentabitAnalyticsRuntimeQueryResult>)insertEventId:(NSString *)id created_at:(int64_t)created_at payload:(NSString *)payload __attribute__((swift_name("insertEvent(id:created_at:payload:)")));
- (PentabitAnalyticsRuntimeQuery<PentabitAnalyticsEvent *> *)selectBatchValue_:(int64_t)value_ __attribute__((swift_name("selectBatch(value_:)")));
- (PentabitAnalyticsRuntimeQuery<id> *)selectBatchValue:(int64_t)value mapper:(id (^)(NSString *, PentabitAnalyticsLong *, NSString *))mapper __attribute__((swift_name("selectBatch(value:mapper:)")));
- (PentabitAnalyticsRuntimeQuery<NSString *> *)selectKvK:(NSString *)k __attribute__((swift_name("selectKv(k:)")));

/**
 * @return The number of rows updated.
 */
- (id<PentabitAnalyticsRuntimeQueryResult>)trimToValue:(int64_t)value __attribute__((swift_name("trimTo(value:)")));

/**
 * @return The number of rows updated.
 */
- (id<PentabitAnalyticsRuntimeQueryResult>)upsertKvK:(NSString *)k v:(NSString *)v __attribute__((swift_name("upsertKv(k:v:)")));
@end

@interface PentabitAnalyticsEventContext (Extensions)

/**
 * Everything common to a batch goes in headers, so the body is only the list of events.
 * Empty values are left out. The advertising ID, instance ID and user ID are present only when
 * the privacy mode allowed them (the context already holds null otherwise).
 */
- (NSDictionary<NSString *, NSString *> *)toHeaders __attribute__((swift_name("toHeaders()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdErrorKt")))
@interface PentabitAnalyticsAdErrorKt : PentabitAnalyticsBase
+ (PentabitAnalyticsAdError * _Nullable)errorOrNull:(id<PentabitAnalyticsAdResult>)receiver __attribute__((swift_name("errorOrNull(_:)")));
+ (PentabitAnalyticsAdResultFailure *)failureCode:(PentabitAnalyticsAdErrorCode *)code message:(NSString *)message __attribute__((swift_name("failure(code:message:)")));
+ (id<PentabitAnalyticsAdResult>)flatMap:(id<PentabitAnalyticsAdResult>)receiver transform:(id<PentabitAnalyticsAdResult> (^)(id _Nullable))transform __attribute__((swift_name("flatMap(_:transform:)")));
+ (id _Nullable)getOrNull:(id<PentabitAnalyticsAdResult>)receiver __attribute__((swift_name("getOrNull(_:)")));

/**
 * Runs [block] and converts any unexpected exception into an INTERNAL failure.
 * Cancellation is always rethrown so structured concurrency keeps working.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
+ (void)guardBlock:(id<PentabitAnalyticsKotlinSuspendFunction0>)block completionHandler:(void (^)(id<PentabitAnalyticsAdResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("guard(block:completionHandler:)")));
+ (id<PentabitAnalyticsAdResult>)map:(id<PentabitAnalyticsAdResult>)receiver transform:(id _Nullable (^)(id _Nullable))transform __attribute__((swift_name("map(_:transform:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NetKt")))
@interface PentabitAnalyticsNetKt : PentabitAnalyticsBase
@property (class, readonly) PentabitAnalyticsKotlinx_serialization_jsonJson *PentabitJson __attribute__((swift_name("PentabitJson")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlatformFactoryKt")))
@interface PentabitAnalyticsPlatformFactoryKt : PentabitAnalyticsBase

/**
 * Builds every platform implementation. [storeName] names the on-device database, so two Pentabit SDKs in one app keep separate queues.
 * A database that cannot be opened never stops the SDK:
 * events fall back to memory for this run.
 */
+ (id<PentabitAnalyticsPlatformModule>)createPlatformModuleContext:(PentabitAnalyticsPlatformContext *)context debug:(BOOL)debug storeName:(NSString *)storeName __attribute__((swift_name("createPlatformModule(context:debug:storeName:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UtilKt")))
@interface PentabitAnalyticsUtilKt : PentabitAnalyticsBase
+ (int64_t)elapsedSince:(id<PentabitAnalyticsClock>)receiver startMillis:(int64_t)startMillis __attribute__((swift_name("elapsedSince(_:startMillis:)")));
+ (NSString *)htmlEscapeValue:(NSString *)value __attribute__((swift_name("htmlEscape(value:)")));

/** Percent-encodes everything except RFC 3986 unreserved characters. */
+ (NSString *)percentEncodeValue:(NSString *)value __attribute__((swift_name("percentEncode(value:)")));
@end

__attribute__((swift_name("KotlinFunction")))
@protocol PentabitAnalyticsKotlinFunction
@required
@end

__attribute__((swift_name("KotlinSuspendFunction1")))
@protocol PentabitAnalyticsKotlinSuspendFunction1 <PentabitAnalyticsKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:completionHandler:)")));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface PentabitAnalyticsKotlinRuntimeException : PentabitAnalyticsKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(PentabitAnalyticsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(PentabitAnalyticsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface PentabitAnalyticsKotlinIllegalStateException : PentabitAnalyticsKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(PentabitAnalyticsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(PentabitAnalyticsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface PentabitAnalyticsKotlinCancellationException : PentabitAnalyticsKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(PentabitAnalyticsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(PentabitAnalyticsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol PentabitAnalyticsKotlinx_coroutines_coreFlow
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<PentabitAnalyticsKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSharedFlow")))
@protocol PentabitAnalyticsKotlinx_coroutines_coreSharedFlow <PentabitAnalyticsKotlinx_coroutines_coreFlow>
@required
@property (readonly) NSArray<id> *replayCache __attribute__((swift_name("replayCache")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreStateFlow")))
@protocol PentabitAnalyticsKotlinx_coroutines_coreStateFlow <PentabitAnalyticsKotlinx_coroutines_coreSharedFlow>
@required
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface PentabitAnalyticsKotlinEnumCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface PentabitAnalyticsKotlinArray<T> : PentabitAnalyticsBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(PentabitAnalyticsInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<PentabitAnalyticsKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinCoroutineContext")))
@protocol PentabitAnalyticsKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<PentabitAnalyticsKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<PentabitAnalyticsKotlinCoroutineContextElement> _Nullable)getKey:(id<PentabitAnalyticsKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<PentabitAnalyticsKotlinCoroutineContext>)minusKeyKey:(id<PentabitAnalyticsKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<PentabitAnalyticsKotlinCoroutineContext>)plusContext:(id<PentabitAnalyticsKotlinCoroutineContext>)context __attribute__((swift_name("plus(context:)")));
@end

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol PentabitAnalyticsKotlinCoroutineContextElement <PentabitAnalyticsKotlinCoroutineContext>
@required
@property (readonly) id<PentabitAnalyticsKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextElement")))
@interface PentabitAnalyticsKotlinAbstractCoroutineContextElement : PentabitAnalyticsBase <PentabitAnalyticsKotlinCoroutineContextElement>
- (instancetype)initWithKey:(id<PentabitAnalyticsKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<PentabitAnalyticsKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuationInterceptor")))
@protocol PentabitAnalyticsKotlinContinuationInterceptor <PentabitAnalyticsKotlinCoroutineContextElement>
@required
- (id<PentabitAnalyticsKotlinContinuation>)interceptContinuationContinuation:(id<PentabitAnalyticsKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (void)releaseInterceptedContinuationContinuation:(id<PentabitAnalyticsKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher")))
@interface PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcher : PentabitAnalyticsKotlinAbstractCoroutineContextElement <PentabitAnalyticsKotlinContinuationInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithKey:(id<PentabitAnalyticsKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcherKey *companion __attribute__((swift_name("companion")));
- (void)dispatchContext:(id<PentabitAnalyticsKotlinCoroutineContext>)context block:(id<PentabitAnalyticsKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(context:block:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (void)dispatchYieldContext:(id<PentabitAnalyticsKotlinCoroutineContext>)context block:(id<PentabitAnalyticsKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatchYield(context:block:)")));
- (id<PentabitAnalyticsKotlinContinuation>)interceptContinuationContinuation:(id<PentabitAnalyticsKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (BOOL)isDispatchNeededContext:(id<PentabitAnalyticsKotlinCoroutineContext>)context __attribute__((swift_name("isDispatchNeeded(context:)")));
- (PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcher *)limitedParallelismParallelism:(int32_t)parallelism name:(NSString * _Nullable)name __attribute__((swift_name("limitedParallelism(parallelism:name:)")));
- (PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcher *)plusOther:(PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcher *)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two CoroutineDispatcher objects is meaningless. CoroutineDispatcher is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The dispatcher to the right of `+` just replaces the dispatcher to the left.")));
- (void)releaseInterceptedContinuationContinuation:(id<PentabitAnalyticsKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol PentabitAnalyticsKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<PentabitAnalyticsKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol PentabitAnalyticsKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<PentabitAnalyticsKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol PentabitAnalyticsKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<PentabitAnalyticsKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol PentabitAnalyticsKotlinx_serialization_coreKSerializer <PentabitAnalyticsKotlinx_serialization_coreSerializationStrategy, PentabitAnalyticsKotlinx_serialization_coreDeserializationStrategy>
@required
@end

__attribute__((swift_name("KotlinSuspendFunction0")))
@protocol PentabitAnalyticsKotlinSuspendFunction0 <PentabitAnalyticsKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end

__attribute__((swift_name("RuntimeTransactionCallbacks")))
@protocol PentabitAnalyticsRuntimeTransactionCallbacks
@required
- (void)afterCommitFunction:(void (^)(void))function __attribute__((swift_name("afterCommit(function:)")));
- (void)afterRollbackFunction:(void (^)(void))function __attribute__((swift_name("afterRollback(function:)")));
@end

__attribute__((swift_name("RuntimeTransactionWithoutReturn")))
@protocol PentabitAnalyticsRuntimeTransactionWithoutReturn <PentabitAnalyticsRuntimeTransactionCallbacks>
@required
- (void)rollback __attribute__((swift_name("rollback()")));
- (void)transactionBody:(void (^)(id<PentabitAnalyticsRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(body:)")));
@end

__attribute__((swift_name("RuntimeTransactionWithReturn")))
@protocol PentabitAnalyticsRuntimeTransactionWithReturn <PentabitAnalyticsRuntimeTransactionCallbacks>
@required
- (void)rollbackReturnValue:(id _Nullable)returnValue __attribute__((swift_name("rollback(returnValue:)")));
- (id _Nullable)transactionBody_:(id _Nullable (^)(id<PentabitAnalyticsRuntimeTransactionWithReturn>))body __attribute__((swift_name("transaction(body_:)")));
@end

__attribute__((swift_name("RuntimeCloseable")))
@protocol PentabitAnalyticsRuntimeCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end

__attribute__((swift_name("RuntimeSqlDriver")))
@protocol PentabitAnalyticsRuntimeSqlDriver <PentabitAnalyticsRuntimeCloseable>
@required
- (void)addListenerQueryKeys:(PentabitAnalyticsKotlinArray<NSString *> *)queryKeys listener:(id<PentabitAnalyticsRuntimeQueryListener>)listener __attribute__((swift_name("addListener(queryKeys:listener:)")));
- (PentabitAnalyticsRuntimeTransacterTransaction * _Nullable)currentTransaction __attribute__((swift_name("currentTransaction()")));
- (id<PentabitAnalyticsRuntimeQueryResult>)executeIdentifier:(PentabitAnalyticsInt * _Nullable)identifier sql:(NSString *)sql parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<PentabitAnalyticsRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("execute(identifier:sql:parameters:binders:)")));
- (id<PentabitAnalyticsRuntimeQueryResult>)executeQueryIdentifier:(PentabitAnalyticsInt * _Nullable)identifier sql:(NSString *)sql mapper:(id<PentabitAnalyticsRuntimeQueryResult> (^)(id<PentabitAnalyticsRuntimeSqlCursor>))mapper parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<PentabitAnalyticsRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("executeQuery(identifier:sql:mapper:parameters:binders:)")));
- (id<PentabitAnalyticsRuntimeQueryResult>)doNewTransaction __attribute__((swift_name("doNewTransaction()")));
- (void)notifyListenersQueryKeys:(PentabitAnalyticsKotlinArray<NSString *> *)queryKeys __attribute__((swift_name("notifyListeners(queryKeys:)")));
- (void)removeListenerQueryKeys:(PentabitAnalyticsKotlinArray<NSString *> *)queryKeys listener:(id<PentabitAnalyticsRuntimeQueryListener>)listener __attribute__((swift_name("removeListener(queryKeys:listener:)")));
@end

__attribute__((swift_name("RuntimeSqlSchema")))
@protocol PentabitAnalyticsRuntimeSqlSchema
@required
- (id<PentabitAnalyticsRuntimeQueryResult>)createDriver:(id<PentabitAnalyticsRuntimeSqlDriver>)driver __attribute__((swift_name("create(driver:)")));
- (id<PentabitAnalyticsRuntimeQueryResult>)migrateDriver:(id<PentabitAnalyticsRuntimeSqlDriver>)driver oldVersion:(int64_t)oldVersion newVersion:(int64_t)newVersion callbacks:(PentabitAnalyticsKotlinArray<PentabitAnalyticsRuntimeAfterVersion *> *)callbacks __attribute__((swift_name("migrate(driver:oldVersion:newVersion:callbacks:)")));
@property (readonly) int64_t version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface PentabitAnalyticsKotlinUnit : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsKotlinUnit *shared __attribute__((swift_name("shared")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("RuntimeTransacterTransaction")))
@interface PentabitAnalyticsRuntimeTransacterTransaction : PentabitAnalyticsBase <PentabitAnalyticsRuntimeTransactionCallbacks>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)afterCommitFunction:(void (^)(void))function __attribute__((swift_name("afterCommit(function:)")));
- (void)afterRollbackFunction:(void (^)(void))function __attribute__((swift_name("afterRollback(function:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (id<PentabitAnalyticsRuntimeQueryResult>)endTransactionSuccessful:(BOOL)successful __attribute__((swift_name("endTransaction(successful:)")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) PentabitAnalyticsRuntimeTransacterTransaction * _Nullable enclosingTransaction __attribute__((swift_name("enclosingTransaction")));
@end

__attribute__((swift_name("RuntimeExecutableQuery")))
@interface PentabitAnalyticsRuntimeExecutableQuery<__covariant RowType> : PentabitAnalyticsBase
- (instancetype)initWithMapper:(RowType (^)(id<PentabitAnalyticsRuntimeSqlCursor>))mapper __attribute__((swift_name("init(mapper:)"))) __attribute__((objc_designated_initializer));
- (id<PentabitAnalyticsRuntimeQueryResult>)executeMapper:(id<PentabitAnalyticsRuntimeQueryResult> (^)(id<PentabitAnalyticsRuntimeSqlCursor>))mapper __attribute__((swift_name("execute(mapper:)")));
- (NSArray<RowType> *)executeAsList __attribute__((swift_name("executeAsList()")));
- (RowType)executeAsOne __attribute__((swift_name("executeAsOne()")));
- (RowType _Nullable)executeAsOneOrNull __attribute__((swift_name("executeAsOneOrNull()")));
@property (readonly) RowType (^mapper)(id<PentabitAnalyticsRuntimeSqlCursor>) __attribute__((swift_name("mapper")));
@end

__attribute__((swift_name("RuntimeQuery")))
@interface PentabitAnalyticsRuntimeQuery<__covariant RowType> : PentabitAnalyticsRuntimeExecutableQuery<RowType>
- (instancetype)initWithMapper:(RowType (^)(id<PentabitAnalyticsRuntimeSqlCursor>))mapper __attribute__((swift_name("init(mapper:)"))) __attribute__((objc_designated_initializer));
- (void)addListenerListener:(id<PentabitAnalyticsRuntimeQueryListener>)listener __attribute__((swift_name("addListener(listener:)")));
- (void)removeListenerListener:(id<PentabitAnalyticsRuntimeQueryListener>)listener __attribute__((swift_name("removeListener(listener:)")));
@end

__attribute__((swift_name("RuntimeQueryResult")))
@protocol PentabitAnalyticsRuntimeQueryResult
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)awaitWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("await(completionHandler:)")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialFormat")))
@protocol PentabitAnalyticsKotlinx_serialization_coreSerialFormat
@required
@property (readonly) PentabitAnalyticsKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreStringFormat")))
@protocol PentabitAnalyticsKotlinx_serialization_coreStringFormat <PentabitAnalyticsKotlinx_serialization_coreSerialFormat>
@required
- (id _Nullable)decodeFromStringDeserializer:(id<PentabitAnalyticsKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (NSString *)encodeToStringSerializer:(id<PentabitAnalyticsKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
@end

__attribute__((swift_name("Kotlinx_serialization_jsonJson")))
@interface PentabitAnalyticsKotlinx_serialization_jsonJson : PentabitAnalyticsBase <PentabitAnalyticsKotlinx_serialization_coreStringFormat>
@property (class, readonly, getter=companion) PentabitAnalyticsKotlinx_serialization_jsonJsonDefault *companion __attribute__((swift_name("companion")));
- (id _Nullable)decodeFromJsonElementDeserializer:(id<PentabitAnalyticsKotlinx_serialization_coreDeserializationStrategy>)deserializer element:(PentabitAnalyticsKotlinx_serialization_jsonJsonElement *)element __attribute__((swift_name("decodeFromJsonElement(deserializer:element:)")));
- (id _Nullable)decodeFromStringString:(NSString *)string __attribute__((swift_name("decodeFromString(string:)")));
- (id _Nullable)decodeFromStringDeserializer:(id<PentabitAnalyticsKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (PentabitAnalyticsKotlinx_serialization_jsonJsonElement *)encodeToJsonElementSerializer:(id<PentabitAnalyticsKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToJsonElement(serializer:value:)")));
- (NSString *)encodeToStringValue:(id _Nullable)value __attribute__((swift_name("encodeToString(value:)")));
- (NSString *)encodeToStringSerializer:(id<PentabitAnalyticsKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
- (PentabitAnalyticsKotlinx_serialization_jsonJsonElement *)parseToJsonElementString:(NSString *)string __attribute__((swift_name("parseToJsonElement(string:)")));
@property (readonly) PentabitAnalyticsKotlinx_serialization_jsonJsonConfiguration *configuration __attribute__((swift_name("configuration")));
@property (readonly) PentabitAnalyticsKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlowCollector")))
@protocol PentabitAnalyticsKotlinx_coroutines_coreFlowCollector
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(id _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol PentabitAnalyticsKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol PentabitAnalyticsKotlinCoroutineContextKey
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuation")))
@protocol PentabitAnalyticsKotlinContinuation
@required
- (void)resumeWithResult:(id _Nullable)result __attribute__((swift_name("resumeWith(result:)")));
@property (readonly) id<PentabitAnalyticsKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextKey")))
@interface PentabitAnalyticsKotlinAbstractCoroutineContextKey<B, E> : PentabitAnalyticsBase <PentabitAnalyticsKotlinCoroutineContextKey>
- (instancetype)initWithBaseKey:(id<PentabitAnalyticsKotlinCoroutineContextKey>)baseKey safeCast:(E _Nullable (^)(id<PentabitAnalyticsKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher.Key")))
@interface PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcherKey : PentabitAnalyticsKotlinAbstractCoroutineContextKey<id<PentabitAnalyticsKotlinContinuationInterceptor>, PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcher *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithBaseKey:(id<PentabitAnalyticsKotlinCoroutineContextKey>)baseKey safeCast:(id<PentabitAnalyticsKotlinCoroutineContextElement> _Nullable (^)(id<PentabitAnalyticsKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)key __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsKotlinx_coroutines_coreCoroutineDispatcherKey *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol PentabitAnalyticsKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol PentabitAnalyticsKotlinx_serialization_coreEncoder
@required
- (id<PentabitAnalyticsKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<PentabitAnalyticsKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<PentabitAnalyticsKotlinx_serialization_coreEncoder>)encodeInlineDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("encodeInline(descriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNull __attribute__((swift_name("encodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableValueSerializer:(id<PentabitAnalyticsKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<PentabitAnalyticsKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) PentabitAnalyticsKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor
@required
- (NSArray<id<PentabitAnalyticsKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));
- (id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));
@property (readonly) NSArray<id<PentabitAnalyticsKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));
@property (readonly) PentabitAnalyticsKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol PentabitAnalyticsKotlinx_serialization_coreDecoder
@required
- (id<PentabitAnalyticsKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<PentabitAnalyticsKotlinx_serialization_coreDecoder>)decodeInlineDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeInline(descriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (PentabitAnalyticsKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<PentabitAnalyticsKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<PentabitAnalyticsKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) PentabitAnalyticsKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("RuntimeQueryListener")))
@protocol PentabitAnalyticsRuntimeQueryListener
@required
- (void)queryResultsChanged __attribute__((swift_name("queryResultsChanged()")));
@end

__attribute__((swift_name("RuntimeSqlPreparedStatement")))
@protocol PentabitAnalyticsRuntimeSqlPreparedStatement
@required
- (void)bindBooleanIndex:(int32_t)index boolean:(PentabitAnalyticsBoolean * _Nullable)boolean __attribute__((swift_name("bindBoolean(index:boolean:)")));
- (void)bindBytesIndex:(int32_t)index bytes:(PentabitAnalyticsKotlinByteArray * _Nullable)bytes __attribute__((swift_name("bindBytes(index:bytes:)")));
- (void)bindDoubleIndex:(int32_t)index double:(PentabitAnalyticsDouble * _Nullable)double_ __attribute__((swift_name("bindDouble(index:double:)")));
- (void)bindLongIndex:(int32_t)index long:(PentabitAnalyticsLong * _Nullable)long_ __attribute__((swift_name("bindLong(index:long:)")));
- (void)bindStringIndex:(int32_t)index string:(NSString * _Nullable)string __attribute__((swift_name("bindString(index:string:)")));
@end

__attribute__((swift_name("RuntimeSqlCursor")))
@protocol PentabitAnalyticsRuntimeSqlCursor
@required
- (PentabitAnalyticsBoolean * _Nullable)getBooleanIndex:(int32_t)index __attribute__((swift_name("getBoolean(index:)")));
- (PentabitAnalyticsKotlinByteArray * _Nullable)getBytesIndex:(int32_t)index __attribute__((swift_name("getBytes(index:)")));
- (PentabitAnalyticsDouble * _Nullable)getDoubleIndex:(int32_t)index __attribute__((swift_name("getDouble(index:)")));
- (PentabitAnalyticsLong * _Nullable)getLongIndex:(int32_t)index __attribute__((swift_name("getLong(index:)")));
- (NSString * _Nullable)getStringIndex:(int32_t)index __attribute__((swift_name("getString(index:)")));
- (id<PentabitAnalyticsRuntimeQueryResult>)next __attribute__((swift_name("next()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RuntimeAfterVersion")))
@interface PentabitAnalyticsRuntimeAfterVersion : PentabitAnalyticsBase
- (instancetype)initWithAfterVersion:(int64_t)afterVersion block:(void (^)(id<PentabitAnalyticsRuntimeSqlDriver>))block __attribute__((swift_name("init(afterVersion:block:)"))) __attribute__((objc_designated_initializer));
@property (readonly) int64_t afterVersion __attribute__((swift_name("afterVersion")));
@property (readonly) void (^block)(id<PentabitAnalyticsRuntimeSqlDriver>) __attribute__((swift_name("block")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface PentabitAnalyticsKotlinx_serialization_coreSerializersModule : PentabitAnalyticsBase

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)dumpToCollector:(id<PentabitAnalyticsKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<PentabitAnalyticsKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<PentabitAnalyticsKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<PentabitAnalyticsKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<PentabitAnalyticsKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<PentabitAnalyticsKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJson.Default")))
@interface PentabitAnalyticsKotlinx_serialization_jsonJsonDefault : PentabitAnalyticsKotlinx_serialization_jsonJson
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)default_ __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsKotlinx_serialization_jsonJsonDefault *shared __attribute__((swift_name("shared")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=kotlinx/serialization/json/JsonElementSerializer))
*/
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement")))
@interface PentabitAnalyticsKotlinx_serialization_jsonJsonElement : PentabitAnalyticsBase
@property (class, readonly, getter=companion) PentabitAnalyticsKotlinx_serialization_jsonJsonElementCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonConfiguration")))
@interface PentabitAnalyticsKotlinx_serialization_jsonJsonConfiguration : PentabitAnalyticsBase
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL allowComments __attribute__((swift_name("allowComments")));
@property (readonly) BOOL allowSpecialFloatingPointValues __attribute__((swift_name("allowSpecialFloatingPointValues")));
@property (readonly) BOOL allowStructuredMapKeys __attribute__((swift_name("allowStructuredMapKeys")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL allowTrailingComma __attribute__((swift_name("allowTrailingComma")));
@property (readonly) NSString *classDiscriminator __attribute__((swift_name("classDiscriminator")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property PentabitAnalyticsKotlinx_serialization_jsonClassDiscriminatorMode *classDiscriminatorMode __attribute__((swift_name("classDiscriminatorMode")));
@property (readonly) BOOL coerceInputValues __attribute__((swift_name("coerceInputValues")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL decodeEnumsCaseInsensitive __attribute__((swift_name("decodeEnumsCaseInsensitive")));
@property (readonly) BOOL encodeDefaults __attribute__((swift_name("encodeDefaults")));
@property (readonly) BOOL explicitNulls __attribute__((swift_name("explicitNulls")));
@property (readonly) BOOL ignoreUnknownKeys __attribute__((swift_name("ignoreUnknownKeys")));
@property (readonly) BOOL isLenient __attribute__((swift_name("isLenient")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) id<PentabitAnalyticsKotlinx_serialization_jsonJsonNamingStrategy> _Nullable namingStrategy __attribute__((swift_name("namingStrategy")));
@property (readonly) BOOL prettyPrint __attribute__((swift_name("prettyPrint")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSString *prettyPrintIndent __attribute__((swift_name("prettyPrintIndent")));
@property (readonly) BOOL useAlternativeNames __attribute__((swift_name("useAlternativeNames")));
@property (readonly) BOOL useArrayPolymorphism __attribute__((swift_name("useArrayPolymorphism")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol PentabitAnalyticsKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<PentabitAnalyticsKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<PentabitAnalyticsKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<PentabitAnalyticsKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) PentabitAnalyticsKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("KotlinAnnotation")))
@protocol PentabitAnalyticsKotlinAnnotation
@required
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface PentabitAnalyticsKotlinx_serialization_coreSerialKind : PentabitAnalyticsBase
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol PentabitAnalyticsKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<PentabitAnalyticsKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<PentabitAnalyticsKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<PentabitAnalyticsKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) PentabitAnalyticsKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface PentabitAnalyticsKotlinNothing : PentabitAnalyticsBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface PentabitAnalyticsKotlinByteArray : PentabitAnalyticsBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(PentabitAnalyticsByte *(^)(PentabitAnalyticsInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (PentabitAnalyticsKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol PentabitAnalyticsKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<PentabitAnalyticsKotlinKClass>)kClass provider:(id<PentabitAnalyticsKotlinx_serialization_coreKSerializer> (^)(NSArray<id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>> *))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<PentabitAnalyticsKotlinKClass>)kClass serializer:(id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<PentabitAnalyticsKotlinKClass>)baseClass actualClass:(id<PentabitAnalyticsKotlinKClass>)actualClass actualSerializer:(id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<PentabitAnalyticsKotlinKClass>)baseClass defaultDeserializerProvider:(id<PentabitAnalyticsKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)"))) __attribute__((deprecated("Deprecated in favor of function with more precise name: polymorphicDefaultDeserializer")));
- (void)polymorphicDefaultDeserializerBaseClass:(id<PentabitAnalyticsKotlinKClass>)baseClass defaultDeserializerProvider:(id<PentabitAnalyticsKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultSerializerBaseClass:(id<PentabitAnalyticsKotlinKClass>)baseClass defaultSerializerProvider:(id<PentabitAnalyticsKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol PentabitAnalyticsKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol PentabitAnalyticsKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol PentabitAnalyticsKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol PentabitAnalyticsKotlinKClass <PentabitAnalyticsKotlinKDeclarationContainer, PentabitAnalyticsKotlinKAnnotatedElement, PentabitAnalyticsKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement.Companion")))
@interface PentabitAnalyticsKotlinx_serialization_jsonJsonElementCompanion : PentabitAnalyticsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAnalyticsKotlinx_serialization_jsonJsonElementCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAnalyticsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonClassDiscriminatorMode")))
@interface PentabitAnalyticsKotlinx_serialization_jsonClassDiscriminatorMode : PentabitAnalyticsKotlinEnum<PentabitAnalyticsKotlinx_serialization_jsonClassDiscriminatorMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAnalyticsKotlinx_serialization_jsonClassDiscriminatorMode *none __attribute__((swift_name("none")));
@property (class, readonly) PentabitAnalyticsKotlinx_serialization_jsonClassDiscriminatorMode *allJsonObjects __attribute__((swift_name("allJsonObjects")));
@property (class, readonly) PentabitAnalyticsKotlinx_serialization_jsonClassDiscriminatorMode *polymorphic __attribute__((swift_name("polymorphic")));
+ (PentabitAnalyticsKotlinArray<PentabitAnalyticsKotlinx_serialization_jsonClassDiscriminatorMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAnalyticsKotlinx_serialization_jsonClassDiscriminatorMode *> *entries __attribute__((swift_name("entries")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_jsonJsonNamingStrategy")))
@protocol PentabitAnalyticsKotlinx_serialization_jsonJsonNamingStrategy
@required
- (NSString *)serialNameForJsonDescriptor:(id<PentabitAnalyticsKotlinx_serialization_coreSerialDescriptor>)descriptor elementIndex:(int32_t)elementIndex serialName:(NSString *)serialName __attribute__((swift_name("serialNameForJson(descriptor:elementIndex:serialName:)")));
@end

__attribute__((swift_name("KotlinByteIterator")))
@interface PentabitAnalyticsKotlinByteIterator : PentabitAnalyticsBase <PentabitAnalyticsKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (PentabitAnalyticsByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
