#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class PentabitAdsAdError, PentabitAdsAdErrorCode, PentabitAdsAdFormat, PentabitAdsAdFormatCompanion, PentabitAdsAdLoadListener, PentabitAdsAdRequest, PentabitAdsAdRequestCompanion, PentabitAdsAdResponse, PentabitAdsAdResponseCompanion, PentabitAdsAdResultFailure, PentabitAdsAdResultSuccess<__covariant T>, PentabitAdsAdSessionCompanion, PentabitAdsAdShowListener, PentabitAdsAdStage, PentabitAdsAdValue, PentabitAdsAnalyticsOptions, PentabitAdsApiClient, PentabitAdsAppInfo, PentabitAdsAppInfoCompanion, PentabitAdsAppOpenAd, PentabitAdsAudienceProfile, PentabitAdsBannerSize, PentabitAdsCachedAsset, PentabitAdsCircuitBreaker, PentabitAdsConfigParser, PentabitAdsConfigRepository, PentabitAdsConsentPolicy, PentabitAdsConsentSignals, PentabitAdsCoreOptions, PentabitAdsCreative, PentabitAdsCreativeAsset, PentabitAdsCreativeAssetCompanion, PentabitAdsCreativeCompanion, PentabitAdsCreativeHtml, PentabitAdsCreativeType, PentabitAdsCreativeTypeCompanion, PentabitAdsDeepLink, PentabitAdsDeepLinkResolver, PentabitAdsDeviceContext, PentabitAdsDeviceContextCompanion, PentabitAdsEvent, PentabitAdsEventConfig, PentabitAdsEventConfigCompanion, PentabitAdsEventContext, PentabitAdsEventContextCompanion, PentabitAdsEventFlusher, PentabitAdsEventNames, PentabitAdsEventTracker, PentabitAdsEventUploader, PentabitAdsFakeAssetStore, PentabitAdsFakeClock, PentabitAdsFakeConnectivity, PentabitAdsFakeDeviceInfo, PentabitAdsFakeHttp, PentabitAdsFlushOutcome, PentabitAdsFullScreenAd, PentabitAdsHttpRequest, PentabitAdsHttpResponse, PentabitAdsInMemoryEventStore, PentabitAdsInMemoryKeyValueStore, PentabitAdsInterstitialAd, PentabitAdsIosVideoSupport, PentabitAdsKotlinAbstractCoroutineContextElement, PentabitAdsKotlinAbstractCoroutineContextKey<B, E>, PentabitAdsKotlinArray<T>, PentabitAdsKotlinByteArray, PentabitAdsKotlinByteIterator, PentabitAdsKotlinEnum<E>, PentabitAdsKotlinEnumCompanion, PentabitAdsKotlinException, PentabitAdsKotlinIllegalStateException, PentabitAdsKotlinNothing, PentabitAdsKotlinRuntimeException, PentabitAdsKotlinThrowable, PentabitAdsKotlinUnit, PentabitAdsKotlinx_coroutines_coreCoroutineDispatcher, PentabitAdsKotlinx_coroutines_coreCoroutineDispatcherKey, PentabitAdsKotlinx_serialization_coreSerialKind, PentabitAdsKotlinx_serialization_coreSerializersModule, PentabitAdsKotlinx_serialization_jsonClassDiscriminatorMode, PentabitAdsKotlinx_serialization_jsonJson, PentabitAdsKotlinx_serialization_jsonJsonConfiguration, PentabitAdsKotlinx_serialization_jsonJsonDefault, PentabitAdsKotlinx_serialization_jsonJsonElement, PentabitAdsKotlinx_serialization_jsonJsonElementCompanion, PentabitAdsKv, PentabitAdsLoadedAd, PentabitAdsMediaSelector, PentabitAdsMraidControllerCompanion, PentabitAdsMraidMessageClose, PentabitAdsMraidMessageOpen, PentabitAdsMraidMessageOrientation, PentabitAdsMraidMessagePlayableComplete, PentabitAdsMraidMessagePlayableCta, PentabitAdsMraidMessagePlayableError, PentabitAdsMraidMessagePlayableReady, PentabitAdsMraidMessageUnload, PentabitAdsMraidPlacement, PentabitAdsMraidScript, PentabitAdsMraidState, PentabitAdsNativeAd, PentabitAdsNativeAdEventListener, PentabitAdsNativeAdListener, PentabitAdsNativeAdLoader, PentabitAdsNativeAssets, PentabitAdsNativeAssetsCompanion, PentabitAdsNetworkExceptionKind, PentabitAdsNoopLogger, PentabitAdsPentabitAds, PentabitAdsPentabitAdsOptions, PentabitAdsPentabitAnalytics, PentabitAdsPentabitDatabaseCompanion, PentabitAdsPentabitEndpoints, PentabitAdsPentabitEvent, PentabitAdsPentabitEventCompanion, PentabitAdsPentabitQueries, PentabitAdsPentabitVersion, PentabitAdsPixelClient, PentabitAdsPlacementConfig, PentabitAdsPlacementConfigCompanion, PentabitAdsPlatformContext, PentabitAdsPrivacyContext, PentabitAdsPrivacyContextCompanion, PentabitAdsPrivacyMode, PentabitAdsPrivacyState, PentabitAdsResolvedVast, PentabitAdsRetryPolicy, PentabitAdsRewardItem, PentabitAdsRewardSpec, PentabitAdsRewardSpecCompanion, PentabitAdsRewardedAd, PentabitAdsRuntimeAfterVersion, PentabitAdsRuntimeBaseTransacterImpl, PentabitAdsRuntimeExecutableQuery<__covariant RowType>, PentabitAdsRuntimeQuery<__covariant RowType>, PentabitAdsRuntimeTransacterImpl, PentabitAdsRuntimeTransacterTransaction, PentabitAdsSdkConfig, PentabitAdsSdkConfigCompanion, PentabitAdsSdkDefaults, PentabitAdsSdkInfo, PentabitAdsSdkInfoCompanion, PentabitAdsSdkScope, PentabitAdsStoredEvent, PentabitAdsSystemIds, PentabitAdsTriState, PentabitAdsUrlPolicy, PentabitAdsValuePrecision, PentabitAdsVastAd, PentabitAdsVastCompanion, PentabitAdsVastEvents, PentabitAdsVastLinear, PentabitAdsVastMedia, PentabitAdsVastParser, PentabitAdsVastParserCompanion, PentabitAdsVastResolver, PentabitAdsVastTracking, UIView, UIViewController;

@protocol PentabitAdsAdResult, PentabitAdsAssetStore, PentabitAdsClock, PentabitAdsConnectivityMonitor, PentabitAdsDeviceInfo, PentabitAdsDispatcherProvider, PentabitAdsEventStore, PentabitAdsHttpClientPort, PentabitAdsIdGenerator, PentabitAdsIosVideoPlayer, PentabitAdsIosVideoPlayerFactory, PentabitAdsKeyValueStore, PentabitAdsKotlinAnnotation, PentabitAdsKotlinComparable, PentabitAdsKotlinContinuation, PentabitAdsKotlinContinuationInterceptor, PentabitAdsKotlinCoroutineContext, PentabitAdsKotlinCoroutineContextElement, PentabitAdsKotlinCoroutineContextKey, PentabitAdsKotlinFunction, PentabitAdsKotlinIterator, PentabitAdsKotlinKAnnotatedElement, PentabitAdsKotlinKClass, PentabitAdsKotlinKClassifier, PentabitAdsKotlinKDeclarationContainer, PentabitAdsKotlinSuspendFunction0, PentabitAdsKotlinSuspendFunction1, PentabitAdsKotlinx_coroutines_coreCoroutineScope, PentabitAdsKotlinx_coroutines_coreFlow, PentabitAdsKotlinx_coroutines_coreFlowCollector, PentabitAdsKotlinx_coroutines_coreRunnable, PentabitAdsKotlinx_coroutines_coreSharedFlow, PentabitAdsKotlinx_coroutines_coreStateFlow, PentabitAdsKotlinx_serialization_coreCompositeDecoder, PentabitAdsKotlinx_serialization_coreCompositeEncoder, PentabitAdsKotlinx_serialization_coreDecoder, PentabitAdsKotlinx_serialization_coreDeserializationStrategy, PentabitAdsKotlinx_serialization_coreEncoder, PentabitAdsKotlinx_serialization_coreKSerializer, PentabitAdsKotlinx_serialization_coreSerialDescriptor, PentabitAdsKotlinx_serialization_coreSerialFormat, PentabitAdsKotlinx_serialization_coreSerializationStrategy, PentabitAdsKotlinx_serialization_coreSerializersModuleCollector, PentabitAdsKotlinx_serialization_coreStringFormat, PentabitAdsKotlinx_serialization_jsonJsonNamingStrategy, PentabitAdsLogger, PentabitAdsMraidListener, PentabitAdsMraidMessage, PentabitAdsPentabitDatabase, PentabitAdsPlatformModule, PentabitAdsRuntimeCloseable, PentabitAdsRuntimeQueryListener, PentabitAdsRuntimeQueryResult, PentabitAdsRuntimeSqlCursor, PentabitAdsRuntimeSqlDriver, PentabitAdsRuntimeSqlPreparedStatement, PentabitAdsRuntimeSqlSchema, PentabitAdsRuntimeTransacter, PentabitAdsRuntimeTransacterBase, PentabitAdsRuntimeTransactionCallbacks, PentabitAdsRuntimeTransactionWithReturn, PentabitAdsRuntimeTransactionWithoutReturn, PentabitAdsVideoListener, PentabitAdsVideoPlayerHandle;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface PentabitAdsBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface PentabitAdsBase (PentabitAdsBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface PentabitAdsMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface PentabitAdsMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorPentabitAdsKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface PentabitAdsNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface PentabitAdsByte : PentabitAdsNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface PentabitAdsUByte : PentabitAdsNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface PentabitAdsShort : PentabitAdsNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface PentabitAdsUShort : PentabitAdsNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface PentabitAdsInt : PentabitAdsNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface PentabitAdsUInt : PentabitAdsNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface PentabitAdsLong : PentabitAdsNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface PentabitAdsULong : PentabitAdsNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface PentabitAdsFloat : PentabitAdsNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface PentabitAdsDouble : PentabitAdsNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface PentabitAdsBoolean : PentabitAdsNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end


/** Open classes with no-op methods: implement only what you need (works from Swift too). */
__attribute__((swift_name("AdLoadListener")))
@interface PentabitAdsAdLoadListener : PentabitAdsBase

/** Open classes with no-op methods: implement only what you need (works from Swift too). */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/** Open classes with no-op methods: implement only what you need (works from Swift too). */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)onLoadFailedError:(PentabitAdsAdError *)error __attribute__((swift_name("onLoadFailed(error:)")));
- (void)onLoaded __attribute__((swift_name("onLoaded()")));
@end

__attribute__((swift_name("AdShowListener")))
@interface PentabitAdsAdShowListener : PentabitAdsBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/** The ad was counted as an impression (once per ad). */
- (void)onAdImpression __attribute__((swift_name("onAdImpression()")));

/** Revenue earned by that impression; right after [onAdImpression]. */
- (void)onAdPaidValue:(PentabitAdsAdValue *)value __attribute__((swift_name("onAdPaid(value:)")));
- (void)onClicked __attribute__((swift_name("onClicked()")));
- (void)onClosed __attribute__((swift_name("onClosed()")));
- (void)onRewardEarnedReward:(PentabitAdsRewardItem *)reward __attribute__((swift_name("onRewardEarned(reward:)")));
- (void)onShowFailedError:(PentabitAdsAdError *)error __attribute__((swift_name("onShowFailed(error:)")));
- (void)onShown __attribute__((swift_name("onShown()")));
@end


/**
 * Revenue for one impression, like AdMob's paid event. [valueMicros] is in millionths of [currencyCode]
 * (1_000_000 = 1 USD). It is 0 while only cross-promotion is served.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdValue")))
@interface PentabitAdsAdValue : PentabitAdsBase
- (instancetype)initWithValueMicros:(int64_t)valueMicros currencyCode:(NSString *)currencyCode precision:(PentabitAdsValuePrecision *)precision __attribute__((swift_name("init(valueMicros:currencyCode:precision:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsAdValue *)doCopyValueMicros:(int64_t)valueMicros currencyCode:(NSString *)currencyCode precision:(PentabitAdsValuePrecision *)precision __attribute__((swift_name("doCopy(valueMicros:currencyCode:precision:)")));

/**
 * Revenue for one impression, like AdMob's paid event. [valueMicros] is in millionths of [currencyCode]
 * (1_000_000 = 1 USD). It is 0 while only cross-promotion is served.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Revenue for one impression, like AdMob's paid event. [valueMicros] is in millionths of [currencyCode]
 * (1_000_000 = 1 USD). It is 0 while only cross-promotion is served.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Revenue for one impression, like AdMob's paid event. [valueMicros] is in millionths of [currencyCode]
 * (1_000_000 = 1 USD). It is 0 while only cross-promotion is served.
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *currencyCode __attribute__((swift_name("currencyCode")));
@property (readonly) PentabitAdsValuePrecision *precision __attribute__((swift_name("precision")));
@property (readonly) int64_t valueMicros __attribute__((swift_name("valueMicros")));
@end


/**
 * Shared behaviour of interstitial, rewarded and app open ads: load once, show once, then make a
 * new object (or call load again) for the next ad. Call every method from the main thread.
 */
__attribute__((swift_name("FullScreenAd")))
@interface PentabitAdsFullScreenAd : PentabitAdsBase

/** Releases the loaded ad. The object can be loaded again afterwards. */
- (void)destroy __attribute__((swift_name("destroy()")));
- (void)loadListener:(PentabitAdsAdLoadListener *)listener __attribute__((swift_name("load(listener:)")));
- (void)showHost:(UIViewController *)host listener:(PentabitAdsAdShowListener *)listener __attribute__((swift_name("show(host:listener:)")));
@property (readonly) BOOL isReady __attribute__((swift_name("isReady")));
@property (readonly) NSString *placementId __attribute__((swift_name("placementId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AppOpenAd")))
@interface PentabitAdsAppOpenAd : PentabitAdsFullScreenAd
@end

__attribute__((swift_name("BannerListener")))
@interface PentabitAdsBannerListener : PentabitAdsBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)onAdImpression __attribute__((swift_name("onAdImpression()")));
- (void)onAdPaidValue:(PentabitAdsAdValue *)value __attribute__((swift_name("onAdPaid(value:)")));
- (void)onClicked __attribute__((swift_name("onClicked()")));
- (void)onLoadFailedError:(PentabitAdsAdError *)error __attribute__((swift_name("onLoadFailed(error:)")));
- (void)onLoaded __attribute__((swift_name("onLoaded()")));
- (void)onShown __attribute__((swift_name("onShown()")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol PentabitAdsKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface PentabitAdsKotlinEnum<E> : PentabitAdsBase <PentabitAdsKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAdsKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end


/** The banner sizes (in dp). Set [PentabitBannerView.adSize] before `load`: the backend returns a banner of exactly that size, or no ad. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BannerSize")))
@interface PentabitAdsBannerSize : PentabitAdsKotlinEnum<PentabitAdsBannerSize *>
+ (instancetype)alloc __attribute__((unavailable));

/** The banner sizes (in dp). Set [PentabitBannerView.adSize] before `load`: the backend returns a banner of exactly that size, or no ad. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAdsBannerSize *banner __attribute__((swift_name("banner")));
@property (class, readonly) PentabitAdsBannerSize *largeBanner __attribute__((swift_name("largeBanner")));
@property (class, readonly) PentabitAdsBannerSize *mediumRectangle __attribute__((swift_name("mediumRectangle")));
+ (PentabitAdsKotlinArray<PentabitAdsBannerSize *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAdsBannerSize *> *entries __attribute__((swift_name("entries")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InterstitialAd")))
@interface PentabitAdsInterstitialAd : PentabitAdsFullScreenAd
@end


/** A player created by pentabit-ads-video. The platform-specific subtype carries the actual view. */
__attribute__((swift_name("VideoPlayerHandle")))
@protocol PentabitAdsVideoPlayerHandle
@required
- (void)pause __attribute__((swift_name("pause()")));
- (void)play __attribute__((swift_name("play()")));
- (void)release_ __attribute__((swift_name("release()")));
- (void)setMutedMuted:(BOOL)muted __attribute__((swift_name("setMuted(muted:)")));
@end


/** An iOS video player: the view to show plus the shared controls. Created by pentabit-ads-video. */
__attribute__((swift_name("IosVideoPlayer")))
@protocol PentabitAdsIosVideoPlayer <PentabitAdsVideoPlayerHandle>
@required
@property (readonly) UIView *view __attribute__((swift_name("view")));
@end

__attribute__((swift_name("IosVideoPlayerFactory")))
@protocol PentabitAdsIosVideoPlayerFactory
@required
- (id<PentabitAdsIosVideoPlayer>)createFilePath:(NSString *)filePath listener:(id<PentabitAdsVideoListener>)listener __attribute__((swift_name("create(filePath:listener:)")));
@end


/** pentabit-ads-video registers itself here. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IosVideoSupport")))
@interface PentabitAdsIosVideoSupport : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));

/** pentabit-ads-video registers itself here. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)iosVideoSupport __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsIosVideoSupport *shared __attribute__((swift_name("shared")));
@property id<PentabitAdsIosVideoPlayerFactory> _Nullable factory __attribute__((swift_name("factory")));
@end


/**
 * Native and Icon ads are plain assets: you draw them with your own views, so no WebView or MRAID is
 * involved. Report what the user sees and does with [recordImpression], [onExposure] and [recordClick].
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NativeAd")))
@interface PentabitAdsNativeAd : PentabitAdsBase
- (void)destroy __attribute__((swift_name("destroy()")));

/** Optionally feed how much of the ad is visible (0..100); a viewable impression is counted once. */
- (void)onExposurePercent:(double)percent __attribute__((swift_name("onExposure(percent:)")));

/** Opens [privacyUrl]. The ad views call this from their (i) button. */
- (BOOL)openPrivacyPolicy __attribute__((swift_name("openPrivacyPolicy()")));

/** Records the click and opens the destination. Returns false if there was nothing to open. */
- (BOOL)recordClick __attribute__((swift_name("recordClick()")));

/** Call when the ad is first drawn on screen. Safe to call again. */
- (void)recordImpression __attribute__((swift_name("recordImpression()")));
- (void)setEventListenerListener:(PentabitAdsNativeAdEventListener * _Nullable)listener __attribute__((swift_name("setEventListener(listener:)")));
@property (readonly) NSString * _Nullable body __attribute__((swift_name("body")));
@property (readonly) NSString * _Nullable callToAction __attribute__((swift_name("callToAction")));

/** Local file path of the cached icon image, or null. */
@property (readonly) NSString * _Nullable iconPath __attribute__((swift_name("iconPath")));

/** Local file path of the cached main image, or null. */
@property (readonly) NSString * _Nullable imagePath __attribute__((swift_name("imagePath")));

/** The page the (i) button opens: why this ad is shown and the privacy policy. */
@property (readonly) NSString *privacyUrl __attribute__((swift_name("privacyUrl")));

/** Always show this label next to the ad. Google Play and Apple require ads to be identifiable. */
@property (readonly) NSString *sponsoredLabel __attribute__((swift_name("sponsoredLabel")));
@property (readonly) NSString * _Nullable title __attribute__((swift_name("title")));
@end


/** Optional: impression and revenue callbacks for a native or icon ad. Set with [NativeAd.setEventListener]. */
__attribute__((swift_name("NativeAdEventListener")))
@interface PentabitAdsNativeAdEventListener : PentabitAdsBase

/** Optional: impression and revenue callbacks for a native or icon ad. Set with [NativeAd.setEventListener]. */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/** Optional: impression and revenue callbacks for a native or icon ad. Set with [NativeAd.setEventListener]. */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)onAdImpression __attribute__((swift_name("onAdImpression()")));
- (void)onAdPaidValue:(PentabitAdsAdValue *)value __attribute__((swift_name("onAdPaid(value:)")));
- (void)onClicked __attribute__((swift_name("onClicked()")));
@end

__attribute__((swift_name("NativeAdListener")))
@interface PentabitAdsNativeAdListener : PentabitAdsBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)onLoadFailedError:(PentabitAdsAdError *)error __attribute__((swift_name("onLoadFailed(error:)")));
- (void)onLoadedAd:(PentabitAdsNativeAd *)ad __attribute__((swift_name("onLoaded(ad:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NativeAdLoader")))
@interface PentabitAdsNativeAdLoader : PentabitAdsBase
- (void)loadListener:(PentabitAdsNativeAdListener *)listener __attribute__((swift_name("load(listener:)")));
@end


/** Entry point of the Pentabit Ads SDK for publishers. Call [initialize] once at app start. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PentabitAds")))
@interface PentabitAdsPentabitAds : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));

/** Entry point of the Pentabit Ads SDK for publishers. Call [initialize] once at app start. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)pentabitAds __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsPentabitAds *shared __attribute__((swift_name("shared")));
- (PentabitAdsAppOpenAd *)appOpenPlacementId:(NSString *)placementId __attribute__((swift_name("appOpen(placementId:)")));
- (PentabitAdsNativeAdLoader *)iconAdsPlacementId:(NSString *)placementId __attribute__((swift_name("iconAds(placementId:)")));

/**
 * Starts the SDK. Returns at once: event upload happens on background threads.
 * Calling it again does nothing. A failure here never throws; ad calls then report NOT_INITIALIZED.
 */
- (void)initializeContext:(PentabitAdsPlatformContext *)context options:(PentabitAdsPentabitAdsOptions *)options __attribute__((swift_name("initialize(context:options:)")));
- (PentabitAdsInterstitialAd *)interstitialPlacementId:(NSString *)placementId __attribute__((swift_name("interstitial(placementId:)")));
- (PentabitAdsNativeAdLoader *)nativeAdsPlacementId:(NSString *)placementId __attribute__((swift_name("nativeAds(placementId:)")));
- (PentabitAdsRewardedAd *)rewardedPlacementId:(NSString *)placementId __attribute__((swift_name("rewarded(placementId:)")));

/** Pass the user's consent and age signals. Call again whenever they change. */
- (void)setConsentSignals:(PentabitAdsConsentSignals *)signals __attribute__((swift_name("setConsent(signals:)")));
- (void)shutdown __attribute__((swift_name("shutdown()")));
@property (readonly) BOOL isInitialized __attribute__((swift_name("isInitialized")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PentabitAdsOptions")))
@interface PentabitAdsPentabitAdsOptions : PentabitAdsBase
- (instancetype)initWithAppKey:(NSString *)appKey audience:(PentabitAdsAudienceProfile *)audience debug:(BOOL)debug __attribute__((swift_name("init(appKey:audience:debug:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsPentabitAdsOptions *)doCopyAppKey:(NSString *)appKey audience:(PentabitAdsAudienceProfile *)audience debug:(BOOL)debug __attribute__((swift_name("doCopy(appKey:audience:debug:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *appKey __attribute__((swift_name("appKey")));

/** Declare the audience once. CHILD_DIRECTED forces the strictest mode regardless of consent signals. */
@property (readonly) PentabitAdsAudienceProfile *audience __attribute__((swift_name("audience")));

/**
 * Debug builds. Shows Pentabit **test ads** (never live ads, no revenue, nothing billed or counted in live
 * reporting) and turns on logging. Pass `BuildConfig.DEBUG` on Android. Must be false in release builds.
 */
@property (readonly) BOOL debug __attribute__((swift_name("debug")));
@end


/**
 * Drop-in banner. Add it to your view, give it a frame, then call [load]. Banners are HTML creatives
 * rendered through the same MRAID web view as every other web ad. Call [destroy] when you are done.
 */
__attribute__((unavailable("Kotlin subclass of Objective-C class can't be imported")))
__attribute__((swift_name("PentabitBannerView")))
@interface PentabitAdsPentabitBannerView : NSObject
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RewardItem")))
@interface PentabitAdsRewardItem : PentabitAdsBase
- (instancetype)initWithType:(NSString *)type amount:(int32_t)amount __attribute__((swift_name("init(type:amount:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsRewardItem *)doCopyType:(NSString *)type amount:(int32_t)amount __attribute__((swift_name("doCopy(type:amount:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t amount __attribute__((swift_name("amount")));
@property (readonly) NSString *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RewardedAd")))
@interface PentabitAdsRewardedAd : PentabitAdsFullScreenAd
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValuePrecision")))
@interface PentabitAdsValuePrecision : PentabitAdsKotlinEnum<PentabitAdsValuePrecision *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAdsValuePrecision *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) PentabitAdsValuePrecision *estimated __attribute__((swift_name("estimated")));
@property (class, readonly) PentabitAdsValuePrecision *precise __attribute__((swift_name("precise")));
+ (PentabitAdsKotlinArray<PentabitAdsValuePrecision *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAdsValuePrecision *> *entries __attribute__((swift_name("entries")));
@end


/** What a native video player reports back. Implemented by the ads module, called by pentabit-ads-video. */
__attribute__((swift_name("VideoListener")))
@protocol PentabitAdsVideoListener
@required
- (void)onCompleted __attribute__((swift_name("onCompleted()")));
- (void)onErrorMessage:(NSString *)message __attribute__((swift_name("onError(message:)")));
- (void)onMuteChangedMuted:(BOOL)muted __attribute__((swift_name("onMuteChanged(muted:)")));
- (void)onPaused __attribute__((swift_name("onPaused()")));
- (void)onPositionPositionMs:(int64_t)positionMs __attribute__((swift_name("onPosition(positionMs:)")));
- (void)onResumed __attribute__((swift_name("onResumed()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AnalyticsOptions")))
@interface PentabitAdsAnalyticsOptions : PentabitAdsBase
- (instancetype)initWithAppKey:(NSString *)appKey audience:(PentabitAdsAudienceProfile *)audience debug:(BOOL)debug __attribute__((swift_name("init(appKey:audience:debug:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsAnalyticsOptions *)doCopyAppKey:(NSString *)appKey audience:(PentabitAdsAudienceProfile *)audience debug:(BOOL)debug __attribute__((swift_name("doCopy(appKey:audience:debug:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *appKey __attribute__((swift_name("appKey")));

/** Declare the audience once. CHILD_DIRECTED stops all action tracking. */
@property (readonly) PentabitAdsAudienceProfile *audience __attribute__((swift_name("audience")));

/**
 * Debug builds. Actions are flagged as test traffic (the backend must not attribute or bill them) and
 * logging is turned on. Pass `BuildConfig.DEBUG` on Android. Must be false in release builds.
 */
@property (readonly) BOOL debug __attribute__((swift_name("debug")));
@end


/** A link that opened the app from a Pentabit-served ad. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeepLink")))
@interface PentabitAdsDeepLink : PentabitAdsBase
- (instancetype)initWithUrl:(NSString *)url path:(NSString *)path campaign:(NSString * _Nullable)campaign clickId:(NSString * _Nullable)clickId params:(NSDictionary<NSString *, NSString *> *)params __attribute__((swift_name("init(url:path:campaign:clickId:params:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsDeepLink *)doCopyUrl:(NSString *)url path:(NSString *)path campaign:(NSString * _Nullable)campaign clickId:(NSString * _Nullable)clickId params:(NSDictionary<NSString *, NSString *> *)params __attribute__((swift_name("doCopy(url:path:campaign:clickId:params:)")));

/** A link that opened the app from a Pentabit-served ad. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** A link that opened the app from a Pentabit-served ad. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** A link that opened the app from a Pentabit-served ad. */
- (NSString *)description __attribute__((swift_name("description()")));

/** Campaign identifier added by the Pentabit backend (`aks_campaign`). */
@property (readonly) NSString * _Nullable campaign __attribute__((swift_name("campaign")));

/** Click identifier added by the Pentabit backend (`aks_cid`). */
@property (readonly) NSString * _Nullable clickId __attribute__((swift_name("clickId")));

/** All other query parameters. */
@property (readonly) NSDictionary<NSString *, NSString *> *params __attribute__((swift_name("params")));
@property (readonly) NSString *path __attribute__((swift_name("path")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end


/** Reads a deep link without any platform code. Anything that is not a valid link gives null. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeepLinkResolver")))
@interface PentabitAdsDeepLinkResolver : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));

/** Reads a deep link without any platform code. Anything that is not a valid link gives null. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)deepLinkResolver __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsDeepLinkResolver *shared __attribute__((swift_name("shared")));
- (PentabitAdsDeepLink * _Nullable)parseUrl:(NSString *)url __attribute__((swift_name("parse(url:)")));
@end


/**
 * Pentabit Analytics: the small SDK for apps that are advertised. It reports the actions advertisers pay for
 * (installs, sign-ups, purchases and so on). Call [initialize] once at app start; every other call
 * returns at once and never throws.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PentabitAnalytics")))
@interface PentabitAdsPentabitAnalytics : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Pentabit Analytics: the small SDK for apps that are advertised. It reports the actions advertisers pay for
 * (installs, sign-ups, purchases and so on). Call [initialize] once at app start; every other call
 * returns at once and never throws.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)pentabitAnalytics __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsPentabitAnalytics *shared __attribute__((swift_name("shared")));

/**
 * Call with the URL that opened the app. If it carries Pentabit campaign data, a deep_link_open event
 * is reported. Returns the parsed link, or null if it is not a usable link.
 */
- (PentabitAdsDeepLink * _Nullable)handleDeepLinkUrl:(NSString *)url __attribute__((swift_name("handleDeepLink(url:)")));
- (void)initializeContext:(PentabitAdsPlatformContext *)context options:(PentabitAdsAnalyticsOptions *)options __attribute__((swift_name("initialize(context:options:)")));

/** Pass the user's consent and age signals. Call again whenever they change. */
- (void)setConsentSignals:(PentabitAdsConsentSignals *)signals __attribute__((swift_name("setConsent(signals:)")));
- (void)shutdown __attribute__((swift_name("shutdown()")));

/**
 * Reports a custom action. [name] is lower-case letters, digits and underscores (max 40).
 * Returns false if the SDK is not started or the arguments are invalid.
 */
- (BOOL)trackName:(NSString *)name params:(NSDictionary<NSString *, NSString *> *)params value:(PentabitAdsDouble * _Nullable)value currency:(NSString * _Nullable)currency __attribute__((swift_name("track(name:params:value:currency:)")));
- (BOOL)trackFeatureUsedFeature:(NSString *)feature __attribute__((swift_name("trackFeatureUsed(feature:)")));
- (BOOL)trackLevelReachedLevel:(int32_t)level __attribute__((swift_name("trackLevelReached(level:)")));
- (BOOL)trackPurchaseRevenue:(double)revenue currency:(NSString *)currency productId:(NSString * _Nullable)productId __attribute__((swift_name("trackPurchase(revenue:currency:productId:)")));
- (BOOL)trackRegistrationMethod:(NSString * _Nullable)method __attribute__((swift_name("trackRegistration(method:)")));
- (BOOL)trackSubscribeRevenue:(double)revenue currency:(NSString *)currency productId:(NSString * _Nullable)productId __attribute__((swift_name("trackSubscribe(revenue:currency:productId:)")));
- (BOOL)trackTutorialComplete __attribute__((swift_name("trackTutorialComplete()")));
@property (readonly) BOOL isInitialized __attribute__((swift_name("isInitialized")));
@end


/**
 * The composition root for everything both SDKs share. Nothing outside this class (and the
 * module graphs built on it) constructs a platform or network class.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CoreGraph")))
@interface PentabitAdsCoreGraph : PentabitAdsBase
- (instancetype)initWithPlatform:(id<PentabitAdsPlatformModule>)platform options:(PentabitAdsCoreOptions *)options onUploadReply:(id<PentabitAdsKotlinSuspendFunction1> _Nullable)onUploadReply __attribute__((swift_name("init(platform:options:onUploadReply:)"))) __attribute__((objc_designated_initializer));
- (void)shutdown __attribute__((swift_name("shutdown()")));

/** Loads the cached config, refreshes it in the background and starts the event timer. Returns at once. */
- (void)start __attribute__((swift_name("start()")));
@property (readonly) PentabitAdsApiClient *api __attribute__((swift_name("api")));
@property (readonly) PentabitAdsConfigRepository *config __attribute__((swift_name("config")));
@property (readonly) PentabitAdsEventTracker *events __attribute__((swift_name("events")));
@property (readonly) PentabitAdsEventFlusher *flusher __attribute__((swift_name("flusher")));
@property (readonly) PentabitAdsCoreOptions *options __attribute__((swift_name("options")));
@property (readonly) PentabitAdsPixelClient *pixels __attribute__((swift_name("pixels")));
@property (readonly) id<PentabitAdsPlatformModule> platform __attribute__((swift_name("platform")));
@property (readonly) PentabitAdsPrivacyState *privacy __attribute__((swift_name("privacy")));
@property (readonly) PentabitAdsSdkInfo *sdkInfo __attribute__((swift_name("sdkInfo")));
@property (readonly) PentabitAdsSdkScope *sdkScope __attribute__((swift_name("sdkScope")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CoreOptions")))
@interface PentabitAdsCoreOptions : PentabitAdsBase
- (instancetype)initWithAppKey:(NSString *)appKey baseUrl:(NSString *)baseUrl audience:(PentabitAdsAudienceProfile *)audience sdkName:(NSString *)sdkName sdkVersion:(NSString *)sdkVersion debug:(BOOL)debug eventsPath:(NSString *)eventsPath reportUrl:(NSString *)reportUrl __attribute__((swift_name("init(appKey:baseUrl:audience:sdkName:sdkVersion:debug:eventsPath:reportUrl:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsCoreOptions *)doCopyAppKey:(NSString *)appKey baseUrl:(NSString *)baseUrl audience:(PentabitAdsAudienceProfile *)audience sdkName:(NSString *)sdkName sdkVersion:(NSString *)sdkVersion debug:(BOOL)debug eventsPath:(NSString *)eventsPath reportUrl:(NSString *)reportUrl __attribute__((swift_name("doCopy(appKey:baseUrl:audience:sdkName:sdkVersion:debug:eventsPath:reportUrl:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *appKey __attribute__((swift_name("appKey")));
@property (readonly) PentabitAdsAudienceProfile *audience __attribute__((swift_name("audience")));
@property (readonly) NSString *baseUrl __attribute__((swift_name("baseUrl")));
@property (readonly) BOOL debug __attribute__((swift_name("debug")));

/** Where queued events are posted. */
@property (readonly) NSString *eventsPath __attribute__((swift_name("eventsPath")));

/** Where events and actions are sent. Defaults to [baseUrl] (one backend). */
@property (readonly) NSString *reportUrl __attribute__((swift_name("reportUrl")));
@property (readonly) NSString *sdkName __attribute__((swift_name("sdkName")));
@property (readonly) NSString *sdkVersion __attribute__((swift_name("sdkVersion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PentabitEndpoints")))
@interface PentabitAdsPentabitEndpoints : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)pentabitEndpoints __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsPentabitEndpoints *shared __attribute__((swift_name("shared")));

/** Ads backend: app config and ad requests. */
@property (readonly) NSString *BASE_URL __attribute__((swift_name("BASE_URL")));

/** Reporting backend: ad events (impressions, clicks) and in-app actions (installs, purchases). */
@property (readonly) NSString *REPORT_URL __attribute__((swift_name("REPORT_URL")));
@end


/** Keep in step with `pentabit.version` in gradle.properties. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PentabitVersion")))
@interface PentabitAdsPentabitVersion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));

/** Keep in step with `pentabit.version` in gradle.properties. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)pentabitVersion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsPentabitVersion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *VERSION __attribute__((swift_name("VERSION")));
@end


/**
 * Fixed SDK limits. The SDK makes no decisions: what to show, for how long, whether a reward is
 * granted and what a conversion is worth all come from the server, per ad or per reply.
 * These numbers only protect the device (timeouts, sizes, batching).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkDefaults")))
@interface PentabitAdsSdkDefaults : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Fixed SDK limits. The SDK makes no decisions: what to show, for how long, whether a reward is
 * granted and what a conversion is worth all come from the server, per ad or per reply.
 * These numbers only protect the device (timeouts, sizes, batching).
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sdkDefaults __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsSdkDefaults *shared __attribute__((swift_name("shared")));
@property (readonly) int32_t EVENT_BATCH_SIZE __attribute__((swift_name("EVENT_BATCH_SIZE")));
@property (readonly) int32_t EVENT_FLUSH_SECONDS __attribute__((swift_name("EVENT_FLUSH_SECONDS")));
@property (readonly) int32_t EVENT_MAX_AGE_HOURS __attribute__((swift_name("EVENT_MAX_AGE_HOURS")));
@property (readonly) int32_t EVENT_QUEUE_MAX __attribute__((swift_name("EVENT_QUEUE_MAX")));
@property (readonly) int64_t MAX_ASSET_BYTES __attribute__((swift_name("MAX_ASSET_BYTES")));
@property (readonly) int32_t MAX_CLOSE_DELAY_SECONDS __attribute__((swift_name("MAX_CLOSE_DELAY_SECONDS")));
@property (readonly) int32_t MAX_TTL_SECONDS __attribute__((swift_name("MAX_TTL_SECONDS")));
@property (readonly) int32_t MIN_TTL_SECONDS __attribute__((swift_name("MIN_TTL_SECONDS")));
@property (readonly) int64_t REQUEST_TIMEOUT_MS __attribute__((swift_name("REQUEST_TIMEOUT_MS")));
@property (readonly) int32_t VAST_MAX_BITRATE_KBPS __attribute__((swift_name("VAST_MAX_BITRATE_KBPS")));
@property (readonly) int32_t VAST_MAX_WRAPPER_DEPTH __attribute__((swift_name("VAST_MAX_WRAPPER_DEPTH")));
@property (readonly) int64_t VAST_TIMEOUT_MS __attribute__((swift_name("VAST_TIMEOUT_MS")));
@property (readonly) int32_t VIEWABLE_AREA_PERCENT __attribute__((swift_name("VIEWABLE_AREA_PERCENT")));
@property (readonly) int64_t VIEWABLE_MS __attribute__((swift_name("VIEWABLE_MS")));
@property (readonly) int64_t VIEWABLE_VIDEO_MS __attribute__((swift_name("VIEWABLE_VIDEO_MS")));
@end


/**
 * Turns a placement ID into a loaded ad: checks config and consent, asks the backend, resolves
 * VAST if needed and downloads assets. Runs entirely off the main thread (the caller picks the
 * dispatcher; network and disk hops switch to io inside the ports).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdLoader")))
@interface PentabitAdsAdLoader : PentabitAdsBase
- (instancetype)initWithConfig:(PentabitAdsConfigRepository *)config privacy:(PentabitAdsPrivacyState *)privacy deviceInfo:(id<PentabitAdsDeviceInfo>)deviceInfo api:(PentabitAdsApiClient *)api assets:(id<PentabitAdsAssetStore>)assets vastFactory:(PentabitAdsVastResolver *(^)(PentabitAdsInt *, PentabitAdsLong *, PentabitAdsInt *))vastFactory clock:(id<PentabitAdsClock>)clock ids:(id<PentabitAdsIdGenerator>)ids events:(PentabitAdsEventTracker *)events sdk:(PentabitAdsSdkInfo *)sdk testMode:(BOOL)testMode __attribute__((swift_name("init(config:privacy:deviceInfo:api:assets:vastFactory:clock:ids:events:sdk:testMode:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)loadPlacementId:(NSString *)placementId format:(PentabitAdsAdFormat *)format bannerSize:(NSString * _Nullable)bannerSize completionHandler:(void (^)(id<PentabitAdsAdResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("load(placementId:format:bannerSize:completionHandler:)")));
@end


/**
 * One ad, driven by an explicit state machine. A move is only allowed from certain states, which
 * prevents double shows, shows after expiry and leaks.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdSession")))
@interface PentabitAdsAdSession : PentabitAdsBase
- (instancetype)initWithId:(NSString *)id __attribute__((swift_name("init(id:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAdsAdSessionCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isExpiredNowMillis:(int64_t)nowMillis __attribute__((swift_name("isExpired(nowMillis:)")));
- (BOOL)markFailedError:(PentabitAdsAdError *)error __attribute__((swift_name("markFailed(error:)")));
- (BOOL)markLoadedAd:(PentabitAdsLoadedAd *)ad __attribute__((swift_name("markLoaded(ad:)")));

/** Returns false (and changes nothing) when the move is not allowed. */
- (BOOL)transitionTo:(PentabitAdsAdStage *)to __attribute__((swift_name("transition(to:)")));
@property (readonly) PentabitAdsAdError * _Nullable error __attribute__((swift_name("error")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) PentabitAdsLoadedAd * _Nullable loaded __attribute__((swift_name("loaded")));
@property (readonly) id<PentabitAdsKotlinx_coroutines_coreStateFlow> stage __attribute__((swift_name("stage")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdSession.Companion")))
@interface PentabitAdsAdSessionCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsAdSessionCompanion *shared __attribute__((swift_name("shared")));
- (NSSet<PentabitAdsAdStage *> *)allowedFromFrom:(PentabitAdsAdStage *)from __attribute__((swift_name("allowedFrom(from:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdStage")))
@interface PentabitAdsAdStage : PentabitAdsKotlinEnum<PentabitAdsAdStage *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAdsAdStage *idle __attribute__((swift_name("idle")));
@property (class, readonly) PentabitAdsAdStage *loading __attribute__((swift_name("loading")));
@property (class, readonly) PentabitAdsAdStage *ready __attribute__((swift_name("ready")));
@property (class, readonly) PentabitAdsAdStage *showing __attribute__((swift_name("showing")));
@property (class, readonly) PentabitAdsAdStage *completed __attribute__((swift_name("completed")));
@property (class, readonly) PentabitAdsAdStage *expired __attribute__((swift_name("expired")));
@property (class, readonly) PentabitAdsAdStage *failed __attribute__((swift_name("failed")));
@property (class, readonly) PentabitAdsAdStage *destroyed __attribute__((swift_name("destroyed")));
+ (PentabitAdsKotlinArray<PentabitAdsAdStage *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAdsAdStage *> *entries __attribute__((swift_name("entries")));
@end


/** Everything needed to show an ad that has finished loading. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoadedAd")))
@interface PentabitAdsLoadedAd : PentabitAdsBase
- (instancetype)initWithSessionId:(NSString *)sessionId placementId:(NSString *)placementId format:(PentabitAdsAdFormat *)format response:(PentabitAdsAdResponse *)response assets:(NSDictionary<NSString *, PentabitAdsCachedAsset *> *)assets vast:(PentabitAdsResolvedVast * _Nullable)vast videoAsset:(PentabitAdsCachedAsset * _Nullable)videoAsset endCardMarkup:(NSString * _Nullable)endCardMarkup loadedAtMillis:(int64_t)loadedAtMillis expiresAtMillis:(int64_t)expiresAtMillis privacyMode:(PentabitAdsPrivacyMode *)privacyMode __attribute__((swift_name("init(sessionId:placementId:format:response:assets:vast:videoAsset:endCardMarkup:loadedAtMillis:expiresAtMillis:privacyMode:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSDictionary<NSString *, PentabitAdsCachedAsset *> *assets __attribute__((swift_name("assets")));
@property (readonly) NSString * _Nullable endCardMarkup __attribute__((swift_name("endCardMarkup")));
@property (readonly) int64_t expiresAtMillis __attribute__((swift_name("expiresAtMillis")));
@property (readonly) PentabitAdsAdFormat *format __attribute__((swift_name("format")));
@property (readonly) int64_t loadedAtMillis __attribute__((swift_name("loadedAtMillis")));
@property (readonly) NSString *placementId __attribute__((swift_name("placementId")));
@property (readonly) PentabitAdsPrivacyMode *privacyMode __attribute__((swift_name("privacyMode")));
@property (readonly) NSString *requestId __attribute__((swift_name("requestId")));
@property (readonly) PentabitAdsAdResponse *response __attribute__((swift_name("response")));
@property (readonly) NSString *sessionId __attribute__((swift_name("sessionId")));
@property (readonly) PentabitAdsResolvedVast * _Nullable vast __attribute__((swift_name("vast")));
@property (readonly) PentabitAdsCachedAsset * _Nullable videoAsset __attribute__((swift_name("videoAsset")));
@end


/** All dispatchers come from here so tests can replace them with one test dispatcher. */
__attribute__((swift_name("DispatcherProvider")))
@protocol PentabitAdsDispatcherProvider
@required
@property (readonly, getter=default) PentabitAdsKotlinx_coroutines_coreCoroutineDispatcher *default_ __attribute__((swift_name("default_")));
@property (readonly) PentabitAdsKotlinx_coroutines_coreCoroutineDispatcher *io __attribute__((swift_name("io")));
@property (readonly) PentabitAdsKotlinx_coroutines_coreCoroutineDispatcher *main __attribute__((swift_name("main")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultDispatcherProvider")))
@interface PentabitAdsDefaultDispatcherProvider : PentabitAdsBase <PentabitAdsDispatcherProvider>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (readonly, getter=default) PentabitAdsKotlinx_coroutines_coreCoroutineDispatcher *default_ __attribute__((swift_name("default_")));
@property (readonly) PentabitAdsKotlinx_coroutines_coreCoroutineDispatcher *io __attribute__((swift_name("io")));
@property (readonly) PentabitAdsKotlinx_coroutines_coreCoroutineDispatcher *main __attribute__((swift_name("main")));
@end


/** One scope for the whole SDK. A failing child never cancels its siblings. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkScope")))
@interface PentabitAdsSdkScope : PentabitAdsBase
- (instancetype)initWithDispatchers:(id<PentabitAdsDispatcherProvider>)dispatchers onUncaught:(void (^)(PentabitAdsKotlinThrowable *))onUncaught __attribute__((swift_name("init(dispatchers:onUncaught:)"))) __attribute__((objc_designated_initializer));

/** A scope for one ad. Cancelling it never affects the SDK scope. */
- (id<PentabitAdsKotlinx_coroutines_coreCoroutineScope>)child __attribute__((swift_name("child()")));
- (void)shutdown __attribute__((swift_name("shutdown()")));
@property (readonly) id<PentabitAdsKotlinx_coroutines_coreCoroutineScope> scope __attribute__((swift_name("scope")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConfigParser")))
@interface PentabitAdsConfigParser : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)configParser __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsConfigParser *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsAdResult>)parseText:(NSString *)text __attribute__((swift_name("parse(text:)")));
- (id<PentabitAdsAdResult>)validateConfig:(PentabitAdsSdkConfig *)config __attribute__((swift_name("validate(config:)")));
@end


/**
 * Holds the current config. The last good config is kept on disk, so the SDK works offline.
 * An invalid config is rejected and the previous one stays.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConfigRepository")))
@interface PentabitAdsConfigRepository : PentabitAdsBase
- (instancetype)initWithApi:(PentabitAdsApiClient *)api store:(id<PentabitAdsKeyValueStore>)store clock:(id<PentabitAdsClock>)clock logger:(id<PentabitAdsLogger>)logger __attribute__((swift_name("init(api:store:clock:logger:)"))) __attribute__((objc_designated_initializer));
- (id<PentabitAdsAdResult>)findPlacementId:(NSString *)id __attribute__((swift_name("findPlacement(id:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)loadCachedWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("loadCached(completionHandler:)")));

/** Called on HTTP 401/403 from any ad or config call: forget the config so nothing can load.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)markUnauthorizedWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("markUnauthorized(completionHandler:)")));

/** Fetches a new config unless one was fetched recently.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)refreshForce:(BOOL)force completionHandler:(void (^)(id<PentabitAdsAdResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("refresh(force:completionHandler:)")));
@property (readonly) id<PentabitAdsKotlinx_coroutines_coreStateFlow> current __attribute__((swift_name("current")));

/** True while the backend rejects this app key for this app. No ads are shown and no actions are sent. */
@property (readonly) id<PentabitAdsKotlinx_coroutines_coreStateFlow> unauthorized __attribute__((swift_name("unauthorized")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventConfig")))
@interface PentabitAdsEventConfig : PentabitAdsBase
- (instancetype)initWithBatchSize:(int32_t)batchSize flushIntervalSeconds:(int32_t)flushIntervalSeconds __attribute__((swift_name("init(batchSize:flushIntervalSeconds:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAdsEventConfigCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAdsEventConfig *)doCopyBatchSize:(int32_t)batchSize flushIntervalSeconds:(int32_t)flushIntervalSeconds __attribute__((swift_name("doCopy(batchSize:flushIntervalSeconds:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t batchSize __attribute__((swift_name("batchSize")));
@property (readonly) int32_t flushIntervalSeconds __attribute__((swift_name("flushIntervalSeconds")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventConfig.Companion")))
@interface PentabitAdsEventConfigCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsEventConfigCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/** One ad slot the app may use. Everything else about an ad comes with the ad itself.
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlacementConfig")))
@interface PentabitAdsPlacementConfig : PentabitAdsBase
- (instancetype)initWithId:(NSString *)id format:(PentabitAdsAdFormat *)format enabled:(BOOL)enabled __attribute__((swift_name("init(id:format:enabled:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAdsPlacementConfigCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAdsPlacementConfig *)doCopyId:(NSString *)id format:(PentabitAdsAdFormat *)format enabled:(BOOL)enabled __attribute__((swift_name("doCopy(id:format:enabled:)")));

/** One ad slot the app may use. Everything else about an ad comes with the ad itself. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** One ad slot the app may use. Everything else about an ad comes with the ad itself. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** One ad slot the app may use. Everything else about an ad comes with the ad itself. */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL enabled __attribute__((swift_name("enabled")));
@property (readonly) PentabitAdsAdFormat *format __attribute__((swift_name("format")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@end


/** One ad slot the app may use. Everything else about an ad comes with the ad itself. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlacementConfig.Companion")))
@interface PentabitAdsPlacementConfigCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));

/** One ad slot the app may use. Everything else about an ad comes with the ad itself. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsPlacementConfigCompanion *shared __attribute__((swift_name("shared")));

/** One ad slot the app may use. Everything else about an ad comes with the ad itself. */
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/** The slim config: what the SDK must know before it asks for an ad.
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkConfig")))
@interface PentabitAdsSdkConfig : PentabitAdsBase
- (instancetype)initWithVersion:(int64_t)version killSwitch:(BOOL)killSwitch refreshIntervalSeconds:(int32_t)refreshIntervalSeconds placements:(NSArray<PentabitAdsPlacementConfig *> *)placements events:(PentabitAdsEventConfig *)events __attribute__((swift_name("init(version:killSwitch:refreshIntervalSeconds:placements:events:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAdsSdkConfigCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAdsSdkConfig *)doCopyVersion:(int64_t)version killSwitch:(BOOL)killSwitch refreshIntervalSeconds:(int32_t)refreshIntervalSeconds placements:(NSArray<PentabitAdsPlacementConfig *> *)placements events:(PentabitAdsEventConfig *)events __attribute__((swift_name("doCopy(version:killSwitch:refreshIntervalSeconds:placements:events:)")));

/** The slim config: what the SDK must know before it asks for an ad. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** The slim config: what the SDK must know before it asks for an ad. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** The slim config: what the SDK must know before it asks for an ad. */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PentabitAdsEventConfig *events __attribute__((swift_name("events")));
@property (readonly) BOOL killSwitch __attribute__((swift_name("killSwitch")));
@property (readonly) NSArray<PentabitAdsPlacementConfig *> *placements __attribute__((swift_name("placements")));
@property (readonly) int32_t refreshIntervalSeconds __attribute__((swift_name("refreshIntervalSeconds")));
@property (readonly) int64_t version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkConfig.Companion")))
@interface PentabitAdsSdkConfigCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsSdkConfigCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));

/** Safe default: no placements, so no ad can be requested until a real config arrives. */
@property (readonly) PentabitAdsSdkConfig *SAFE_DEFAULT __attribute__((swift_name("SAFE_DEFAULT")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdError")))
@interface PentabitAdsAdError : PentabitAdsBase
- (instancetype)initWithCode:(PentabitAdsAdErrorCode *)code message:(NSString *)message __attribute__((swift_name("init(code:message:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsAdError *)doCopyCode:(PentabitAdsAdErrorCode *)code message:(NSString *)message __attribute__((swift_name("doCopy(code:message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PentabitAdsAdErrorCode *code __attribute__((swift_name("code")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end


/** Stable error codes. Publishers can rely on these never changing meaning. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdErrorCode")))
@interface PentabitAdsAdErrorCode : PentabitAdsKotlinEnum<PentabitAdsAdErrorCode *>
+ (instancetype)alloc __attribute__((unavailable));

/** Stable error codes. Publishers can rely on these never changing meaning. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAdsAdErrorCode *notInitialized __attribute__((swift_name("notInitialized")));
@property (class, readonly) PentabitAdsAdErrorCode *placementNotFound __attribute__((swift_name("placementNotFound")));
@property (class, readonly) PentabitAdsAdErrorCode *placementDisabled __attribute__((swift_name("placementDisabled")));
@property (class, readonly) PentabitAdsAdErrorCode *killSwitch __attribute__((swift_name("killSwitch")));
@property (class, readonly) PentabitAdsAdErrorCode *appNotAuthorized __attribute__((swift_name("appNotAuthorized")));
@property (class, readonly) PentabitAdsAdErrorCode *consentBlocked __attribute__((swift_name("consentBlocked")));
@property (class, readonly) PentabitAdsAdErrorCode *noFill __attribute__((swift_name("noFill")));
@property (class, readonly) PentabitAdsAdErrorCode *timeout __attribute__((swift_name("timeout")));
@property (class, readonly) PentabitAdsAdErrorCode *network __attribute__((swift_name("network")));
@property (class, readonly) PentabitAdsAdErrorCode *assetFailed __attribute__((swift_name("assetFailed")));
@property (class, readonly) PentabitAdsAdErrorCode *expired __attribute__((swift_name("expired")));
@property (class, readonly) PentabitAdsAdErrorCode *internal __attribute__((swift_name("internal")));
+ (PentabitAdsKotlinArray<PentabitAdsAdErrorCode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAdsAdErrorCode *> *entries __attribute__((swift_name("entries")));
@end


/** Result type used across the SDK instead of exceptions. */
__attribute__((swift_name("AdResult")))
@protocol PentabitAdsAdResult
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdResultFailure")))
@interface PentabitAdsAdResultFailure : PentabitAdsBase <PentabitAdsAdResult>
- (instancetype)initWithError:(PentabitAdsAdError *)error __attribute__((swift_name("init(error:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsAdResultFailure *)doCopyError:(PentabitAdsAdError *)error __attribute__((swift_name("doCopy(error:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PentabitAdsAdError *error __attribute__((swift_name("error")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdResultSuccess")))
@interface PentabitAdsAdResultSuccess<__covariant T> : PentabitAdsBase <PentabitAdsAdResult>
- (instancetype)initWithValue:(T _Nullable)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsAdResultSuccess<T> *)doCopyValue:(T _Nullable)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) T _Nullable value __attribute__((swift_name("value")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventContext")))
@interface PentabitAdsEventContext : PentabitAdsBase
- (instancetype)initWithApp:(PentabitAdsAppInfo *)app device:(PentabitAdsDeviceContext *)device privacy:(PentabitAdsPrivacyContext *)privacy sdk:(PentabitAdsSdkInfo *)sdk sessionId:(NSString *)sessionId clockOffsetMs:(PentabitAdsLong * _Nullable)clockOffsetMs testMode:(BOOL)testMode __attribute__((swift_name("init(app:device:privacy:sdk:sessionId:clockOffsetMs:testMode:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAdsEventContextCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAdsEventContext *)doCopyApp:(PentabitAdsAppInfo *)app device:(PentabitAdsDeviceContext *)device privacy:(PentabitAdsPrivacyContext *)privacy sdk:(PentabitAdsSdkInfo *)sdk sessionId:(NSString *)sessionId clockOffsetMs:(PentabitAdsLong * _Nullable)clockOffsetMs testMode:(BOOL)testMode __attribute__((swift_name("doCopy(app:device:privacy:sdk:sessionId:clockOffsetMs:testMode:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PentabitAdsAppInfo *app __attribute__((swift_name("app")));

/** Device clock minus last seen server time, when known. */
@property (readonly) PentabitAdsLong * _Nullable clockOffsetMs __attribute__((swift_name("clockOffsetMs")));
@property (readonly) PentabitAdsDeviceContext *device __attribute__((swift_name("device")));
@property (readonly) PentabitAdsPrivacyContext *privacy __attribute__((swift_name("privacy")));
@property (readonly) PentabitAdsSdkInfo *sdk __attribute__((swift_name("sdk")));

/** Random per-process ID. Used instead of a persistent ID when the privacy mode forbids one. */
@property (readonly) NSString *sessionId __attribute__((swift_name("sessionId")));

/** True for debug builds: the backend must keep this traffic out of live reporting and billing. */
@property (readonly) BOOL testMode __attribute__((swift_name("testMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventContext.Companion")))
@interface PentabitAdsEventContextCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsEventContextCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/** Runs the flush timer, with backoff after failures. Only one flush runs at a time. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventFlusher")))
@interface PentabitAdsEventFlusher : PentabitAdsBase
- (instancetype)initWithUploader:(PentabitAdsEventUploader *)uploader scope:(id<PentabitAdsKotlinx_coroutines_coreCoroutineScope>)scope flushIntervalSeconds:(PentabitAdsInt *(^)(void))flushIntervalSeconds retry:(PentabitAdsRetryPolicy *)retry __attribute__((swift_name("init(uploader:scope:flushIntervalSeconds:retry:)"))) __attribute__((objc_designated_initializer));

/** Call when the app goes to the background so queued events are sent before the process may stop.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)flushAndWaitWithCompletionHandler:(void (^)(PentabitAdsFlushOutcome * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("flushAndWait(completionHandler:)")));
- (void)flushNow __attribute__((swift_name("flushNow()")));
- (void)start __attribute__((swift_name("start()")));
- (void)stop __attribute__((swift_name("stop()")));
@end


/** Standard event names used by both SDKs. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventNames")))
@interface PentabitAdsEventNames : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));

/** Standard event names used by both SDKs. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)eventNames __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsEventNames *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *CLICK __attribute__((swift_name("CLICK")));
@property (readonly) NSString *CLOSE __attribute__((swift_name("CLOSE")));
@property (readonly) NSString *DEEP_LINK_OPEN __attribute__((swift_name("DEEP_LINK_OPEN")));
@property (readonly) NSString *END_CARD_SHOWN __attribute__((swift_name("END_CARD_SHOWN")));
@property (readonly) NSString *ERROR __attribute__((swift_name("ERROR")));
@property (readonly) NSString *FEATURE_USED __attribute__((swift_name("FEATURE_USED")));
@property (readonly) NSString *FIRST_OPEN __attribute__((swift_name("FIRST_OPEN")));

/** Events sent at once instead of waiting for the next batch. */
@property (readonly) NSSet<NSString *> *IMMEDIATE __attribute__((swift_name("IMMEDIATE")));
@property (readonly) NSString *IMPRESSION __attribute__((swift_name("IMPRESSION")));
@property (readonly) NSString *LEVEL_REACHED __attribute__((swift_name("LEVEL_REACHED")));
@property (readonly) NSString *PLAYABLE_COMPLETE __attribute__((swift_name("PLAYABLE_COMPLETE")));
@property (readonly) NSString *PURCHASE __attribute__((swift_name("PURCHASE")));
@property (readonly) NSString *REGISTRATION __attribute__((swift_name("REGISTRATION")));
@property (readonly) NSString *REWARD_EARNED __attribute__((swift_name("REWARD_EARNED")));
@property (readonly) NSString *SKIP __attribute__((swift_name("SKIP")));
@property (readonly) NSString *SUBSCRIBE __attribute__((swift_name("SUBSCRIBE")));
@property (readonly) NSString *TUTORIAL_COMPLETE __attribute__((swift_name("TUTORIAL_COMPLETE")));
@property (readonly) NSString *VIDEO_COMPLETE __attribute__((swift_name("VIDEO_COMPLETE")));
@property (readonly) NSString *VIDEO_MID __attribute__((swift_name("VIDEO_MID")));
@property (readonly) NSString *VIDEO_Q1 __attribute__((swift_name("VIDEO_Q1")));
@property (readonly) NSString *VIDEO_Q3 __attribute__((swift_name("VIDEO_Q3")));
@property (readonly) NSString *VIDEO_START __attribute__((swift_name("VIDEO_START")));
@property (readonly) NSString *VIEWABLE_IMPRESSION __attribute__((swift_name("VIEWABLE_IMPRESSION")));
@end


/**
 * Single entry point for events. It never blocks the caller: the event is written to the durable
 * queue on a background coroutine, then flushed in a batch (or at once for important events).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventTracker")))
@interface PentabitAdsEventTracker : PentabitAdsBase
- (instancetype)initWithStore:(id<PentabitAdsEventStore>)store clock:(id<PentabitAdsClock>)clock ids:(id<PentabitAdsIdGenerator>)ids scope:(id<PentabitAdsKotlinx_coroutines_coreCoroutineScope>)scope logger:(id<PentabitAdsLogger>)logger __attribute__((swift_name("init(store:clock:ids:scope:logger:)"))) __attribute__((objc_designated_initializer));
- (void)attachFlusher:(PentabitAdsEventFlusher *)flusher __attribute__((swift_name("attach(flusher:)")));
- (void)trackName:(NSString *)name requestId:(NSString * _Nullable)requestId placementId:(NSString * _Nullable)placementId params:(NSDictionary<NSString *, NSString *> *)params value:(PentabitAdsDouble * _Nullable)value currency:(NSString * _Nullable)currency __attribute__((swift_name("track(name:requestId:placementId:params:value:currency:)")));
@end


/**
 * Reads batches from the durable queue and posts them. An event is deleted only after the backend
 * confirmed it (2xx) or rejected it as invalid (4xx). Retries are safe because the backend
 * de-duplicates by event ID.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventUploader")))
@interface PentabitAdsEventUploader : PentabitAdsBase
- (instancetype)initWithApi:(PentabitAdsApiClient *)api store:(id<PentabitAdsEventStore>)store clock:(id<PentabitAdsClock>)clock logger:(id<PentabitAdsLogger>)logger contextProvider:(id<PentabitAdsKotlinSuspendFunction0>)contextProvider maxBatchesPerFlush:(int32_t)maxBatchesPerFlush path:(NSString *)path batchSize:(PentabitAdsInt *(^)(void))batchSize onReply:(id<PentabitAdsKotlinSuspendFunction1> _Nullable)onReply __attribute__((swift_name("init(api:store:clock:logger:contextProvider:maxBatchesPerFlush:path:batchSize:onReply:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)flushOnceWithCompletionHandler:(void (^)(PentabitAdsFlushOutcome * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("flushOnce(completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FlushOutcome")))
@interface PentabitAdsFlushOutcome : PentabitAdsKotlinEnum<PentabitAdsFlushOutcome *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAdsFlushOutcome *nothingToSend __attribute__((swift_name("nothingToSend")));
@property (class, readonly) PentabitAdsFlushOutcome *sent __attribute__((swift_name("sent")));
@property (class, readonly) PentabitAdsFlushOutcome *retryLater __attribute__((swift_name("retryLater")));
@property (class, readonly) PentabitAdsFlushOutcome *blocked __attribute__((swift_name("blocked")));
+ (PentabitAdsKotlinArray<PentabitAdsFlushOutcome *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAdsFlushOutcome *> *entries __attribute__((swift_name("entries")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PentabitEvent")))
@interface PentabitAdsPentabitEvent : PentabitAdsBase
- (instancetype)initWithId:(NSString *)id name:(NSString *)name timestamp:(int64_t)timestamp requestId:(NSString * _Nullable)requestId placementId:(NSString * _Nullable)placementId params:(NSDictionary<NSString *, NSString *> *)params value:(PentabitAdsDouble * _Nullable)value currency:(NSString * _Nullable)currency __attribute__((swift_name("init(id:name:timestamp:requestId:placementId:params:value:currency:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAdsPentabitEventCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAdsPentabitEvent *)doCopyId:(NSString *)id name:(NSString *)name timestamp:(int64_t)timestamp requestId:(NSString * _Nullable)requestId placementId:(NSString * _Nullable)placementId params:(NSDictionary<NSString *, NSString *> *)params value:(PentabitAdsDouble * _Nullable)value currency:(NSString * _Nullable)currency __attribute__((swift_name("doCopy(id:name:timestamp:requestId:placementId:params:value:currency:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable currency __attribute__((swift_name("currency")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSDictionary<NSString *, NSString *> *params __attribute__((swift_name("params")));
@property (readonly) NSString * _Nullable placementId __attribute__((swift_name("placementId")));
@property (readonly) NSString * _Nullable requestId __attribute__((swift_name("requestId")));
@property (readonly) int64_t timestamp __attribute__((swift_name("timestamp")));
@property (readonly) PentabitAdsDouble * _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PentabitEvent.Companion")))
@interface PentabitAdsPentabitEventCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsPentabitEventCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Counts an impression once, when at least [minAreaPercent] of the ad has been visible for
 * [minDurationMs] without a break. The defaults live in SdkDefaults.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ViewabilityTracker")))
@interface PentabitAdsViewabilityTracker : PentabitAdsBase
- (instancetype)initWithMinAreaPercent:(int32_t)minAreaPercent minDurationMs:(int64_t)minDurationMs __attribute__((swift_name("init(minAreaPercent:minDurationMs:)"))) __attribute__((objc_designated_initializer));

/** True while the ad is above the area threshold but the time has not elapsed yet. */
- (BOOL)isPending __attribute__((swift_name("isPending()")));
- (int64_t)millisUntilCountedNowMillis:(int64_t)nowMillis __attribute__((swift_name("millisUntilCounted(nowMillis:)")));

/** Feed exposure readings. Returns true exactly once, when the rule is first met. */
- (BOOL)onExposurePercent:(double)percent nowMillis:(int64_t)nowMillis __attribute__((swift_name("onExposure(percent:nowMillis:)")));
@property (readonly) BOOL isCounted __attribute__((swift_name("isCounted")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdFormat")))
@interface PentabitAdsAdFormat : PentabitAdsKotlinEnum<PentabitAdsAdFormat *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) PentabitAdsAdFormatCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) PentabitAdsAdFormat *banner __attribute__((swift_name("banner")));
@property (class, readonly) PentabitAdsAdFormat *native __attribute__((swift_name("native")));
@property (class, readonly) PentabitAdsAdFormat *icon __attribute__((swift_name("icon")));
@property (class, readonly) PentabitAdsAdFormat *interstitial __attribute__((swift_name("interstitial")));
@property (class, readonly) PentabitAdsAdFormat *rewarded __attribute__((swift_name("rewarded")));
@property (class, readonly) PentabitAdsAdFormat *appOpen __attribute__((swift_name("appOpen")));
+ (PentabitAdsKotlinArray<PentabitAdsAdFormat *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAdsAdFormat *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdFormat.Companion")))
@interface PentabitAdsAdFormatCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsAdFormatCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(PentabitAdsKotlinArray<id<PentabitAdsKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdRequest")))
@interface PentabitAdsAdRequest : PentabitAdsBase
- (instancetype)initWithRequestId:(NSString *)requestId placementId:(NSString *)placementId format:(PentabitAdsAdFormat *)format app:(PentabitAdsAppInfo *)app device:(PentabitAdsDeviceContext *)device privacy:(PentabitAdsPrivacyContext *)privacy sdk:(PentabitAdsSdkInfo *)sdk testMode:(BOOL)testMode bannerSize:(NSString * _Nullable)bannerSize __attribute__((swift_name("init(requestId:placementId:format:app:device:privacy:sdk:testMode:bannerSize:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAdsAdRequestCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAdsAdRequest *)doCopyRequestId:(NSString *)requestId placementId:(NSString *)placementId format:(PentabitAdsAdFormat *)format app:(PentabitAdsAppInfo *)app device:(PentabitAdsDeviceContext *)device privacy:(PentabitAdsPrivacyContext *)privacy sdk:(PentabitAdsSdkInfo *)sdk testMode:(BOOL)testMode bannerSize:(NSString * _Nullable)bannerSize __attribute__((swift_name("doCopy(requestId:placementId:format:app:device:privacy:sdk:testMode:bannerSize:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PentabitAdsAppInfo *app __attribute__((swift_name("app")));

/** Banner requests only, "320x50": the backend returns a banner of exactly this size or no ad. */
@property (readonly) NSString * _Nullable bannerSize __attribute__((swift_name("bannerSize")));
@property (readonly) PentabitAdsDeviceContext *device __attribute__((swift_name("device")));
@property (readonly) PentabitAdsAdFormat *format __attribute__((swift_name("format")));
@property (readonly) NSString *placementId __attribute__((swift_name("placementId")));
@property (readonly) PentabitAdsPrivacyContext *privacy __attribute__((swift_name("privacy")));
@property (readonly) NSString *requestId __attribute__((swift_name("requestId")));
@property (readonly) PentabitAdsSdkInfo *sdk __attribute__((swift_name("sdk")));

/** True for debug builds: the backend returns a Pentabit test ad and does not count or bill it. */
@property (readonly) BOOL testMode __attribute__((swift_name("testMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdRequest.Companion")))
@interface PentabitAdsAdRequestCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsAdRequestCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdResponse")))
@interface PentabitAdsAdResponse : PentabitAdsBase
- (instancetype)initWithRequestId:(NSString *)requestId ttlSeconds:(int32_t)ttlSeconds creative:(PentabitAdsCreative *)creative reward:(PentabitAdsRewardSpec * _Nullable)reward closeDelaySeconds:(int32_t)closeDelaySeconds paidMicros:(int64_t)paidMicros paidCurrency:(NSString *)paidCurrency __attribute__((swift_name("init(requestId:ttlSeconds:creative:reward:closeDelaySeconds:paidMicros:paidCurrency:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAdsAdResponseCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAdsAdResponse *)doCopyRequestId:(NSString *)requestId ttlSeconds:(int32_t)ttlSeconds creative:(PentabitAdsCreative *)creative reward:(PentabitAdsRewardSpec * _Nullable)reward closeDelaySeconds:(int32_t)closeDelaySeconds paidMicros:(int64_t)paidMicros paidCurrency:(NSString *)paidCurrency __attribute__((swift_name("doCopy(requestId:ttlSeconds:creative:reward:closeDelaySeconds:paidMicros:paidCurrency:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/** Seconds before the close control shows (server decides; the SDK caps it at 15). A rewarded ad grants its reward when this time has run (web ads) or the video completes. */
@property (readonly) int32_t closeDelaySeconds __attribute__((swift_name("closeDelaySeconds")));
@property (readonly) PentabitAdsCreative *creative __attribute__((swift_name("creative")));
@property (readonly) NSString *paidCurrency __attribute__((swift_name("paidCurrency")));

/** What this impression earned the publisher, in millionths of [paidCurrency]. 0 for cross-promotion. */
@property (readonly) int64_t paidMicros __attribute__((swift_name("paidMicros")));
@property (readonly) NSString *requestId __attribute__((swift_name("requestId")));
@property (readonly) PentabitAdsRewardSpec * _Nullable reward __attribute__((swift_name("reward")));
@property (readonly) int32_t ttlSeconds __attribute__((swift_name("ttlSeconds")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdResponse.Companion")))
@interface PentabitAdsAdResponseCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsAdResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AppInfo")))
@interface PentabitAdsAppInfo : PentabitAdsBase
- (instancetype)initWithId:(NSString *)id version:(NSString *)version __attribute__((swift_name("init(id:version:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAdsAppInfoCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAdsAppInfo *)doCopyId:(NSString *)id version:(NSString *)version __attribute__((swift_name("doCopy(id:version:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString *version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AppInfo.Companion")))
@interface PentabitAdsAppInfoCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsAppInfoCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Creative")))
@interface PentabitAdsCreative : PentabitAdsBase
- (instancetype)initWithType:(PentabitAdsCreativeType *)type markup:(NSString * _Nullable)markup vastXml:(NSString * _Nullable)vastXml vastUrl:(NSString * _Nullable)vastUrl clickUrl:(NSString * _Nullable)clickUrl assets:(NSArray<PentabitAdsCreativeAsset *> *)assets native:(PentabitAdsNativeAssets * _Nullable)native width:(PentabitAdsInt * _Nullable)width height:(PentabitAdsInt * _Nullable)height orientation:(NSString * _Nullable)orientation __attribute__((swift_name("init(type:markup:vastXml:vastUrl:clickUrl:assets:native:width:height:orientation:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAdsCreativeCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAdsCreative *)doCopyType:(PentabitAdsCreativeType *)type markup:(NSString * _Nullable)markup vastXml:(NSString * _Nullable)vastXml vastUrl:(NSString * _Nullable)vastUrl clickUrl:(NSString * _Nullable)clickUrl assets:(NSArray<PentabitAdsCreativeAsset *> *)assets native:(PentabitAdsNativeAssets * _Nullable)native width:(PentabitAdsInt * _Nullable)width height:(PentabitAdsInt * _Nullable)height orientation:(NSString * _Nullable)orientation __attribute__((swift_name("doCopy(type:markup:vastXml:vastUrl:clickUrl:assets:native:width:height:orientation:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<PentabitAdsCreativeAsset *> *assets __attribute__((swift_name("assets")));
@property (readonly) NSString * _Nullable clickUrl __attribute__((swift_name("clickUrl")));
@property (readonly) PentabitAdsInt * _Nullable height __attribute__((swift_name("height")));
@property (readonly) NSString * _Nullable markup __attribute__((swift_name("markup")));
@property (readonly) PentabitAdsNativeAssets * _Nullable native __attribute__((swift_name("native")));
@property (readonly) NSString * _Nullable orientation __attribute__((swift_name("orientation")));
@property (readonly) PentabitAdsCreativeType *type __attribute__((swift_name("type")));
@property (readonly) NSString * _Nullable vastUrl __attribute__((swift_name("vastUrl")));
@property (readonly) NSString * _Nullable vastXml __attribute__((swift_name("vastXml")));
@property (readonly) PentabitAdsInt * _Nullable width __attribute__((swift_name("width")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Creative.Companion")))
@interface PentabitAdsCreativeCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsCreativeCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreativeAsset")))
@interface PentabitAdsCreativeAsset : PentabitAdsBase
- (instancetype)initWithKey:(NSString *)key url:(NSString *)url mime:(NSString * _Nullable)mime sizeBytes:(PentabitAdsLong * _Nullable)sizeBytes sha256:(NSString * _Nullable)sha256 role:(NSString * _Nullable)role __attribute__((swift_name("init(key:url:mime:sizeBytes:sha256:role:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAdsCreativeAssetCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAdsCreativeAsset *)doCopyKey:(NSString *)key url:(NSString *)url mime:(NSString * _Nullable)mime sizeBytes:(PentabitAdsLong * _Nullable)sizeBytes sha256:(NSString * _Nullable)sha256 role:(NSString * _Nullable)role __attribute__((swift_name("doCopy(key:url:mime:sizeBytes:sha256:role:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *key __attribute__((swift_name("key")));
@property (readonly) NSString * _Nullable mime __attribute__((swift_name("mime")));
@property (readonly) NSString * _Nullable role __attribute__((swift_name("role")));
@property (readonly) NSString * _Nullable sha256 __attribute__((swift_name("sha256")));
@property (readonly) PentabitAdsLong * _Nullable sizeBytes __attribute__((swift_name("sizeBytes")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreativeAsset.Companion")))
@interface PentabitAdsCreativeAssetCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsCreativeAssetCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreativeType")))
@interface PentabitAdsCreativeType : PentabitAdsKotlinEnum<PentabitAdsCreativeType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) PentabitAdsCreativeTypeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) PentabitAdsCreativeType *html __attribute__((swift_name("html")));
@property (class, readonly) PentabitAdsCreativeType *image __attribute__((swift_name("image")));
@property (class, readonly) PentabitAdsCreativeType *vast __attribute__((swift_name("vast")));
@property (class, readonly) PentabitAdsCreativeType *native __attribute__((swift_name("native")));
+ (PentabitAdsKotlinArray<PentabitAdsCreativeType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAdsCreativeType *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreativeType.Companion")))
@interface PentabitAdsCreativeTypeCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsCreativeTypeCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(PentabitAdsKotlinArray<id<PentabitAdsKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeviceContext")))
@interface PentabitAdsDeviceContext : PentabitAdsBase
- (instancetype)initWithPlatform:(NSString *)platform osVersion:(NSString *)osVersion deviceClass:(NSString *)deviceClass country:(NSString * _Nullable)country language:(NSString * _Nullable)language advertisingId:(NSString * _Nullable)advertisingId appInstanceId:(NSString * _Nullable)appInstanceId deviceId:(NSString * _Nullable)deviceId __attribute__((swift_name("init(platform:osVersion:deviceClass:country:language:advertisingId:appInstanceId:deviceId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAdsDeviceContextCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAdsDeviceContext *)doCopyPlatform:(NSString *)platform osVersion:(NSString *)osVersion deviceClass:(NSString *)deviceClass country:(NSString * _Nullable)country language:(NSString * _Nullable)language advertisingId:(NSString * _Nullable)advertisingId appInstanceId:(NSString * _Nullable)appInstanceId deviceId:(NSString * _Nullable)deviceId __attribute__((swift_name("doCopy(platform:osVersion:deviceClass:country:language:advertisingId:appInstanceId:deviceId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/** Present only when the privacy mode allows it. */
@property (readonly) NSString * _Nullable advertisingId __attribute__((swift_name("advertisingId")));

/** Present only in NORMAL mode. */
@property (readonly) NSString * _Nullable appInstanceId __attribute__((swift_name("appInstanceId")));
@property (readonly) NSString * _Nullable country __attribute__((swift_name("country")));
@property (readonly) NSString *deviceClass __attribute__((swift_name("deviceClass")));

/** Device-level ID (ANDROID_ID / identifierForVendor). Present only in NORMAL mode. */
@property (readonly) NSString * _Nullable deviceId __attribute__((swift_name("deviceId")));
@property (readonly) NSString * _Nullable language __attribute__((swift_name("language")));
@property (readonly) NSString *osVersion __attribute__((swift_name("osVersion")));
@property (readonly) NSString *platform __attribute__((swift_name("platform")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeviceContext.Companion")))
@interface PentabitAdsDeviceContextCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsDeviceContextCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NativeAssets")))
@interface PentabitAdsNativeAssets : PentabitAdsBase
- (instancetype)initWithTitle:(NSString * _Nullable)title body:(NSString * _Nullable)body callToAction:(NSString * _Nullable)callToAction iconAssetKey:(NSString * _Nullable)iconAssetKey imageAssetKey:(NSString * _Nullable)imageAssetKey sponsoredLabel:(NSString * _Nullable)sponsoredLabel privacyUrl:(NSString * _Nullable)privacyUrl __attribute__((swift_name("init(title:body:callToAction:iconAssetKey:imageAssetKey:sponsoredLabel:privacyUrl:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAdsNativeAssetsCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAdsNativeAssets *)doCopyTitle:(NSString * _Nullable)title body:(NSString * _Nullable)body callToAction:(NSString * _Nullable)callToAction iconAssetKey:(NSString * _Nullable)iconAssetKey imageAssetKey:(NSString * _Nullable)imageAssetKey sponsoredLabel:(NSString * _Nullable)sponsoredLabel privacyUrl:(NSString * _Nullable)privacyUrl __attribute__((swift_name("doCopy(title:body:callToAction:iconAssetKey:imageAssetKey:sponsoredLabel:privacyUrl:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable body __attribute__((swift_name("body")));
@property (readonly) NSString * _Nullable callToAction __attribute__((swift_name("callToAction")));
@property (readonly) NSString * _Nullable iconAssetKey __attribute__((swift_name("iconAssetKey")));
@property (readonly) NSString * _Nullable imageAssetKey __attribute__((swift_name("imageAssetKey")));

/** Where the (i) button leads. Defaults to the Pentabit privacy policy. */
@property (readonly) NSString * _Nullable privacyUrl __attribute__((swift_name("privacyUrl")));
@property (readonly) NSString * _Nullable sponsoredLabel __attribute__((swift_name("sponsoredLabel")));
@property (readonly) NSString * _Nullable title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NativeAssets.Companion")))
@interface PentabitAdsNativeAssetsCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsNativeAssetsCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrivacyContext")))
@interface PentabitAdsPrivacyContext : PentabitAdsBase
- (instancetype)initWithMode:(NSString *)mode tcfString:(NSString * _Nullable)tcfString gppString:(NSString * _Nullable)gppString underAge:(PentabitAdsBoolean * _Nullable)underAge usOptOut:(BOOL)usOptOut userId:(NSString * _Nullable)userId __attribute__((swift_name("init(mode:tcfString:gppString:underAge:usOptOut:userId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAdsPrivacyContextCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAdsPrivacyContext *)doCopyMode:(NSString *)mode tcfString:(NSString * _Nullable)tcfString gppString:(NSString * _Nullable)gppString underAge:(PentabitAdsBoolean * _Nullable)underAge usOptOut:(BOOL)usOptOut userId:(NSString * _Nullable)userId __attribute__((swift_name("doCopy(mode:tcfString:gppString:underAge:usOptOut:userId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable gppString __attribute__((swift_name("gppString")));
@property (readonly) NSString *mode __attribute__((swift_name("mode")));
@property (readonly) NSString * _Nullable tcfString __attribute__((swift_name("tcfString")));
@property (readonly) PentabitAdsBoolean * _Nullable underAge __attribute__((swift_name("underAge")));
@property (readonly) BOOL usOptOut __attribute__((swift_name("usOptOut")));
@property (readonly) NSString * _Nullable userId __attribute__((swift_name("userId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrivacyContext.Companion")))
@interface PentabitAdsPrivacyContextCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsPrivacyContextCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RewardSpec")))
@interface PentabitAdsRewardSpec : PentabitAdsBase
- (instancetype)initWithType:(NSString *)type amount:(int32_t)amount __attribute__((swift_name("init(type:amount:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAdsRewardSpecCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAdsRewardSpec *)doCopyType:(NSString *)type amount:(int32_t)amount __attribute__((swift_name("doCopy(type:amount:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t amount __attribute__((swift_name("amount")));
@property (readonly) NSString *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RewardSpec.Companion")))
@interface PentabitAdsRewardSpecCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsRewardSpecCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkInfo")))
@interface PentabitAdsSdkInfo : PentabitAdsBase
- (instancetype)initWithName:(NSString *)name version:(NSString *)version __attribute__((swift_name("init(name:version:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAdsSdkInfoCompanion *companion __attribute__((swift_name("companion")));
- (PentabitAdsSdkInfo *)doCopyName:(NSString *)name version:(NSString *)version __attribute__((swift_name("doCopy(name:version:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkInfo.Companion")))
@interface PentabitAdsSdkInfoCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsSdkInfoCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/** Builds the HTML the WebView loads. Creatives must be self-contained, so the CSP blocks everything else. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreativeHtml")))
@interface PentabitAdsCreativeHtml : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));

/** Builds the HTML the WebView loads. Creatives must be self-contained, so the CSP blocks everything else. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)creativeHtml __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsCreativeHtml *shared __attribute__((swift_name("shared")));

/** Replaces `[AKS_ASSET:key]` in creative markup with the URL the platform serves that cached asset from. */
- (NSString *)expandAssetsMarkup:(NSString *)markup assetBase:(NSString *)assetBase __attribute__((swift_name("expandAssets(markup:assetBase:)")));

/**
 * Injects the MRAID script, a viewport tag and the content security policy into [markup].
 * [assetOrigins] lists the origins serving cached assets, for example
 * `https://aks-assets.invalid aks-asset://aks-assets.invalid`.
 */
- (NSString *)prepareMarkup:(NSString *)markup assetOrigins:(NSString *)assetOrigins __attribute__((swift_name("prepare(markup:assetOrigins:)")));

/**
 * A static image creative becomes a tiny HTML page, so every creative uses the same MRAID path. The page carries the (i) button:
 * small in the top-right corner of a banner ([compact]), bottom-left on a full-screen ad. A tap opens [PRIVACY_URL] and not the store.
 */
- (NSString *)staticImagePageImageUrl:(NSString *)imageUrl clickUrl:(NSString * _Nullable)clickUrl compact:(BOOL)compact __attribute__((swift_name("staticImagePage(imageUrl:clickUrl:compact:)")));

/** Host used for locally served assets. The platform intercepts requests to it. */
@property (readonly) NSString *ASSET_HOST __attribute__((swift_name("ASSET_HOST")));

/** The page the (i) button opens. Opening it is not a click on the ad. */
@property (readonly) NSString *PRIVACY_URL __attribute__((swift_name("PRIVACY_URL")));
@end


/**
 * The MRAID state machine and message handling, shared by Android and iOS. The platform only
 * injects the script, forwards raw messages here and runs the scripts this class returns.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidController")))
@interface PentabitAdsMraidController : PentabitAdsBase
- (instancetype)initWithPlacement:(PentabitAdsMraidPlacement *)placement listener:(id<PentabitAdsMraidListener>)listener __attribute__((swift_name("init(placement:listener:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PentabitAdsMraidControllerCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)exposureScriptPercent:(double)percent __attribute__((swift_name("exposureScript(percent:)")));
- (void)handleMsg:(id<PentabitAdsMraidMessage>)msg __attribute__((swift_name("handle(msg:)")));
- (id<PentabitAdsMraidMessage> _Nullable)handleRawRaw:(NSString *)raw __attribute__((swift_name("handleRaw(raw:)")));
- (NSString *)hiddenScript __attribute__((swift_name("hiddenScript()")));

/** Scripts to run once the page has loaded. Moves the state from loading to default. */
- (NSArray<NSString *> *)readyScriptsMaxWidth:(int32_t)maxWidth maxHeight:(int32_t)maxHeight screenWidth:(int32_t)screenWidth screenHeight:(int32_t)screenHeight __attribute__((swift_name("readyScripts(maxWidth:maxHeight:screenWidth:screenHeight:)")));
- (NSString *)viewableScriptViewable:(BOOL)viewable __attribute__((swift_name("viewableScript(viewable:)")));
@property (readonly) PentabitAdsMraidState *state __attribute__((swift_name("state")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidController.Companion")))
@interface PentabitAdsMraidControllerCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsMraidControllerCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsMraidMessage> _Nullable)parseRaw:(NSString *)raw __attribute__((swift_name("parse(raw:)")));
@end

__attribute__((swift_name("MraidListener")))
@protocol PentabitAdsMraidListener
@required
- (void)onClose __attribute__((swift_name("onClose()")));
- (void)onCreativeErrorMessage:(NSString *)message __attribute__((swift_name("onCreativeError(message:)")));
- (void)onOpenUrl:(NSString *)url __attribute__((swift_name("onOpen(url:)")));
- (void)onOrientationAllowChange:(BOOL)allowChange force:(NSString *)force __attribute__((swift_name("onOrientation(allowChange:force:)")));
- (void)onPlayableComplete __attribute__((swift_name("onPlayableComplete()")));
- (void)onPlayableCta __attribute__((swift_name("onPlayableCta()")));
- (void)onPlayableReady __attribute__((swift_name("onPlayableReady()")));
@end


/** Messages the creative can send to the host. */
__attribute__((swift_name("MraidMessage")))
@protocol PentabitAdsMraidMessage
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidMessageClose")))
@interface PentabitAdsMraidMessageClose : PentabitAdsBase <PentabitAdsMraidMessage>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)close __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsMraidMessageClose *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidMessageOpen")))
@interface PentabitAdsMraidMessageOpen : PentabitAdsBase <PentabitAdsMraidMessage>
- (instancetype)initWithUrl:(NSString *)url __attribute__((swift_name("init(url:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsMraidMessageOpen *)doCopyUrl:(NSString *)url __attribute__((swift_name("doCopy(url:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidMessageOrientation")))
@interface PentabitAdsMraidMessageOrientation : PentabitAdsBase <PentabitAdsMraidMessage>
- (instancetype)initWithAllowChange:(BOOL)allowChange force:(NSString *)force __attribute__((swift_name("init(allowChange:force:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsMraidMessageOrientation *)doCopyAllowChange:(BOOL)allowChange force:(NSString *)force __attribute__((swift_name("doCopy(allowChange:force:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL allowChange __attribute__((swift_name("allowChange")));
@property (readonly) NSString *force __attribute__((swift_name("force")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidMessagePlayableComplete")))
@interface PentabitAdsMraidMessagePlayableComplete : PentabitAdsBase <PentabitAdsMraidMessage>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)playableComplete __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsMraidMessagePlayableComplete *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidMessagePlayableCta")))
@interface PentabitAdsMraidMessagePlayableCta : PentabitAdsBase <PentabitAdsMraidMessage>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)playableCta __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsMraidMessagePlayableCta *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidMessagePlayableError")))
@interface PentabitAdsMraidMessagePlayableError : PentabitAdsBase <PentabitAdsMraidMessage>
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsMraidMessagePlayableError *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidMessagePlayableReady")))
@interface PentabitAdsMraidMessagePlayableReady : PentabitAdsBase <PentabitAdsMraidMessage>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)playableReady __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsMraidMessagePlayableReady *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidMessageUnload")))
@interface PentabitAdsMraidMessageUnload : PentabitAdsBase <PentabitAdsMraidMessage>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unload __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsMraidMessageUnload *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidPlacement")))
@interface PentabitAdsMraidPlacement : PentabitAdsKotlinEnum<PentabitAdsMraidPlacement *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAdsMraidPlacement *inline_ __attribute__((swift_name("inline_")));
@property (class, readonly) PentabitAdsMraidPlacement *interstitial __attribute__((swift_name("interstitial")));
+ (PentabitAdsKotlinArray<PentabitAdsMraidPlacement *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAdsMraidPlacement *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *wire __attribute__((swift_name("wire")));
@end


/**
 * The mraid.js the SDK injects into every web creative, plus the small `aks` object used by
 * playables. Native code talks to it through `window.__aks`. Written for MRAID 3.0 without
 * expand and resize, which report an error event.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidScript")))
@interface PentabitAdsMraidScript : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * The mraid.js the SDK injects into every web creative, plus the small `aks` object used by
 * playables. Native code talks to it through `window.__aks`. Written for MRAID 3.0 without
 * expand and resize, which report an error event.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)mraidScript __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsMraidScript *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *JS __attribute__((swift_name("JS")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MraidState")))
@interface PentabitAdsMraidState : PentabitAdsKotlinEnum<PentabitAdsMraidState *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAdsMraidState *loading __attribute__((swift_name("loading")));
@property (class, readonly) PentabitAdsMraidState *default_ __attribute__((swift_name("default_")));
@property (class, readonly) PentabitAdsMraidState *hidden __attribute__((swift_name("hidden")));
+ (PentabitAdsKotlinArray<PentabitAdsMraidState *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAdsMraidState *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *wire __attribute__((swift_name("wire")));
@end


/** Only these schemes may be opened from a creative. Everything else is ignored. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UrlPolicy")))
@interface PentabitAdsUrlPolicy : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));

/** Only these schemes may be opened from a creative. Everything else is ignored. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)urlPolicy __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsUrlPolicy *shared __attribute__((swift_name("shared")));
- (BOOL)isAllowedOpenUrlUrl:(NSString *)url __attribute__((swift_name("isAllowedOpenUrl(url:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiClient")))
@interface PentabitAdsApiClient : PentabitAdsBase
- (instancetype)initWithHttp:(id<PentabitAdsHttpClientPort>)http baseUrl:(NSString *)baseUrl clock:(id<PentabitAdsClock>)clock connectivity:(id<PentabitAdsConnectivityMonitor>)connectivity dispatchers:(id<PentabitAdsDispatcherProvider>)dispatchers headers:(NSDictionary<NSString *, NSString *> *(^)(void))headers retry:(PentabitAdsRetryPolicy *)retry breaker:(PentabitAdsCircuitBreaker *)breaker random:(PentabitAdsDouble *(^)(void))random sleep:(id<PentabitAdsKotlinSuspendFunction1>)sleep __attribute__((swift_name("init(http:baseUrl:clock:connectivity:dispatchers:headers:retry:breaker:random:sleep:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getPath:(NSString *)path timeoutMs:(int64_t)timeoutMs retryable:(BOOL)retryable completionHandler:(void (^)(id<PentabitAdsAdResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("get(path:timeoutMs:retryable:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)postPath:(NSString *)path body:(NSString *)body timeoutMs:(int64_t)timeoutMs retryable:(BOOL)retryable extraHeaders:(NSDictionary<NSString *, NSString *> *)extraHeaders completionHandler:(void (^)(id<PentabitAdsAdResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("post(path:body:timeoutMs:retryable:extraHeaders:completionHandler:)")));

/**
 * Returns any HTTP response (including 4xx and 5xx) as Success once retries are used up.
 * Transport problems become Failure with NETWORK or TIMEOUT.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)sendMethod:(NSString *)method path:(NSString *)path body:(NSString * _Nullable)body timeoutMs:(int64_t)timeoutMs retryable:(BOOL)retryable extraHeaders:(NSDictionary<NSString *, NSString *> *)extraHeaders completionHandler:(void (^)(id<PentabitAdsAdResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("send(method:path:body:timeoutMs:retryable:extraHeaders:completionHandler:)")));
@end


/** After repeated failures, calls fail fast for a cool-down so an outage does not drain battery. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CircuitBreaker")))
@interface PentabitAdsCircuitBreaker : PentabitAdsBase
- (instancetype)initWithClock:(id<PentabitAdsClock>)clock failureThreshold:(int32_t)failureThreshold cooldownMs:(int64_t)cooldownMs __attribute__((swift_name("init(clock:failureThreshold:cooldownMs:)"))) __attribute__((objc_designated_initializer));
- (BOOL)isOpen __attribute__((swift_name("isOpen()")));
- (void)recordFailure __attribute__((swift_name("recordFailure()")));
- (void)recordSuccess __attribute__((swift_name("recordSuccess()")));
@end


/** Fires tracking URLs (VAST and creative trackers) on a best-effort basis with one retry. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PixelClient")))
@interface PentabitAdsPixelClient : PentabitAdsBase
- (instancetype)initWithHttp:(id<PentabitAdsHttpClientPort>)http scope:(id<PentabitAdsKotlinx_coroutines_coreCoroutineScope>)scope clock:(id<PentabitAdsClock>)clock logger:(id<PentabitAdsLogger>)logger __attribute__((swift_name("init(http:scope:clock:logger:)"))) __attribute__((objc_designated_initializer));
- (void)fireUrls:(NSArray<NSString *> *)urls macros:(NSDictionary<NSString *, NSString *> *)macros __attribute__((swift_name("fire(urls:macros:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RetryPolicy")))
@interface PentabitAdsRetryPolicy : PentabitAdsBase
- (instancetype)initWithMaxAttempts:(int32_t)maxAttempts baseDelayMs:(int64_t)baseDelayMs maxDelayMs:(int64_t)maxDelayMs __attribute__((swift_name("init(maxAttempts:baseDelayMs:maxDelayMs:)"))) __attribute__((objc_designated_initializer));

/** Exponential backoff with jitter. [attempt] starts at 0 for the first retry. [random] is in 0..1. */
- (int64_t)delayMillisAttempt:(int32_t)attempt random:(double)random __attribute__((swift_name("delayMillis(attempt:random:)")));
@property (readonly) int32_t maxAttempts __attribute__((swift_name("maxAttempts")));
@end

__attribute__((swift_name("AssetStore")))
@protocol PentabitAdsAssetStore
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)downloadUrl:(NSString *)url key:(NSString *)key maxBytes:(int64_t)maxBytes sha256:(NSString * _Nullable)sha256 completionHandler:(void (^)(id<PentabitAdsAdResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("download(url:key:maxBytes:sha256:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getKey:(NSString *)key completionHandler:(void (^)(PentabitAdsCachedAsset * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("get(key:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)releaseKey:(NSString *)key completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("release(key:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)trimToMaxBytes:(int64_t)maxBytes completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("trimTo(maxBytes:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CachedAsset")))
@interface PentabitAdsCachedAsset : PentabitAdsBase
- (instancetype)initWithKey:(NSString *)key path:(NSString *)path sizeBytes:(int64_t)sizeBytes __attribute__((swift_name("init(key:path:sizeBytes:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsCachedAsset *)doCopyKey:(NSString *)key path:(NSString *)path sizeBytes:(int64_t)sizeBytes __attribute__((swift_name("doCopy(key:path:sizeBytes:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *key __attribute__((swift_name("key")));
@property (readonly) NSString *path __attribute__((swift_name("path")));
@property (readonly) int64_t sizeBytes __attribute__((swift_name("sizeBytes")));
@end

__attribute__((swift_name("Clock")))
@protocol PentabitAdsClock
@required
- (int64_t)nowMillis __attribute__((swift_name("nowMillis()")));
@end

__attribute__((swift_name("ConnectivityMonitor")))
@protocol PentabitAdsConnectivityMonitor
@required
- (BOOL)isOnline __attribute__((swift_name("isOnline()")));
@end

__attribute__((swift_name("DeviceInfo")))
@protocol PentabitAdsDeviceInfo
@required

/** The advertising ID, or null when unavailable, denied or zeroed. Callers must check the privacy mode first.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)advertisingIdWithCompletionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("advertisingId(completionHandler:)")));

/** A random per-install ID kept in app-private storage.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)appInstanceIdWithCompletionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("appInstanceId(completionHandler:)")));

/**
 * A device-level ID: Android's ANDROID_ID, iOS's identifierForVendor. Null when unavailable. Callers must check the privacy mode
 * first, and send it only in NORMAL mode.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deviceIdWithCompletionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("deviceId(completionHandler:)")));
@property (readonly) NSString *appId __attribute__((swift_name("appId")));
@property (readonly) NSString *appVersion __attribute__((swift_name("appVersion")));
@property (readonly) NSString * _Nullable country __attribute__((swift_name("country")));
@property (readonly) NSString *deviceClass __attribute__((swift_name("deviceClass")));
@property (readonly) BOOL isLowPowerMode __attribute__((swift_name("isLowPowerMode")));
@property (readonly) NSString * _Nullable language __attribute__((swift_name("language")));
@property (readonly) NSString *osVersion __attribute__((swift_name("osVersion")));
@property (readonly) NSString *platform __attribute__((swift_name("platform")));
@end

__attribute__((swift_name("EventStore")))
@protocol PentabitAdsEventStore
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)countWithCompletionHandler:(void (^)(PentabitAdsLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("count(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteIds:(NSArray<NSString *> *)ids completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("delete(ids:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteOlderThanTimestampMillis:(int64_t)timestampMillis completionHandler:(void (^)(PentabitAdsInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("deleteOlderThan(timestampMillis:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertEvents:(NSArray<PentabitAdsStoredEvent *> *)events completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("insert(events:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readBatchLimit:(int32_t)limit completionHandler:(void (^)(NSArray<PentabitAdsStoredEvent *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readBatch(limit:completionHandler:)")));

/** Keeps only the newest [maxCount] events. Returns how many were removed.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)trimToMaxCount:(int32_t)maxCount completionHandler:(void (^)(PentabitAdsInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("trimTo(maxCount:completionHandler:)")));
@end

__attribute__((swift_name("HttpClientPort")))
@protocol PentabitAdsHttpClientPort
@required

/** Throws [NetworkException] for transport failures; any HTTP status is returned as a response.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeRequest:(PentabitAdsHttpRequest *)request completionHandler:(void (^)(PentabitAdsHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(request:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("HttpRequest")))
@interface PentabitAdsHttpRequest : PentabitAdsBase
- (instancetype)initWithUrl:(NSString *)url method:(NSString *)method headers:(NSDictionary<NSString *, NSString *> *)headers body:(NSString * _Nullable)body timeoutMillis:(int64_t)timeoutMillis __attribute__((swift_name("init(url:method:headers:body:timeoutMillis:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsHttpRequest *)doCopyUrl:(NSString *)url method:(NSString *)method headers:(NSDictionary<NSString *, NSString *> *)headers body:(NSString * _Nullable)body timeoutMillis:(int64_t)timeoutMillis __attribute__((swift_name("doCopy(url:method:headers:body:timeoutMillis:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable body __attribute__((swift_name("body")));
@property (readonly) NSDictionary<NSString *, NSString *> *headers __attribute__((swift_name("headers")));
@property (readonly) NSString *method __attribute__((swift_name("method")));
@property (readonly) int64_t timeoutMillis __attribute__((swift_name("timeoutMillis")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("HttpResponse")))
@interface PentabitAdsHttpResponse : PentabitAdsBase
- (instancetype)initWithStatus:(int32_t)status headers:(NSDictionary<NSString *, NSString *> *)headers body:(NSString *)body __attribute__((swift_name("init(status:headers:body:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsHttpResponse *)doCopyStatus:(int32_t)status headers:(NSDictionary<NSString *, NSString *> *)headers body:(NSString *)body __attribute__((swift_name("doCopy(status:headers:body:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *body __attribute__((swift_name("body")));
@property (readonly) NSDictionary<NSString *, NSString *> *headers __attribute__((swift_name("headers")));
@property (readonly) int32_t status __attribute__((swift_name("status")));
@end

__attribute__((swift_name("IdGenerator")))
@protocol PentabitAdsIdGenerator
@required
- (NSString *)doNewId __attribute__((swift_name("doNewId()")));
@end

__attribute__((swift_name("KeyValueStore")))
@protocol PentabitAdsKeyValueStore
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getStringKey:(NSString *)key completionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getString(key:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)putStringKey:(NSString *)key value:(NSString *)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("putString(key:value:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeKey:(NSString *)key completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("remove(key:completionHandler:)")));
@end

__attribute__((swift_name("Logger")))
@protocol PentabitAdsLogger
@required
- (void)debugTag:(NSString *)tag message:(NSString *)message __attribute__((swift_name("debug(tag:message:)")));
- (void)errorTag:(NSString *)tag message:(NSString *)message error:(PentabitAdsKotlinThrowable * _Nullable)error __attribute__((swift_name("error(tag:message:error:)")));
- (void)warnTag:(NSString *)tag message:(NSString *)message error:(PentabitAdsKotlinThrowable * _Nullable)error __attribute__((swift_name("warn(tag:message:error:)")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface PentabitAdsKotlinThrowable : PentabitAdsBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(PentabitAdsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(PentabitAdsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (PentabitAdsKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PentabitAdsKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface PentabitAdsKotlinException : PentabitAdsKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(PentabitAdsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(PentabitAdsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NetworkException")))
@interface PentabitAdsNetworkException : PentabitAdsKotlinException
- (instancetype)initWithKind:(PentabitAdsNetworkExceptionKind *)kind message:(NSString *)message __attribute__((swift_name("init(kind:message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(PentabitAdsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(PentabitAdsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (readonly) PentabitAdsNetworkExceptionKind *kind __attribute__((swift_name("kind")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NetworkException.Kind")))
@interface PentabitAdsNetworkExceptionKind : PentabitAdsKotlinEnum<PentabitAdsNetworkExceptionKind *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAdsNetworkExceptionKind *timeout __attribute__((swift_name("timeout")));
@property (class, readonly) PentabitAdsNetworkExceptionKind *noConnection __attribute__((swift_name("noConnection")));
@property (class, readonly) PentabitAdsNetworkExceptionKind *other __attribute__((swift_name("other")));
+ (PentabitAdsKotlinArray<PentabitAdsNetworkExceptionKind *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAdsNetworkExceptionKind *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NoopLogger")))
@interface PentabitAdsNoopLogger : PentabitAdsBase <PentabitAdsLogger>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)noopLogger __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsNoopLogger *shared __attribute__((swift_name("shared")));
- (void)debugTag:(NSString *)tag message:(NSString *)message __attribute__((swift_name("debug(tag:message:)")));
- (void)errorTag:(NSString *)tag message:(NSString *)message error:(PentabitAdsKotlinThrowable * _Nullable)error __attribute__((swift_name("error(tag:message:error:)")));
- (void)warnTag:(NSString *)tag message:(NSString *)message error:(PentabitAdsKotlinThrowable * _Nullable)error __attribute__((swift_name("warn(tag:message:error:)")));
@end


/** Everything the platform layer provides. Core never imports a platform class. */
__attribute__((swift_name("PlatformModule")))
@protocol PentabitAdsPlatformModule
@required
@property (readonly) id<PentabitAdsAssetStore> assetStore __attribute__((swift_name("assetStore")));
@property (readonly) id<PentabitAdsClock> clock __attribute__((swift_name("clock")));
@property (readonly) id<PentabitAdsConnectivityMonitor> connectivity __attribute__((swift_name("connectivity")));
@property (readonly) id<PentabitAdsDeviceInfo> deviceInfo __attribute__((swift_name("deviceInfo")));
@property (readonly) id<PentabitAdsDispatcherProvider> dispatchers __attribute__((swift_name("dispatchers")));
@property (readonly) id<PentabitAdsEventStore> eventStore __attribute__((swift_name("eventStore")));
@property (readonly) id<PentabitAdsHttpClientPort> http __attribute__((swift_name("http")));
@property (readonly) id<PentabitAdsIdGenerator> ids __attribute__((swift_name("ids")));
@property (readonly) id<PentabitAdsKeyValueStore> keyValueStore __attribute__((swift_name("keyValueStore")));
@property (readonly) id<PentabitAdsLogger> logger __attribute__((swift_name("logger")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StoredEvent")))
@interface PentabitAdsStoredEvent : PentabitAdsBase
- (instancetype)initWithId:(NSString *)id createdAtMillis:(int64_t)createdAtMillis payload:(NSString *)payload __attribute__((swift_name("init(id:createdAtMillis:payload:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsStoredEvent *)doCopyId:(NSString *)id createdAtMillis:(int64_t)createdAtMillis payload:(NSString *)payload __attribute__((swift_name("doCopy(id:createdAtMillis:payload:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t createdAtMillis __attribute__((swift_name("createdAtMillis")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString *payload __attribute__((swift_name("payload")));
@end


/** Who the app is made for. Declared once by the app at initialize. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AudienceProfile")))
@interface PentabitAdsAudienceProfile : PentabitAdsKotlinEnum<PentabitAdsAudienceProfile *>
+ (instancetype)alloc __attribute__((unavailable));

/** Who the app is made for. Declared once by the app at initialize. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAdsAudienceProfile *childDirected __attribute__((swift_name("childDirected")));
@property (class, readonly) PentabitAdsAudienceProfile *mixedAudience __attribute__((swift_name("mixedAudience")));
@property (class, readonly) PentabitAdsAudienceProfile *general __attribute__((swift_name("general")));
+ (PentabitAdsKotlinArray<PentabitAdsAudienceProfile *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAdsAudienceProfile *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConsentPolicy")))
@interface PentabitAdsConsentPolicy : PentabitAdsBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/** Returns a reason when nothing may be requested or sent, or null when allowed. */
- (NSString * _Nullable)blockReasonSignals:(PentabitAdsConsentSignals *)signals mode:(PentabitAdsPrivacyMode *)mode __attribute__((swift_name("blockReason(signals:mode:)")));

/**
 * Unknown or missing signals fall to the stricter mode, never the looser one.
 */
- (PentabitAdsPrivacyMode *)modeProfile:(PentabitAdsAudienceProfile *)profile signals:(PentabitAdsConsentSignals *)signals advertisingIdAvailable:(BOOL)advertisingIdAvailable __attribute__((swift_name("mode(profile:signals:advertisingIdAvailable:)")));
@end


/** Signals the publisher (or advertiser) supplies from its own consent and age tools. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConsentSignals")))
@interface PentabitAdsConsentSignals : PentabitAdsBase
- (instancetype)initWithPersonalizedAdsAllowed:(PentabitAdsTriState *)personalizedAdsAllowed gdprApplies:(PentabitAdsTriState *)gdprApplies tcfString:(NSString * _Nullable)tcfString gppString:(NSString * _Nullable)gppString usPrivacyOptOut:(BOOL)usPrivacyOptOut isUnderAgeOfConsent:(PentabitAdsTriState *)isUnderAgeOfConsent userId:(NSString * _Nullable)userId __attribute__((swift_name("init(personalizedAdsAllowed:gdprApplies:tcfString:gppString:usPrivacyOptOut:isUnderAgeOfConsent:userId:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsConsentSignals *)doCopyPersonalizedAdsAllowed:(PentabitAdsTriState *)personalizedAdsAllowed gdprApplies:(PentabitAdsTriState *)gdprApplies tcfString:(NSString * _Nullable)tcfString gppString:(NSString * _Nullable)gppString usPrivacyOptOut:(BOOL)usPrivacyOptOut isUnderAgeOfConsent:(PentabitAdsTriState *)isUnderAgeOfConsent userId:(NSString * _Nullable)userId __attribute__((swift_name("doCopy(personalizedAdsAllowed:gdprApplies:tcfString:gppString:usPrivacyOptOut:isUnderAgeOfConsent:userId:)")));

/** Signals the publisher (or advertiser) supplies from its own consent and age tools. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** Signals the publisher (or advertiser) supplies from its own consent and age tools. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** Signals the publisher (or advertiser) supplies from its own consent and age tools. */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PentabitAdsTriState *gdprApplies __attribute__((swift_name("gdprApplies")));
@property (readonly) NSString * _Nullable gppString __attribute__((swift_name("gppString")));
@property (readonly) PentabitAdsTriState *isUnderAgeOfConsent __attribute__((swift_name("isUnderAgeOfConsent")));
@property (readonly) PentabitAdsTriState *personalizedAdsAllowed __attribute__((swift_name("personalizedAdsAllowed")));
@property (readonly) NSString * _Nullable tcfString __attribute__((swift_name("tcfString")));
@property (readonly) BOOL usPrivacyOptOut __attribute__((swift_name("usPrivacyOptOut")));
@property (readonly) NSString * _Nullable userId __attribute__((swift_name("userId")));
@end


/** What the SDK may collect, send and show for the current user. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrivacyMode")))
@interface PentabitAdsPrivacyMode : PentabitAdsKotlinEnum<PentabitAdsPrivacyMode *>
+ (instancetype)alloc __attribute__((unavailable));

/** What the SDK may collect, send and show for the current user. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAdsPrivacyMode *normal __attribute__((swift_name("normal")));
@property (class, readonly) PentabitAdsPrivacyMode *nonPersonalized __attribute__((swift_name("nonPersonalized")));
@property (class, readonly) PentabitAdsPrivacyMode *childDirected __attribute__((swift_name("childDirected")));
+ (PentabitAdsKotlinArray<PentabitAdsPrivacyMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAdsPrivacyMode *> *entries __attribute__((swift_name("entries")));
@property (readonly) BOOL allowAdvertisingId __attribute__((swift_name("allowAdvertisingId")));
@property (readonly) BOOL allowUserId __attribute__((swift_name("allowUserId")));
@property (readonly) BOOL analyticsActionsAllowed __attribute__((swift_name("analyticsActionsAllowed")));
@property (readonly) BOOL persistentEventId __attribute__((swift_name("persistentEventId")));
@property (readonly) BOOL personalized __attribute__((swift_name("personalized")));
@end


/** Holds the current audience profile and consent signals, and computes the mode on demand. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrivacyState")))
@interface PentabitAdsPrivacyState : PentabitAdsBase
- (instancetype)initWithProfile:(PentabitAdsAudienceProfile *)profile deviceInfo:(id<PentabitAdsDeviceInfo>)deviceInfo policy:(PentabitAdsConsentPolicy *)policy __attribute__((swift_name("init(profile:deviceInfo:policy:)"))) __attribute__((objc_designated_initializer));
- (NSString * _Nullable)blockReasonMode:(PentabitAdsPrivacyMode *)mode __attribute__((swift_name("blockReason(mode:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)currentModeWithCompletionHandler:(void (^)(PentabitAdsPrivacyMode * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("currentMode(completionHandler:)")));
- (void)updateSignals:(PentabitAdsConsentSignals *)signals __attribute__((swift_name("update(signals:)")));
@property (readonly) PentabitAdsAudienceProfile *profile __attribute__((swift_name("profile")));
@property (readonly) id<PentabitAdsKotlinx_coroutines_coreStateFlow> signals __attribute__((swift_name("signals")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TriState")))
@interface PentabitAdsTriState : PentabitAdsKotlinEnum<PentabitAdsTriState *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAdsTriState *true_ __attribute__((swift_name("true_")));
@property (class, readonly) PentabitAdsTriState *false_ __attribute__((swift_name("false_")));
@property (class, readonly) PentabitAdsTriState *unknown __attribute__((swift_name("unknown")));
+ (PentabitAdsKotlinArray<PentabitAdsTriState *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAdsTriState *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FakeAssetStore")))
@interface PentabitAdsFakeAssetStore : PentabitAdsBase <PentabitAdsAssetStore>
- (instancetype)initWithFailWith:(NSString * _Nullable)failWith __attribute__((swift_name("init(failWith:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)downloadUrl:(NSString *)url key:(NSString *)key maxBytes:(int64_t)maxBytes sha256:(NSString * _Nullable)sha256 completionHandler:(void (^)(id<PentabitAdsAdResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("download(url:key:maxBytes:sha256:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getKey:(NSString *)key completionHandler:(void (^)(PentabitAdsCachedAsset * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("get(key:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)releaseKey:(NSString *)key completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("release(key:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)trimToMaxBytes:(int64_t)maxBytes completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("trimTo(maxBytes:completionHandler:)")));
@property (readonly) NSMutableArray<NSString *> *downloaded __attribute__((swift_name("downloaded")));
@property NSString * _Nullable failWith __attribute__((swift_name("failWith")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FakeClock")))
@interface PentabitAdsFakeClock : PentabitAdsBase <PentabitAdsClock>
- (instancetype)initWithNow:(int64_t)now __attribute__((swift_name("init(now:)"))) __attribute__((objc_designated_initializer));
- (void)advanceMs:(int64_t)ms __attribute__((swift_name("advance(ms:)")));
- (int64_t)nowMillis __attribute__((swift_name("nowMillis()")));
@property int64_t now __attribute__((swift_name("now")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FakeConnectivity")))
@interface PentabitAdsFakeConnectivity : PentabitAdsBase <PentabitAdsConnectivityMonitor>
- (instancetype)initWithOnline:(BOOL)online __attribute__((swift_name("init(online:)"))) __attribute__((objc_designated_initializer));
- (BOOL)isOnline __attribute__((swift_name("isOnline()")));
@property BOOL online __attribute__((swift_name("online")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FakeDeviceInfo")))
@interface PentabitAdsFakeDeviceInfo : PentabitAdsBase <PentabitAdsDeviceInfo>
- (instancetype)initWithAdId:(NSString * _Nullable)adId platform:(NSString *)platform __attribute__((swift_name("init(adId:platform:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)advertisingIdWithCompletionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("advertisingId(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)appInstanceIdWithCompletionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("appInstanceId(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deviceIdWithCompletionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("deviceId(completionHandler:)")));
@property NSString * _Nullable adId __attribute__((swift_name("adId")));
@property (readonly) NSString *appId __attribute__((swift_name("appId")));
@property (readonly) NSString *appVersion __attribute__((swift_name("appVersion")));
@property (readonly) NSString * _Nullable country __attribute__((swift_name("country")));
@property (readonly) NSString *deviceClass __attribute__((swift_name("deviceClass")));
@property (readonly) BOOL isLowPowerMode __attribute__((swift_name("isLowPowerMode")));
@property (readonly) NSString * _Nullable language __attribute__((swift_name("language")));
@property (readonly) NSString *osVersion __attribute__((swift_name("osVersion")));
@property (readonly) NSString *platform __attribute__((swift_name("platform")));
@end


/** A scriptable HTTP client. [handler] decides each response; throw [NetworkException] to simulate transport errors. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FakeHttp")))
@interface PentabitAdsFakeHttp : PentabitAdsBase <PentabitAdsHttpClientPort>
- (instancetype)initWithHandler:(PentabitAdsHttpResponse *(^)(PentabitAdsHttpRequest *))handler __attribute__((swift_name("init(handler:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeRequest:(PentabitAdsHttpRequest *)request completionHandler:(void (^)(PentabitAdsHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(request:completionHandler:)")));
@property PentabitAdsHttpResponse *(^handler)(PentabitAdsHttpRequest *) __attribute__((swift_name("handler")));
@property (readonly) NSMutableArray<PentabitAdsHttpRequest *> *requests __attribute__((swift_name("requests")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FakePlatform")))
@interface PentabitAdsFakePlatform : PentabitAdsBase <PentabitAdsPlatformModule>
- (instancetype)initWithDispatcher:(PentabitAdsKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher clock:(PentabitAdsFakeClock *)clock http:(PentabitAdsFakeHttp *)http eventStore:(PentabitAdsInMemoryEventStore *)eventStore keyValueStore:(PentabitAdsInMemoryKeyValueStore *)keyValueStore assetStore:(PentabitAdsFakeAssetStore *)assetStore connectivity:(PentabitAdsFakeConnectivity *)connectivity deviceInfo:(PentabitAdsFakeDeviceInfo *)deviceInfo __attribute__((swift_name("init(dispatcher:clock:http:eventStore:keyValueStore:assetStore:connectivity:deviceInfo:)"))) __attribute__((objc_designated_initializer));
@property (readonly) PentabitAdsFakeAssetStore *assetStore __attribute__((swift_name("assetStore")));
@property (readonly) PentabitAdsFakeClock *clock __attribute__((swift_name("clock")));
@property (readonly) PentabitAdsFakeConnectivity *connectivity __attribute__((swift_name("connectivity")));
@property (readonly) PentabitAdsFakeDeviceInfo *deviceInfo __attribute__((swift_name("deviceInfo")));
@property (readonly) id<PentabitAdsDispatcherProvider> dispatchers __attribute__((swift_name("dispatchers")));
@property (readonly) PentabitAdsInMemoryEventStore *eventStore __attribute__((swift_name("eventStore")));
@property (readonly) PentabitAdsFakeHttp *http __attribute__((swift_name("http")));
@property (readonly) id<PentabitAdsIdGenerator> ids __attribute__((swift_name("ids")));
@property (readonly) PentabitAdsInMemoryKeyValueStore *keyValueStore __attribute__((swift_name("keyValueStore")));
@property (readonly) id<PentabitAdsLogger> logger __attribute__((swift_name("logger")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InMemoryEventStore")))
@interface PentabitAdsInMemoryEventStore : PentabitAdsBase <PentabitAdsEventStore>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)countWithCompletionHandler:(void (^)(PentabitAdsLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("count(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteIds:(NSArray<NSString *> *)ids completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("delete(ids:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteOlderThanTimestampMillis:(int64_t)timestampMillis completionHandler:(void (^)(PentabitAdsInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("deleteOlderThan(timestampMillis:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertEvents:(NSArray<PentabitAdsStoredEvent *> *)events completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("insert(events:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readBatchLimit:(int32_t)limit completionHandler:(void (^)(NSArray<PentabitAdsStoredEvent *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readBatch(limit:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)trimToMaxCount:(int32_t)maxCount completionHandler:(void (^)(PentabitAdsInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("trimTo(maxCount:completionHandler:)")));
@property (readonly) NSMutableArray<PentabitAdsStoredEvent *> *rows __attribute__((swift_name("rows")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InMemoryKeyValueStore")))
@interface PentabitAdsInMemoryKeyValueStore : PentabitAdsBase <PentabitAdsKeyValueStore>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getStringKey:(NSString *)key completionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getString(key:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)putStringKey:(NSString *)key value:(NSString *)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("putString(key:value:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeKey:(NSString *)key completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("remove(key:completionHandler:)")));
@property (readonly) PentabitAdsMutableDictionary<NSString *, NSString *> *map __attribute__((swift_name("map")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SequentialIds")))
@interface PentabitAdsSequentialIds : PentabitAdsBase <PentabitAdsIdGenerator>
- (instancetype)initWithPrefix:(NSString *)prefix __attribute__((swift_name("init(prefix:)"))) __attribute__((objc_designated_initializer));
- (NSString *)doNewId __attribute__((swift_name("doNewId()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TestDispatchers")))
@interface PentabitAdsTestDispatchers : PentabitAdsBase <PentabitAdsDispatcherProvider>
- (instancetype)initWithDispatcher:(PentabitAdsKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher __attribute__((swift_name("init(dispatcher:)"))) __attribute__((objc_designated_initializer));
@property (readonly, getter=default) PentabitAdsKotlinx_coroutines_coreCoroutineDispatcher *default_ __attribute__((swift_name("default_")));
@property (readonly) PentabitAdsKotlinx_coroutines_coreCoroutineDispatcher *io __attribute__((swift_name("io")));
@property (readonly) PentabitAdsKotlinx_coroutines_coreCoroutineDispatcher *main __attribute__((swift_name("main")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SystemIds")))
@interface PentabitAdsSystemIds : PentabitAdsBase <PentabitAdsIdGenerator>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)systemIds __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsSystemIds *shared __attribute__((swift_name("shared")));
- (NSString *)doNewId __attribute__((swift_name("doNewId()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MediaSelector")))
@interface PentabitAdsMediaSelector : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)mediaSelector __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsMediaSelector *shared __attribute__((swift_name("shared")));

/** MP4 only in v1. Prefers the highest bitrate at or below the cap, else the lowest available. */
- (PentabitAdsVastMedia * _Nullable)pickFiles:(NSArray<PentabitAdsVastMedia *> *)files maxBitrateKbps:(int32_t)maxBitrateKbps __attribute__((swift_name("pick(files:maxBitrateKbps:)")));
@end


/** A wrapper chain collapsed into one playable ad. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ResolvedVast")))
@interface PentabitAdsResolvedVast : PentabitAdsBase
- (instancetype)initWithImpressions:(NSArray<NSString *> *)impressions errors:(NSArray<NSString *> *)errors durationMs:(int64_t)durationMs skipOffsetMs:(PentabitAdsLong * _Nullable)skipOffsetMs media:(PentabitAdsVastMedia *)media tracking:(NSArray<PentabitAdsVastTracking *> *)tracking clickThrough:(NSString * _Nullable)clickThrough clickTracking:(NSArray<NSString *> *)clickTracking companion:(PentabitAdsVastCompanion * _Nullable)companion __attribute__((swift_name("init(impressions:errors:durationMs:skipOffsetMs:media:tracking:clickThrough:clickTracking:companion:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsResolvedVast *)doCopyImpressions:(NSArray<NSString *> *)impressions errors:(NSArray<NSString *> *)errors durationMs:(int64_t)durationMs skipOffsetMs:(PentabitAdsLong * _Nullable)skipOffsetMs media:(PentabitAdsVastMedia *)media tracking:(NSArray<PentabitAdsVastTracking *> *)tracking clickThrough:(NSString * _Nullable)clickThrough clickTracking:(NSArray<NSString *> *)clickTracking companion:(PentabitAdsVastCompanion * _Nullable)companion __attribute__((swift_name("doCopy(impressions:errors:durationMs:skipOffsetMs:media:tracking:clickThrough:clickTracking:companion:)")));

/** A wrapper chain collapsed into one playable ad. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** A wrapper chain collapsed into one playable ad. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** A wrapper chain collapsed into one playable ad. */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable clickThrough __attribute__((swift_name("clickThrough")));
@property (readonly) NSArray<NSString *> *clickTracking __attribute__((swift_name("clickTracking")));
@property (readonly) PentabitAdsVastCompanion * _Nullable companion __attribute__((swift_name("companion")));
@property (readonly) int64_t durationMs __attribute__((swift_name("durationMs")));
@property (readonly) NSArray<NSString *> *errors __attribute__((swift_name("errors")));
@property (readonly) NSArray<NSString *> *impressions __attribute__((swift_name("impressions")));
@property (readonly) PentabitAdsVastMedia *media __attribute__((swift_name("media")));
@property (readonly) PentabitAdsLong * _Nullable skipOffsetMs __attribute__((swift_name("skipOffsetMs")));
@property (readonly) NSArray<PentabitAdsVastTracking *> *tracking __attribute__((swift_name("tracking")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastAd")))
@interface PentabitAdsVastAd : PentabitAdsBase
- (instancetype)initWithIsWrapper:(BOOL)isWrapper wrapperUrl:(NSString * _Nullable)wrapperUrl impressions:(NSArray<NSString *> *)impressions errors:(NSArray<NSString *> *)errors linear:(PentabitAdsVastLinear * _Nullable)linear companions:(NSArray<PentabitAdsVastCompanion *> *)companions __attribute__((swift_name("init(isWrapper:wrapperUrl:impressions:errors:linear:companions:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsVastAd *)doCopyIsWrapper:(BOOL)isWrapper wrapperUrl:(NSString * _Nullable)wrapperUrl impressions:(NSArray<NSString *> *)impressions errors:(NSArray<NSString *> *)errors linear:(PentabitAdsVastLinear * _Nullable)linear companions:(NSArray<PentabitAdsVastCompanion *> *)companions __attribute__((swift_name("doCopy(isWrapper:wrapperUrl:impressions:errors:linear:companions:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<PentabitAdsVastCompanion *> *companions __attribute__((swift_name("companions")));
@property (readonly) NSArray<NSString *> *errors __attribute__((swift_name("errors")));
@property (readonly) NSArray<NSString *> *impressions __attribute__((swift_name("impressions")));
@property (readonly) BOOL isWrapper __attribute__((swift_name("isWrapper")));
@property (readonly) PentabitAdsVastLinear * _Nullable linear __attribute__((swift_name("linear")));
@property (readonly) NSString * _Nullable wrapperUrl __attribute__((swift_name("wrapperUrl")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastCompanion")))
@interface PentabitAdsVastCompanion : PentabitAdsBase
- (instancetype)initWithWidth:(int32_t)width height:(int32_t)height resourceType:(NSString *)resourceType resource:(NSString *)resource creativeType:(NSString * _Nullable)creativeType clickThrough:(NSString * _Nullable)clickThrough clickTracking:(NSArray<NSString *> *)clickTracking tracking:(NSArray<PentabitAdsVastTracking *> *)tracking __attribute__((swift_name("init(width:height:resourceType:resource:creativeType:clickThrough:clickTracking:tracking:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsVastCompanion *)doCopyWidth:(int32_t)width height:(int32_t)height resourceType:(NSString *)resourceType resource:(NSString *)resource creativeType:(NSString * _Nullable)creativeType clickThrough:(NSString * _Nullable)clickThrough clickTracking:(NSArray<NSString *> *)clickTracking tracking:(NSArray<PentabitAdsVastTracking *> *)tracking __attribute__((swift_name("doCopy(width:height:resourceType:resource:creativeType:clickThrough:clickTracking:tracking:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable clickThrough __attribute__((swift_name("clickThrough")));
@property (readonly) NSArray<NSString *> *clickTracking __attribute__((swift_name("clickTracking")));
@property (readonly) NSString * _Nullable creativeType __attribute__((swift_name("creativeType")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) NSString *resource __attribute__((swift_name("resource")));

/** "html", "static" or "iframe". */
@property (readonly) NSString *resourceType __attribute__((swift_name("resourceType")));
@property (readonly) NSArray<PentabitAdsVastTracking *> *tracking __attribute__((swift_name("tracking")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end


/** Names of VAST tracking events the player reports. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastEvents")))
@interface PentabitAdsVastEvents : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));

/** Names of VAST tracking events the player reports. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)vastEvents __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsVastEvents *shared __attribute__((swift_name("shared")));

/** The Pentabit event that matches a VAST event, if any. */
- (NSString * _Nullable)toPentabitEventVastEvent:(NSString *)vastEvent __attribute__((swift_name("toPentabitEvent(vastEvent:)")));
@property (readonly) NSString *CLOSE __attribute__((swift_name("CLOSE")));
@property (readonly) NSString *COMPLETE __attribute__((swift_name("COMPLETE")));
@property (readonly) NSString *CREATIVE_VIEW __attribute__((swift_name("CREATIVE_VIEW")));
@property (readonly) NSString *FIRST_QUARTILE __attribute__((swift_name("FIRST_QUARTILE")));
@property (readonly) NSString *MIDPOINT __attribute__((swift_name("MIDPOINT")));
@property (readonly) NSString *MUTE __attribute__((swift_name("MUTE")));
@property (readonly) NSString *PAUSE __attribute__((swift_name("PAUSE")));
@property (readonly) NSString *RESUME __attribute__((swift_name("RESUME")));
@property (readonly) NSString *SKIP __attribute__((swift_name("SKIP")));
@property (readonly) NSString *START __attribute__((swift_name("START")));
@property (readonly) NSString *THIRD_QUARTILE __attribute__((swift_name("THIRD_QUARTILE")));
@property (readonly) NSString *UNMUTE __attribute__((swift_name("UNMUTE")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastLinear")))
@interface PentabitAdsVastLinear : PentabitAdsBase
- (instancetype)initWithDurationMs:(PentabitAdsLong * _Nullable)durationMs skipOffset:(NSString * _Nullable)skipOffset mediaFiles:(NSArray<PentabitAdsVastMedia *> *)mediaFiles tracking:(NSArray<PentabitAdsVastTracking *> *)tracking clickThrough:(NSString * _Nullable)clickThrough clickTracking:(NSArray<NSString *> *)clickTracking __attribute__((swift_name("init(durationMs:skipOffset:mediaFiles:tracking:clickThrough:clickTracking:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsVastLinear *)doCopyDurationMs:(PentabitAdsLong * _Nullable)durationMs skipOffset:(NSString * _Nullable)skipOffset mediaFiles:(NSArray<PentabitAdsVastMedia *> *)mediaFiles tracking:(NSArray<PentabitAdsVastTracking *> *)tracking clickThrough:(NSString * _Nullable)clickThrough clickTracking:(NSArray<NSString *> *)clickTracking __attribute__((swift_name("doCopy(durationMs:skipOffset:mediaFiles:tracking:clickThrough:clickTracking:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable clickThrough __attribute__((swift_name("clickThrough")));
@property (readonly) NSArray<NSString *> *clickTracking __attribute__((swift_name("clickTracking")));
@property (readonly) PentabitAdsLong * _Nullable durationMs __attribute__((swift_name("durationMs")));
@property (readonly) NSArray<PentabitAdsVastMedia *> *mediaFiles __attribute__((swift_name("mediaFiles")));
@property (readonly) NSString * _Nullable skipOffset __attribute__((swift_name("skipOffset")));
@property (readonly) NSArray<PentabitAdsVastTracking *> *tracking __attribute__((swift_name("tracking")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastMedia")))
@interface PentabitAdsVastMedia : PentabitAdsBase
- (instancetype)initWithUrl:(NSString *)url mime:(NSString *)mime width:(int32_t)width height:(int32_t)height bitrateKbps:(PentabitAdsInt * _Nullable)bitrateKbps delivery:(NSString *)delivery __attribute__((swift_name("init(url:mime:width:height:bitrateKbps:delivery:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsVastMedia *)doCopyUrl:(NSString *)url mime:(NSString *)mime width:(int32_t)width height:(int32_t)height bitrateKbps:(PentabitAdsInt * _Nullable)bitrateKbps delivery:(NSString *)delivery __attribute__((swift_name("doCopy(url:mime:width:height:bitrateKbps:delivery:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PentabitAdsInt * _Nullable bitrateKbps __attribute__((swift_name("bitrateKbps")));
@property (readonly) NSString *delivery __attribute__((swift_name("delivery")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) NSString *mime __attribute__((swift_name("mime")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end


/** Parses one VAST 2.0 to 4.x document into its first ad. Ad pods are not used in v1. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastParser")))
@interface PentabitAdsVastParser : PentabitAdsBase

/** Parses one VAST 2.0 to 4.x document into its first ad. Ad pods are not used in v1. */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/** Parses one VAST 2.0 to 4.x document into its first ad. Ad pods are not used in v1. */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) PentabitAdsVastParserCompanion *companion __attribute__((swift_name("companion")));
- (id<PentabitAdsAdResult>)parseXml:(NSString *)xml __attribute__((swift_name("parse(xml:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastParser.Companion")))
@interface PentabitAdsVastParserCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsVastParserCompanion *shared __attribute__((swift_name("shared")));

/** Parses "HH:MM:SS" or "HH:MM:SS.mmm" into milliseconds. */
- (PentabitAdsLong * _Nullable)parseTimeMsValue:(NSString *)value __attribute__((swift_name("parseTimeMs(value:)")));
@end


/**
 * Follows a wrapper chain with a depth limit and an overall timeout, then returns one playable ad.
 * Impressions, errors and tracking from every wrapper are merged into the final ad.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastResolver")))
@interface PentabitAdsVastResolver : PentabitAdsBase
- (instancetype)initWithHttp:(id<PentabitAdsHttpClientPort>)http parser:(PentabitAdsVastParser *)parser pixels:(PentabitAdsPixelClient *)pixels maxDepth:(int32_t)maxDepth timeoutMs:(int64_t)timeoutMs maxBitrateKbps:(int32_t)maxBitrateKbps __attribute__((swift_name("init(http:parser:pixels:maxDepth:timeoutMs:maxBitrateKbps:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)resolveXml:(NSString * _Nullable)xml url:(NSString * _Nullable)url completionHandler:(void (^)(id<PentabitAdsAdResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("resolve(xml:url:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VastTracking")))
@interface PentabitAdsVastTracking : PentabitAdsBase
- (instancetype)initWithEvent:(NSString *)event url:(NSString *)url offset:(NSString * _Nullable)offset __attribute__((swift_name("init(event:url:offset:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsVastTracking *)doCopyEvent:(NSString *)event url:(NSString *)url offset:(NSString * _Nullable)offset __attribute__((swift_name("doCopy(event:url:offset:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *event __attribute__((swift_name("event")));
@property (readonly) NSString * _Nullable offset __attribute__((swift_name("offset")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end


/**
 * Turns real playback position into quartile events. Each milestone fires once. Pausing or
 * seeking back never fires a milestone twice, and seeking past one fires it at the next update.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VideoProgressTracker")))
@interface PentabitAdsVideoProgressTracker : PentabitAdsBase
- (instancetype)initWithDurationMs:(int64_t)durationMs emit:(void (^)(NSString *))emit __attribute__((swift_name("init(durationMs:emit:)"))) __attribute__((objc_designated_initializer));
- (void)onCompleted __attribute__((swift_name("onCompleted()")));
- (void)onPositionPositionMs:(int64_t)positionMs __attribute__((swift_name("onPosition(positionMs:)")));
@property (readonly) BOOL isCompleted __attribute__((swift_name("isCompleted")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlatformContext")))
@interface PentabitAdsPlatformContext : PentabitAdsBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Event")))
@interface PentabitAdsEvent : PentabitAdsBase
- (instancetype)initWithId:(NSString *)id created_at:(int64_t)created_at payload:(NSString *)payload __attribute__((swift_name("init(id:created_at:payload:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsEvent *)doCopyId:(NSString *)id created_at:(int64_t)created_at payload:(NSString *)payload __attribute__((swift_name("doCopy(id:created_at:payload:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t created_at __attribute__((swift_name("created_at")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString *payload __attribute__((swift_name("payload")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kv")))
@interface PentabitAdsKv : PentabitAdsBase
- (instancetype)initWithK:(NSString *)k v:(NSString *)v __attribute__((swift_name("init(k:v:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsKv *)doCopyK:(NSString *)k v:(NSString *)v __attribute__((swift_name("doCopy(k:v:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *k __attribute__((swift_name("k")));
@property (readonly) NSString *v __attribute__((swift_name("v")));
@end

__attribute__((swift_name("RuntimeTransacterBase")))
@protocol PentabitAdsRuntimeTransacterBase
@required
@end

__attribute__((swift_name("RuntimeTransacter")))
@protocol PentabitAdsRuntimeTransacter <PentabitAdsRuntimeTransacterBase>
@required
- (void)transactionNoEnclosing:(BOOL)noEnclosing body:(void (^)(id<PentabitAdsRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(noEnclosing:body:)")));
- (id _Nullable)transactionWithResultNoEnclosing:(BOOL)noEnclosing bodyWithReturn:(id _Nullable (^)(id<PentabitAdsRuntimeTransactionWithReturn>))bodyWithReturn __attribute__((swift_name("transactionWithResult(noEnclosing:bodyWithReturn:)")));
@end

__attribute__((swift_name("PentabitDatabase")))
@protocol PentabitAdsPentabitDatabase <PentabitAdsRuntimeTransacter>
@required
@property (readonly) PentabitAdsPentabitQueries *pentabitQueries __attribute__((swift_name("pentabitQueries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PentabitDatabaseCompanion")))
@interface PentabitAdsPentabitDatabaseCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsPentabitDatabaseCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsPentabitDatabase>)invokeDriver:(id<PentabitAdsRuntimeSqlDriver>)driver __attribute__((swift_name("invoke(driver:)")));
@property (readonly) id<PentabitAdsRuntimeSqlSchema> Schema __attribute__((swift_name("Schema")));
@end

__attribute__((swift_name("RuntimeBaseTransacterImpl")))
@interface PentabitAdsRuntimeBaseTransacterImpl : PentabitAdsBase
- (instancetype)initWithDriver:(id<PentabitAdsRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (NSString *)createArgumentsCount:(int32_t)count __attribute__((swift_name("createArguments(count:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)notifyQueriesIdentifier:(int32_t)identifier tableProvider:(void (^)(PentabitAdsKotlinUnit *(^)(NSString *)))tableProvider __attribute__((swift_name("notifyQueries(identifier:tableProvider:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (id _Nullable)postTransactionCleanupTransaction:(PentabitAdsRuntimeTransacterTransaction *)transaction enclosing:(PentabitAdsRuntimeTransacterTransaction * _Nullable)enclosing thrownException:(PentabitAdsKotlinThrowable * _Nullable)thrownException returnValue:(id _Nullable)returnValue __attribute__((swift_name("postTransactionCleanup(transaction:enclosing:thrownException:returnValue:)")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) id<PentabitAdsRuntimeSqlDriver> driver __attribute__((swift_name("driver")));
@end

__attribute__((swift_name("RuntimeTransacterImpl")))
@interface PentabitAdsRuntimeTransacterImpl : PentabitAdsRuntimeBaseTransacterImpl <PentabitAdsRuntimeTransacter>
- (instancetype)initWithDriver:(id<PentabitAdsRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer));
- (void)transactionNoEnclosing:(BOOL)noEnclosing body:(void (^)(id<PentabitAdsRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(noEnclosing:body:)")));
- (id _Nullable)transactionWithResultNoEnclosing:(BOOL)noEnclosing bodyWithReturn:(id _Nullable (^)(id<PentabitAdsRuntimeTransactionWithReturn>))bodyWithReturn __attribute__((swift_name("transactionWithResult(noEnclosing:bodyWithReturn:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PentabitQueries")))
@interface PentabitAdsPentabitQueries : PentabitAdsRuntimeTransacterImpl
- (instancetype)initWithDriver:(id<PentabitAdsRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer));
- (PentabitAdsRuntimeExecutableQuery<PentabitAdsLong *> *)changes __attribute__((swift_name("changes()")));
- (PentabitAdsRuntimeQuery<PentabitAdsLong *> *)countEvents __attribute__((swift_name("countEvents()")));

/**
 * @return The number of rows updated.
 */
- (id<PentabitAdsRuntimeQueryResult>)deleteEventId:(NSString *)id __attribute__((swift_name("deleteEvent(id:)")));

/**
 * @return The number of rows updated.
 */
- (id<PentabitAdsRuntimeQueryResult>)deleteKvK:(NSString *)k __attribute__((swift_name("deleteKv(k:)")));

/**
 * @return The number of rows updated.
 */
- (id<PentabitAdsRuntimeQueryResult>)deleteOlderThanCreated_at:(int64_t)created_at __attribute__((swift_name("deleteOlderThan(created_at:)")));

/**
 * @return The number of rows updated.
 */
- (id<PentabitAdsRuntimeQueryResult>)insertEventId:(NSString *)id created_at:(int64_t)created_at payload:(NSString *)payload __attribute__((swift_name("insertEvent(id:created_at:payload:)")));
- (PentabitAdsRuntimeQuery<PentabitAdsEvent *> *)selectBatchValue_:(int64_t)value_ __attribute__((swift_name("selectBatch(value_:)")));
- (PentabitAdsRuntimeQuery<id> *)selectBatchValue:(int64_t)value mapper:(id (^)(NSString *, PentabitAdsLong *, NSString *))mapper __attribute__((swift_name("selectBatch(value:mapper:)")));
- (PentabitAdsRuntimeQuery<NSString *> *)selectKvK:(NSString *)k __attribute__((swift_name("selectKv(k:)")));

/**
 * @return The number of rows updated.
 */
- (id<PentabitAdsRuntimeQueryResult>)trimToValue:(int64_t)value __attribute__((swift_name("trimTo(value:)")));

/**
 * @return The number of rows updated.
 */
- (id<PentabitAdsRuntimeQueryResult>)upsertKvK:(NSString *)k v:(NSString *)v __attribute__((swift_name("upsertKv(k:v:)")));
@end

@interface PentabitAdsEventContext (Extensions)

/**
 * Everything common to a batch goes in headers, so the body is only the list of events.
 * Empty values are left out. The advertising ID, instance ID and user ID are present only when
 * the privacy mode allowed them (the context already holds null otherwise).
 */
- (NSDictionary<NSString *, NSString *> *)toHeaders __attribute__((swift_name("toHeaders()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AdErrorKt")))
@interface PentabitAdsAdErrorKt : PentabitAdsBase
+ (PentabitAdsAdError * _Nullable)errorOrNull:(id<PentabitAdsAdResult>)receiver __attribute__((swift_name("errorOrNull(_:)")));
+ (PentabitAdsAdResultFailure *)failureCode:(PentabitAdsAdErrorCode *)code message:(NSString *)message __attribute__((swift_name("failure(code:message:)")));
+ (id<PentabitAdsAdResult>)flatMap:(id<PentabitAdsAdResult>)receiver transform:(id<PentabitAdsAdResult> (^)(id _Nullable))transform __attribute__((swift_name("flatMap(_:transform:)")));
+ (id _Nullable)getOrNull:(id<PentabitAdsAdResult>)receiver __attribute__((swift_name("getOrNull(_:)")));

/**
 * Runs [block] and converts any unexpected exception into an INTERNAL failure.
 * Cancellation is always rethrown so structured concurrency keeps working.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
+ (void)guardBlock:(id<PentabitAdsKotlinSuspendFunction0>)block completionHandler:(void (^)(id<PentabitAdsAdResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("guard(block:completionHandler:)")));
+ (id<PentabitAdsAdResult>)map:(id<PentabitAdsAdResult>)receiver transform:(id _Nullable (^)(id _Nullable))transform __attribute__((swift_name("map(_:transform:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NetKt")))
@interface PentabitAdsNetKt : PentabitAdsBase
@property (class, readonly) PentabitAdsKotlinx_serialization_jsonJson *PentabitJson __attribute__((swift_name("PentabitJson")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlatformFactoryKt")))
@interface PentabitAdsPlatformFactoryKt : PentabitAdsBase

/**
 * Builds every platform implementation. [storeName] names the on-device database, so two Pentabit SDKs in one app keep separate queues.
 * A database that cannot be opened never stops the SDK:
 * events fall back to memory for this run.
 */
+ (id<PentabitAdsPlatformModule>)createPlatformModuleContext:(PentabitAdsPlatformContext *)context debug:(BOOL)debug storeName:(NSString *)storeName __attribute__((swift_name("createPlatformModule(context:debug:storeName:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UtilKt")))
@interface PentabitAdsUtilKt : PentabitAdsBase
+ (int64_t)elapsedSince:(id<PentabitAdsClock>)receiver startMillis:(int64_t)startMillis __attribute__((swift_name("elapsedSince(_:startMillis:)")));
+ (NSString *)htmlEscapeValue:(NSString *)value __attribute__((swift_name("htmlEscape(value:)")));

/** Percent-encodes everything except RFC 3986 unreserved characters. */
+ (NSString *)percentEncodeValue:(NSString *)value __attribute__((swift_name("percentEncode(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface PentabitAdsKotlinEnumCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface PentabitAdsKotlinArray<T> : PentabitAdsBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(PentabitAdsInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<PentabitAdsKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("KotlinFunction")))
@protocol PentabitAdsKotlinFunction
@required
@end

__attribute__((swift_name("KotlinSuspendFunction1")))
@protocol PentabitAdsKotlinSuspendFunction1 <PentabitAdsKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:completionHandler:)")));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface PentabitAdsKotlinRuntimeException : PentabitAdsKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(PentabitAdsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(PentabitAdsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface PentabitAdsKotlinIllegalStateException : PentabitAdsKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(PentabitAdsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(PentabitAdsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface PentabitAdsKotlinCancellationException : PentabitAdsKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(PentabitAdsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(PentabitAdsKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol PentabitAdsKotlinx_coroutines_coreFlow
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<PentabitAdsKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSharedFlow")))
@protocol PentabitAdsKotlinx_coroutines_coreSharedFlow <PentabitAdsKotlinx_coroutines_coreFlow>
@required
@property (readonly) NSArray<id> *replayCache __attribute__((swift_name("replayCache")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreStateFlow")))
@protocol PentabitAdsKotlinx_coroutines_coreStateFlow <PentabitAdsKotlinx_coroutines_coreSharedFlow>
@required
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinCoroutineContext")))
@protocol PentabitAdsKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<PentabitAdsKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<PentabitAdsKotlinCoroutineContextElement> _Nullable)getKey:(id<PentabitAdsKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<PentabitAdsKotlinCoroutineContext>)minusKeyKey:(id<PentabitAdsKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<PentabitAdsKotlinCoroutineContext>)plusContext:(id<PentabitAdsKotlinCoroutineContext>)context __attribute__((swift_name("plus(context:)")));
@end

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol PentabitAdsKotlinCoroutineContextElement <PentabitAdsKotlinCoroutineContext>
@required
@property (readonly) id<PentabitAdsKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextElement")))
@interface PentabitAdsKotlinAbstractCoroutineContextElement : PentabitAdsBase <PentabitAdsKotlinCoroutineContextElement>
- (instancetype)initWithKey:(id<PentabitAdsKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<PentabitAdsKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuationInterceptor")))
@protocol PentabitAdsKotlinContinuationInterceptor <PentabitAdsKotlinCoroutineContextElement>
@required
- (id<PentabitAdsKotlinContinuation>)interceptContinuationContinuation:(id<PentabitAdsKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (void)releaseInterceptedContinuationContinuation:(id<PentabitAdsKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher")))
@interface PentabitAdsKotlinx_coroutines_coreCoroutineDispatcher : PentabitAdsKotlinAbstractCoroutineContextElement <PentabitAdsKotlinContinuationInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithKey:(id<PentabitAdsKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) PentabitAdsKotlinx_coroutines_coreCoroutineDispatcherKey *companion __attribute__((swift_name("companion")));
- (void)dispatchContext:(id<PentabitAdsKotlinCoroutineContext>)context block:(id<PentabitAdsKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(context:block:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (void)dispatchYieldContext:(id<PentabitAdsKotlinCoroutineContext>)context block:(id<PentabitAdsKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatchYield(context:block:)")));
- (id<PentabitAdsKotlinContinuation>)interceptContinuationContinuation:(id<PentabitAdsKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (BOOL)isDispatchNeededContext:(id<PentabitAdsKotlinCoroutineContext>)context __attribute__((swift_name("isDispatchNeeded(context:)")));
- (PentabitAdsKotlinx_coroutines_coreCoroutineDispatcher *)limitedParallelismParallelism:(int32_t)parallelism name:(NSString * _Nullable)name __attribute__((swift_name("limitedParallelism(parallelism:name:)")));
- (PentabitAdsKotlinx_coroutines_coreCoroutineDispatcher *)plusOther:(PentabitAdsKotlinx_coroutines_coreCoroutineDispatcher *)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two CoroutineDispatcher objects is meaningless. CoroutineDispatcher is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The dispatcher to the right of `+` just replaces the dispatcher to the left.")));
- (void)releaseInterceptedContinuationContinuation:(id<PentabitAdsKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol PentabitAdsKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<PentabitAdsKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol PentabitAdsKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<PentabitAdsKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<PentabitAdsKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol PentabitAdsKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<PentabitAdsKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<PentabitAdsKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol PentabitAdsKotlinx_serialization_coreKSerializer <PentabitAdsKotlinx_serialization_coreSerializationStrategy, PentabitAdsKotlinx_serialization_coreDeserializationStrategy>
@required
@end

__attribute__((swift_name("KotlinSuspendFunction0")))
@protocol PentabitAdsKotlinSuspendFunction0 <PentabitAdsKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end

__attribute__((swift_name("RuntimeTransactionCallbacks")))
@protocol PentabitAdsRuntimeTransactionCallbacks
@required
- (void)afterCommitFunction:(void (^)(void))function __attribute__((swift_name("afterCommit(function:)")));
- (void)afterRollbackFunction:(void (^)(void))function __attribute__((swift_name("afterRollback(function:)")));
@end

__attribute__((swift_name("RuntimeTransactionWithoutReturn")))
@protocol PentabitAdsRuntimeTransactionWithoutReturn <PentabitAdsRuntimeTransactionCallbacks>
@required
- (void)rollback __attribute__((swift_name("rollback()")));
- (void)transactionBody:(void (^)(id<PentabitAdsRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(body:)")));
@end

__attribute__((swift_name("RuntimeTransactionWithReturn")))
@protocol PentabitAdsRuntimeTransactionWithReturn <PentabitAdsRuntimeTransactionCallbacks>
@required
- (void)rollbackReturnValue:(id _Nullable)returnValue __attribute__((swift_name("rollback(returnValue:)")));
- (id _Nullable)transactionBody_:(id _Nullable (^)(id<PentabitAdsRuntimeTransactionWithReturn>))body __attribute__((swift_name("transaction(body_:)")));
@end

__attribute__((swift_name("RuntimeCloseable")))
@protocol PentabitAdsRuntimeCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end

__attribute__((swift_name("RuntimeSqlDriver")))
@protocol PentabitAdsRuntimeSqlDriver <PentabitAdsRuntimeCloseable>
@required
- (void)addListenerQueryKeys:(PentabitAdsKotlinArray<NSString *> *)queryKeys listener:(id<PentabitAdsRuntimeQueryListener>)listener __attribute__((swift_name("addListener(queryKeys:listener:)")));
- (PentabitAdsRuntimeTransacterTransaction * _Nullable)currentTransaction __attribute__((swift_name("currentTransaction()")));
- (id<PentabitAdsRuntimeQueryResult>)executeIdentifier:(PentabitAdsInt * _Nullable)identifier sql:(NSString *)sql parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<PentabitAdsRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("execute(identifier:sql:parameters:binders:)")));
- (id<PentabitAdsRuntimeQueryResult>)executeQueryIdentifier:(PentabitAdsInt * _Nullable)identifier sql:(NSString *)sql mapper:(id<PentabitAdsRuntimeQueryResult> (^)(id<PentabitAdsRuntimeSqlCursor>))mapper parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<PentabitAdsRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("executeQuery(identifier:sql:mapper:parameters:binders:)")));
- (id<PentabitAdsRuntimeQueryResult>)doNewTransaction __attribute__((swift_name("doNewTransaction()")));
- (void)notifyListenersQueryKeys:(PentabitAdsKotlinArray<NSString *> *)queryKeys __attribute__((swift_name("notifyListeners(queryKeys:)")));
- (void)removeListenerQueryKeys:(PentabitAdsKotlinArray<NSString *> *)queryKeys listener:(id<PentabitAdsRuntimeQueryListener>)listener __attribute__((swift_name("removeListener(queryKeys:listener:)")));
@end

__attribute__((swift_name("RuntimeSqlSchema")))
@protocol PentabitAdsRuntimeSqlSchema
@required
- (id<PentabitAdsRuntimeQueryResult>)createDriver:(id<PentabitAdsRuntimeSqlDriver>)driver __attribute__((swift_name("create(driver:)")));
- (id<PentabitAdsRuntimeQueryResult>)migrateDriver:(id<PentabitAdsRuntimeSqlDriver>)driver oldVersion:(int64_t)oldVersion newVersion:(int64_t)newVersion callbacks:(PentabitAdsKotlinArray<PentabitAdsRuntimeAfterVersion *> *)callbacks __attribute__((swift_name("migrate(driver:oldVersion:newVersion:callbacks:)")));
@property (readonly) int64_t version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface PentabitAdsKotlinUnit : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsKotlinUnit *shared __attribute__((swift_name("shared")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("RuntimeTransacterTransaction")))
@interface PentabitAdsRuntimeTransacterTransaction : PentabitAdsBase <PentabitAdsRuntimeTransactionCallbacks>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)afterCommitFunction:(void (^)(void))function __attribute__((swift_name("afterCommit(function:)")));
- (void)afterRollbackFunction:(void (^)(void))function __attribute__((swift_name("afterRollback(function:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (id<PentabitAdsRuntimeQueryResult>)endTransactionSuccessful:(BOOL)successful __attribute__((swift_name("endTransaction(successful:)")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) PentabitAdsRuntimeTransacterTransaction * _Nullable enclosingTransaction __attribute__((swift_name("enclosingTransaction")));
@end

__attribute__((swift_name("RuntimeExecutableQuery")))
@interface PentabitAdsRuntimeExecutableQuery<__covariant RowType> : PentabitAdsBase
- (instancetype)initWithMapper:(RowType (^)(id<PentabitAdsRuntimeSqlCursor>))mapper __attribute__((swift_name("init(mapper:)"))) __attribute__((objc_designated_initializer));
- (id<PentabitAdsRuntimeQueryResult>)executeMapper:(id<PentabitAdsRuntimeQueryResult> (^)(id<PentabitAdsRuntimeSqlCursor>))mapper __attribute__((swift_name("execute(mapper:)")));
- (NSArray<RowType> *)executeAsList __attribute__((swift_name("executeAsList()")));
- (RowType)executeAsOne __attribute__((swift_name("executeAsOne()")));
- (RowType _Nullable)executeAsOneOrNull __attribute__((swift_name("executeAsOneOrNull()")));
@property (readonly) RowType (^mapper)(id<PentabitAdsRuntimeSqlCursor>) __attribute__((swift_name("mapper")));
@end

__attribute__((swift_name("RuntimeQuery")))
@interface PentabitAdsRuntimeQuery<__covariant RowType> : PentabitAdsRuntimeExecutableQuery<RowType>
- (instancetype)initWithMapper:(RowType (^)(id<PentabitAdsRuntimeSqlCursor>))mapper __attribute__((swift_name("init(mapper:)"))) __attribute__((objc_designated_initializer));
- (void)addListenerListener:(id<PentabitAdsRuntimeQueryListener>)listener __attribute__((swift_name("addListener(listener:)")));
- (void)removeListenerListener:(id<PentabitAdsRuntimeQueryListener>)listener __attribute__((swift_name("removeListener(listener:)")));
@end

__attribute__((swift_name("RuntimeQueryResult")))
@protocol PentabitAdsRuntimeQueryResult
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)awaitWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("await(completionHandler:)")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialFormat")))
@protocol PentabitAdsKotlinx_serialization_coreSerialFormat
@required
@property (readonly) PentabitAdsKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreStringFormat")))
@protocol PentabitAdsKotlinx_serialization_coreStringFormat <PentabitAdsKotlinx_serialization_coreSerialFormat>
@required
- (id _Nullable)decodeFromStringDeserializer:(id<PentabitAdsKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (NSString *)encodeToStringSerializer:(id<PentabitAdsKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
@end

__attribute__((swift_name("Kotlinx_serialization_jsonJson")))
@interface PentabitAdsKotlinx_serialization_jsonJson : PentabitAdsBase <PentabitAdsKotlinx_serialization_coreStringFormat>
@property (class, readonly, getter=companion) PentabitAdsKotlinx_serialization_jsonJsonDefault *companion __attribute__((swift_name("companion")));
- (id _Nullable)decodeFromJsonElementDeserializer:(id<PentabitAdsKotlinx_serialization_coreDeserializationStrategy>)deserializer element:(PentabitAdsKotlinx_serialization_jsonJsonElement *)element __attribute__((swift_name("decodeFromJsonElement(deserializer:element:)")));
- (id _Nullable)decodeFromStringString:(NSString *)string __attribute__((swift_name("decodeFromString(string:)")));
- (id _Nullable)decodeFromStringDeserializer:(id<PentabitAdsKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (PentabitAdsKotlinx_serialization_jsonJsonElement *)encodeToJsonElementSerializer:(id<PentabitAdsKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToJsonElement(serializer:value:)")));
- (NSString *)encodeToStringValue:(id _Nullable)value __attribute__((swift_name("encodeToString(value:)")));
- (NSString *)encodeToStringSerializer:(id<PentabitAdsKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
- (PentabitAdsKotlinx_serialization_jsonJsonElement *)parseToJsonElementString:(NSString *)string __attribute__((swift_name("parseToJsonElement(string:)")));
@property (readonly) PentabitAdsKotlinx_serialization_jsonJsonConfiguration *configuration __attribute__((swift_name("configuration")));
@property (readonly) PentabitAdsKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol PentabitAdsKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlowCollector")))
@protocol PentabitAdsKotlinx_coroutines_coreFlowCollector
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(id _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));
@end

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol PentabitAdsKotlinCoroutineContextKey
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuation")))
@protocol PentabitAdsKotlinContinuation
@required
- (void)resumeWithResult:(id _Nullable)result __attribute__((swift_name("resumeWith(result:)")));
@property (readonly) id<PentabitAdsKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextKey")))
@interface PentabitAdsKotlinAbstractCoroutineContextKey<B, E> : PentabitAdsBase <PentabitAdsKotlinCoroutineContextKey>
- (instancetype)initWithBaseKey:(id<PentabitAdsKotlinCoroutineContextKey>)baseKey safeCast:(E _Nullable (^)(id<PentabitAdsKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher.Key")))
@interface PentabitAdsKotlinx_coroutines_coreCoroutineDispatcherKey : PentabitAdsKotlinAbstractCoroutineContextKey<id<PentabitAdsKotlinContinuationInterceptor>, PentabitAdsKotlinx_coroutines_coreCoroutineDispatcher *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithBaseKey:(id<PentabitAdsKotlinCoroutineContextKey>)baseKey safeCast:(id<PentabitAdsKotlinCoroutineContextElement> _Nullable (^)(id<PentabitAdsKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)key __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsKotlinx_coroutines_coreCoroutineDispatcherKey *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol PentabitAdsKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol PentabitAdsKotlinx_serialization_coreEncoder
@required
- (id<PentabitAdsKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<PentabitAdsKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<PentabitAdsKotlinx_serialization_coreEncoder>)encodeInlineDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("encodeInline(descriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNull __attribute__((swift_name("encodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableValueSerializer:(id<PentabitAdsKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<PentabitAdsKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) PentabitAdsKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol PentabitAdsKotlinx_serialization_coreSerialDescriptor
@required
- (NSArray<id<PentabitAdsKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));
- (id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));
@property (readonly) NSArray<id<PentabitAdsKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));
@property (readonly) PentabitAdsKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol PentabitAdsKotlinx_serialization_coreDecoder
@required
- (id<PentabitAdsKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<PentabitAdsKotlinx_serialization_coreDecoder>)decodeInlineDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeInline(descriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (PentabitAdsKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<PentabitAdsKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<PentabitAdsKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) PentabitAdsKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("RuntimeQueryListener")))
@protocol PentabitAdsRuntimeQueryListener
@required
- (void)queryResultsChanged __attribute__((swift_name("queryResultsChanged()")));
@end

__attribute__((swift_name("RuntimeSqlPreparedStatement")))
@protocol PentabitAdsRuntimeSqlPreparedStatement
@required
- (void)bindBooleanIndex:(int32_t)index boolean:(PentabitAdsBoolean * _Nullable)boolean __attribute__((swift_name("bindBoolean(index:boolean:)")));
- (void)bindBytesIndex:(int32_t)index bytes:(PentabitAdsKotlinByteArray * _Nullable)bytes __attribute__((swift_name("bindBytes(index:bytes:)")));
- (void)bindDoubleIndex:(int32_t)index double:(PentabitAdsDouble * _Nullable)double_ __attribute__((swift_name("bindDouble(index:double:)")));
- (void)bindLongIndex:(int32_t)index long:(PentabitAdsLong * _Nullable)long_ __attribute__((swift_name("bindLong(index:long:)")));
- (void)bindStringIndex:(int32_t)index string:(NSString * _Nullable)string __attribute__((swift_name("bindString(index:string:)")));
@end

__attribute__((swift_name("RuntimeSqlCursor")))
@protocol PentabitAdsRuntimeSqlCursor
@required
- (PentabitAdsBoolean * _Nullable)getBooleanIndex:(int32_t)index __attribute__((swift_name("getBoolean(index:)")));
- (PentabitAdsKotlinByteArray * _Nullable)getBytesIndex:(int32_t)index __attribute__((swift_name("getBytes(index:)")));
- (PentabitAdsDouble * _Nullable)getDoubleIndex:(int32_t)index __attribute__((swift_name("getDouble(index:)")));
- (PentabitAdsLong * _Nullable)getLongIndex:(int32_t)index __attribute__((swift_name("getLong(index:)")));
- (NSString * _Nullable)getStringIndex:(int32_t)index __attribute__((swift_name("getString(index:)")));
- (id<PentabitAdsRuntimeQueryResult>)next __attribute__((swift_name("next()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RuntimeAfterVersion")))
@interface PentabitAdsRuntimeAfterVersion : PentabitAdsBase
- (instancetype)initWithAfterVersion:(int64_t)afterVersion block:(void (^)(id<PentabitAdsRuntimeSqlDriver>))block __attribute__((swift_name("init(afterVersion:block:)"))) __attribute__((objc_designated_initializer));
@property (readonly) int64_t afterVersion __attribute__((swift_name("afterVersion")));
@property (readonly) void (^block)(id<PentabitAdsRuntimeSqlDriver>) __attribute__((swift_name("block")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface PentabitAdsKotlinx_serialization_coreSerializersModule : PentabitAdsBase

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)dumpToCollector:(id<PentabitAdsKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<PentabitAdsKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<PentabitAdsKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<PentabitAdsKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<PentabitAdsKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<PentabitAdsKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<PentabitAdsKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<PentabitAdsKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJson.Default")))
@interface PentabitAdsKotlinx_serialization_jsonJsonDefault : PentabitAdsKotlinx_serialization_jsonJson
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)default_ __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsKotlinx_serialization_jsonJsonDefault *shared __attribute__((swift_name("shared")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=kotlinx/serialization/json/JsonElementSerializer))
*/
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement")))
@interface PentabitAdsKotlinx_serialization_jsonJsonElement : PentabitAdsBase
@property (class, readonly, getter=companion) PentabitAdsKotlinx_serialization_jsonJsonElementCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonConfiguration")))
@interface PentabitAdsKotlinx_serialization_jsonJsonConfiguration : PentabitAdsBase
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL allowComments __attribute__((swift_name("allowComments")));
@property (readonly) BOOL allowSpecialFloatingPointValues __attribute__((swift_name("allowSpecialFloatingPointValues")));
@property (readonly) BOOL allowStructuredMapKeys __attribute__((swift_name("allowStructuredMapKeys")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL allowTrailingComma __attribute__((swift_name("allowTrailingComma")));
@property (readonly) NSString *classDiscriminator __attribute__((swift_name("classDiscriminator")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property PentabitAdsKotlinx_serialization_jsonClassDiscriminatorMode *classDiscriminatorMode __attribute__((swift_name("classDiscriminatorMode")));
@property (readonly) BOOL coerceInputValues __attribute__((swift_name("coerceInputValues")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL decodeEnumsCaseInsensitive __attribute__((swift_name("decodeEnumsCaseInsensitive")));
@property (readonly) BOOL encodeDefaults __attribute__((swift_name("encodeDefaults")));
@property (readonly) BOOL explicitNulls __attribute__((swift_name("explicitNulls")));
@property (readonly) BOOL ignoreUnknownKeys __attribute__((swift_name("ignoreUnknownKeys")));
@property (readonly) BOOL isLenient __attribute__((swift_name("isLenient")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) id<PentabitAdsKotlinx_serialization_jsonJsonNamingStrategy> _Nullable namingStrategy __attribute__((swift_name("namingStrategy")));
@property (readonly) BOOL prettyPrint __attribute__((swift_name("prettyPrint")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSString *prettyPrintIndent __attribute__((swift_name("prettyPrintIndent")));
@property (readonly) BOOL useAlternativeNames __attribute__((swift_name("useAlternativeNames")));
@property (readonly) BOOL useArrayPolymorphism __attribute__((swift_name("useArrayPolymorphism")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol PentabitAdsKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<PentabitAdsKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<PentabitAdsKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<PentabitAdsKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) PentabitAdsKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("KotlinAnnotation")))
@protocol PentabitAdsKotlinAnnotation
@required
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface PentabitAdsKotlinx_serialization_coreSerialKind : PentabitAdsBase
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol PentabitAdsKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<PentabitAdsKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<PentabitAdsKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<PentabitAdsKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) PentabitAdsKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface PentabitAdsKotlinNothing : PentabitAdsBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface PentabitAdsKotlinByteArray : PentabitAdsBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(PentabitAdsByte *(^)(PentabitAdsInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (PentabitAdsKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol PentabitAdsKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<PentabitAdsKotlinKClass>)kClass provider:(id<PentabitAdsKotlinx_serialization_coreKSerializer> (^)(NSArray<id<PentabitAdsKotlinx_serialization_coreKSerializer>> *))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<PentabitAdsKotlinKClass>)kClass serializer:(id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<PentabitAdsKotlinKClass>)baseClass actualClass:(id<PentabitAdsKotlinKClass>)actualClass actualSerializer:(id<PentabitAdsKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<PentabitAdsKotlinKClass>)baseClass defaultDeserializerProvider:(id<PentabitAdsKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)"))) __attribute__((deprecated("Deprecated in favor of function with more precise name: polymorphicDefaultDeserializer")));
- (void)polymorphicDefaultDeserializerBaseClass:(id<PentabitAdsKotlinKClass>)baseClass defaultDeserializerProvider:(id<PentabitAdsKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultSerializerBaseClass:(id<PentabitAdsKotlinKClass>)baseClass defaultSerializerProvider:(id<PentabitAdsKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol PentabitAdsKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol PentabitAdsKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol PentabitAdsKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol PentabitAdsKotlinKClass <PentabitAdsKotlinKDeclarationContainer, PentabitAdsKotlinKAnnotatedElement, PentabitAdsKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement.Companion")))
@interface PentabitAdsKotlinx_serialization_jsonJsonElementCompanion : PentabitAdsBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PentabitAdsKotlinx_serialization_jsonJsonElementCompanion *shared __attribute__((swift_name("shared")));
- (id<PentabitAdsKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonClassDiscriminatorMode")))
@interface PentabitAdsKotlinx_serialization_jsonClassDiscriminatorMode : PentabitAdsKotlinEnum<PentabitAdsKotlinx_serialization_jsonClassDiscriminatorMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PentabitAdsKotlinx_serialization_jsonClassDiscriminatorMode *none __attribute__((swift_name("none")));
@property (class, readonly) PentabitAdsKotlinx_serialization_jsonClassDiscriminatorMode *allJsonObjects __attribute__((swift_name("allJsonObjects")));
@property (class, readonly) PentabitAdsKotlinx_serialization_jsonClassDiscriminatorMode *polymorphic __attribute__((swift_name("polymorphic")));
+ (PentabitAdsKotlinArray<PentabitAdsKotlinx_serialization_jsonClassDiscriminatorMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PentabitAdsKotlinx_serialization_jsonClassDiscriminatorMode *> *entries __attribute__((swift_name("entries")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_jsonJsonNamingStrategy")))
@protocol PentabitAdsKotlinx_serialization_jsonJsonNamingStrategy
@required
- (NSString *)serialNameForJsonDescriptor:(id<PentabitAdsKotlinx_serialization_coreSerialDescriptor>)descriptor elementIndex:(int32_t)elementIndex serialName:(NSString *)serialName __attribute__((swift_name("serialNameForJson(descriptor:elementIndex:serialName:)")));
@end

__attribute__((swift_name("KotlinByteIterator")))
@interface PentabitAdsKotlinByteIterator : PentabitAdsBase <PentabitAdsKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (PentabitAdsByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
