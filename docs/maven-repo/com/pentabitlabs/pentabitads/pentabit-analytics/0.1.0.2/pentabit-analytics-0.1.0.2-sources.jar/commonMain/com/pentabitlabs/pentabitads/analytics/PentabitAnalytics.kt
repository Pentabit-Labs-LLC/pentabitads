package com.pentabitlabs.pentabitads.analytics

import com.pentabitlabs.pentabitads.core.PentabitEndpoints
import com.pentabitlabs.pentabitads.core.PentabitVersion
import com.pentabitlabs.pentabitads.core.CoreGraph
import com.pentabitlabs.pentabitads.core.CoreOptions
import com.pentabitlabs.pentabitads.core.events.EventNames
import com.pentabitlabs.pentabitads.core.privacy.ConsentSignals
import com.pentabitlabs.pentabitads.platform.PlatformContext
import com.pentabitlabs.pentabitads.platform.createPlatformModule
import kotlinx.coroutines.launch

/**
 * Pentabit Analytics: the small SDK for apps that are advertised. It reports the actions advertisers pay for
 * (installs, sign-ups, purchases and so on). Call [initialize] once at app start; every other call
 * returns at once and never throws.
 */
public object PentabitAnalytics {
    private class Graph(val core: CoreGraph, val tracker: AnalyticsEventTracker)

    private var graph: Graph? = null

    public val isInitialized: Boolean get() = graph != null

    public fun initialize(context: PlatformContext, options: AnalyticsOptions) {
        if (graph != null) return
        try {
            val platform = createPlatformModule(context, options.debug, storeName = "pentabit_analytics")
            val filter = ActionFilter(platform.keyValueStore)
            val conversion = ConversionValueTracker(platform.keyValueStore, createConversionValueSink())
            val core = CoreGraph(
                platform,
                CoreOptions(options.appKey, PentabitEndpoints.BASE_URL, options.audience, "pentabit-analytics", PentabitVersion.VERSION, options.debug, eventsPath = "/v1/actions", reportUrl = PentabitEndpoints.REPORT_URL),
                onUploadReply = { body -> conversion.onReply(body); filter.onReply(body) },
            )
            val tracker = AnalyticsEventTracker(core, filter)
            val initializer = AnalyticsInitializer(platform.keyValueStore, platform.clock, createInstallSource(context), tracker)
            graph = Graph(core, tracker)
            core.start()
            core.sdkScope.scope.launch { initializer.run() }
        } catch (t: Throwable) {
            println("PentabitAnalytics: initialization failed: ${t.message}")
        }
    }

    /** Pass the user's consent and age signals. Call again whenever they change. */
    public fun setConsent(signals: ConsentSignals) {
        graph?.core?.privacy?.update(signals)
    }

    /**
     * Reports a custom action. [name] is lower-case letters, digits and underscores (max 40).
     * Returns false if the SDK is not started or the arguments are invalid.
     */
    public fun track(name: String, params: Map<String, String> = emptyMap(), value: Double? = null, currency: String? = null): Boolean =
        graph?.tracker?.track(name, params, value, currency) ?: false

    public fun trackRegistration(method: String? = null): Boolean =
        trackStandard(EventNames.REGISTRATION, method?.let { mapOf("method" to it) } ?: emptyMap())

    public fun trackTutorialComplete(): Boolean = trackStandard(EventNames.TUTORIAL_COMPLETE)

    public fun trackLevelReached(level: Int): Boolean = trackStandard(EventNames.LEVEL_REACHED, mapOf("level" to level.toString()))

    public fun trackFeatureUsed(feature: String): Boolean = trackStandard(EventNames.FEATURE_USED, mapOf("feature" to feature))

    public fun trackPurchase(revenue: Double, currency: String, productId: String? = null): Boolean =
        trackStandard(EventNames.PURCHASE, productId?.let { mapOf("product_id" to it) } ?: emptyMap(), revenue, currency)

    public fun trackSubscribe(revenue: Double, currency: String, productId: String? = null): Boolean =
        trackStandard(EventNames.SUBSCRIBE, productId?.let { mapOf("product_id" to it) } ?: emptyMap(), revenue, currency)

    /**
     * Call with the URL that opened the app. If it carries Pentabit campaign data, a deep_link_open event
     * is reported. Returns the parsed link, or null if it is not a usable link.
     */
    public fun handleDeepLink(url: String): DeepLink? {
        val link = DeepLinkResolver.parse(url) ?: return null
        if (link.campaign != null || link.clickId != null) {
            val params = buildMap {
                link.campaign?.let { put("campaign", it) }
                link.clickId?.let { put("click_id", it) }
                put("path", link.path)
            }
            trackStandard(EventNames.DEEP_LINK_OPEN, params)
        }
        return link
    }

    public fun shutdown() {
        graph?.core?.shutdown()
        graph = null
    }

    private fun trackStandard(name: String, params: Map<String, String> = emptyMap(), value: Double? = null, currency: String? = null): Boolean =
        graph?.tracker?.track(name, params, value, currency) ?: false
}
