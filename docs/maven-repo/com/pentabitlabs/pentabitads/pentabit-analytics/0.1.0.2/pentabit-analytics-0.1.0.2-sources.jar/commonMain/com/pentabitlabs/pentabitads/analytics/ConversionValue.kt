package com.pentabitlabs.pentabitads.analytics

import com.pentabitlabs.pentabitads.core.ports.KeyValueStore

/**
 * The server decides what an action is worth: its /v1/actions reply may carry
 * {"conversionValue": 0..63}. Apple only allows the value to go up, so this remembers the highest
 * value sent and only forwards a higher one.
 */
internal class ConversionValueTracker(
    private val store: KeyValueStore,
    private val sink: ConversionValueSink,
) {
    /** Reads the reply of an accepted batch; ignores anything without a usable value. */
    suspend fun onReply(body: String) {
        val v = Regex("\"conversionValue\"\\s*:\\s*(\\d+)").find(body)?.groupValues?.get(1)?.toIntOrNull() ?: return
        val candidate = v.coerceIn(0, MAX_VALUE)
        val sent = store.getString(KEY)?.toIntOrNull() ?: -1
        if (candidate <= sent) return
        store.putString(KEY, candidate.toString())
        sink.update(candidate)
    }

    private companion object {
        const val MAX_VALUE = 63
        const val KEY = "aks.analytics.conversion_value"
    }
}
