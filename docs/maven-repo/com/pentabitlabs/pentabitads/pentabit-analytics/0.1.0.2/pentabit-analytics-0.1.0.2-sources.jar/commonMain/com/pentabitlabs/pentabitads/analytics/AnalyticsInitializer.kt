package com.pentabitlabs.pentabitads.analytics

import com.pentabitlabs.pentabitads.core.events.EventNames
import com.pentabitlabs.pentabitads.core.ports.Clock
import com.pentabitlabs.pentabitads.core.ports.KeyValueStore
import kotlinx.coroutines.withTimeoutOrNull

/**
 * The actions the SDK reports by itself (the app cannot know them): `first_open` once per install,
 * with the install referrer when there is one, and `retention_d1`, `d3`, `d7`, `d14`, `d30` when the
 * app is opened that many days after the install. Each is sent once. The server decides which of
 * them it wants (see [ActionFilter]).
 */
internal class AnalyticsInitializer(
    private val store: KeyValueStore,
    private val clock: Clock,
    private val installSource: InstallSource,
    private val tracker: AnalyticsEventTracker,
) {
    suspend fun run() {
        if (store.getString(DONE) == null) firstOpen() else retention()
    }

    private suspend fun firstOpen() {
        val referrer = withTimeoutOrNull(REFERRER_TIMEOUT_MS) { installSource.referrer() }
        val params = if (referrer.isNullOrBlank()) emptyMap() else mapOf("install_referrer" to referrer.take(200))
        // If consent is not available yet the event is dropped and we try again next launch.
        if (tracker.accept(EventNames.FIRST_OPEN, params, null, null)) {
            store.putString(INSTALL_MS, clock.nowMillis().toString())
            store.putString(DONE, "1")
        }
    }

    private suspend fun retention() {
        val installMs = store.getString(INSTALL_MS)?.toLongOrNull() ?: return
        val day = ((clock.nowMillis() - installMs) / DAY_MS).toInt()
        if (day !in RETENTION_DAYS) return
        val sent = store.getString(RETENTION_SENT).orEmpty()
        if (sent.contains("|$day|")) return
        if (tracker.accept("retention_d$day", emptyMap(), null, null)) store.putString(RETENTION_SENT, "$sent|$day|")
    }

    private companion object {
        const val DONE = "aks.analytics.first_open_done"
        const val INSTALL_MS = "aks.analytics.install_ms"
        const val RETENTION_SENT = "aks.analytics.retention_sent"
        const val REFERRER_TIMEOUT_MS = 3_000L
        const val DAY_MS = 86_400_000L
        val RETENTION_DAYS = setOf(1, 3, 7, 14, 30)
    }
}
