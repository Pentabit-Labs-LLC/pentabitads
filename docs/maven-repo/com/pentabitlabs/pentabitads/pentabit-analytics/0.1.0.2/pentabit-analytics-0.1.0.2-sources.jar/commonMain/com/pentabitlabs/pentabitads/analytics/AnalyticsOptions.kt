package com.pentabitlabs.pentabitads.analytics

import com.pentabitlabs.pentabitads.core.privacy.AudienceProfile

public data class AnalyticsOptions(
    val appKey: String,
    /** Declare the audience once. CHILD_DIRECTED stops all action tracking. */
    val audience: AudienceProfile = AudienceProfile.GENERAL,
    /**
     * Debug builds. Actions are flagged as test traffic (the backend must not attribute or bill them) and
     * logging is turned on. Pass `BuildConfig.DEBUG` on Android. Must be false in release builds.
     */
    val debug: Boolean = false,
)
