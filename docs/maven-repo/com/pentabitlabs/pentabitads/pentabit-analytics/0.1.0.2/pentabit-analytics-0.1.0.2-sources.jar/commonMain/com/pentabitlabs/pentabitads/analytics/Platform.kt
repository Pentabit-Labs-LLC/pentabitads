package com.pentabitlabs.pentabitads.analytics

import com.pentabitlabs.pentabitads.platform.PlatformContext

/** Where this install came from. Android: Google Play Install Referrer. iOS: nothing (SKAdNetwork is used instead). */
internal interface InstallSource {
    /** The referrer string, or null if unavailable. Must give up on its own after a few seconds. */
    suspend fun referrer(): String?
}

internal expect fun createInstallSource(context: PlatformContext): InstallSource

/** Reports a conversion value to Apple's SKAdNetwork. A no-op on Android. */
internal interface ConversionValueSink {
    fun update(value: Int)
}

internal expect fun createConversionValueSink(): ConversionValueSink
