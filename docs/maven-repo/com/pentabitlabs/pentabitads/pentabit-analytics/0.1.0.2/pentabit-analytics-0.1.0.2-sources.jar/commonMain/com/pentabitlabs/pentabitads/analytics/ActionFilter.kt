package com.pentabitlabs.pentabitads.analytics

import com.pentabitlabs.pentabitads.core.events.EventNames
import com.pentabitlabs.pentabitads.core.ports.KeyValueStore

/**
 * The server decides which actions an app reports. Its reply to /v1/actions may carry
 * {"actions": ["registration", "level_reached"]}; the SDK saves that list and reports only those
 * (plus first_open, which is always sent so the server can answer). Until a list has arrived,
 * everything is reported, so nothing is lost while the first reply is on its way.
 */
internal class ActionFilter(private val store: KeyValueStore) {
    suspend fun allows(name: String): Boolean {
        if (name == EventNames.FIRST_OPEN) return true
        val saved = store.getString(KEY) ?: return true
        return saved.contains("|$name|")
    }

    /** Reads the reply of an accepted batch. A reply without "actions" keeps the saved list. */
    suspend fun onReply(body: String) {
        val array = Regex("\"actions\"\\s*:\\s*\\[(.*?)]").find(body)?.groupValues?.get(1) ?: return
        val names = Regex("\"([a-z][a-z0-9_]{0,39})\"").findAll(array).map { it.groupValues[1] }.toList()
        store.putString(KEY, names.joinToString(separator = "|", prefix = "|", postfix = "|").replace("||", "|"))
    }

    private companion object {
        const val KEY = "aks.analytics.actions"
    }
}
