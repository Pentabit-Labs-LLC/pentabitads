package com.pentabitlabs.pentabitads.analytics

/** A link that opened the app from a Pentabit-served ad. */
public data class DeepLink(
    val url: String,
    val path: String,
    /** Campaign identifier added by the Pentabit backend (`aks_campaign`). */
    val campaign: String?,
    /** Click identifier added by the Pentabit backend (`aks_cid`). */
    val clickId: String?,
    /** All other query parameters. */
    val params: Map<String, String>,
)

/** Reads a deep link without any platform code. Anything that is not a valid link gives null. */
public object DeepLinkResolver {
    private const val MAX_URL = 2_048

    public fun parse(url: String): DeepLink? {
        if (url.isBlank() || url.length > MAX_URL) return null
        val schemeEnd = url.indexOf("://")
        if (schemeEnd <= 0) return null
        val scheme = url.substring(0, schemeEnd).lowercase()
        if (scheme == "javascript" || scheme == "data" || scheme == "file") return null
        val rest = url.substring(schemeEnd + 3).substringBefore('#')
        val query = rest.substringAfter('?', "")
        val pathPart = rest.substringBefore('?')
        val path = "/" + pathPart.substringAfter('/', "")
        val all = LinkedHashMap<String, String>()
        if (query.isNotEmpty()) {
            for (pair in query.split('&')) {
                if (pair.isEmpty()) continue
                val k = decode(pair.substringBefore('='))
                if (k.isEmpty()) continue
                all[k] = decode(pair.substringAfter('=', ""))
            }
        }
        val campaign = all.remove("aks_campaign")
        val clickId = all.remove("aks_cid")
        return DeepLink(url, path, campaign, clickId, all)
    }

    private fun decode(s: String): String {
        val sb = StringBuilder()
        val bytes = ArrayList<Byte>()
        var i = 0
        fun flush() {
            if (bytes.isNotEmpty()) { sb.append(bytes.toByteArray().decodeToString()); bytes.clear() }
        }
        while (i < s.length) {
            val c = s[i]
            if (c == '%' && i + 2 < s.length) {
                val h = s.substring(i + 1, i + 3).toIntOrNull(16)
                if (h != null) { bytes.add(h.toByte()); i += 3; continue }
            }
            flush()
            sb.append(if (c == '+') ' ' else c)
            i++
        }
        flush()
        return sb.toString()
    }
}
