package com.pentabitlabs.pentabitads.analytics

import com.pentabitlabs.pentabitads.core.CoreGraph
import com.pentabitlabs.pentabitads.core.events.EventNames
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch

/**
 * The only way Analytics events enter the queue. Order is kept (one consumer), nothing blocks the caller,
 * and an event is dropped unless the server wants it and the privacy mode allows it.
 */
internal class AnalyticsEventTracker(private val core: CoreGraph, private val filter: ActionFilter) {
    private class Pending(val name: String, val params: Map<String, String>, val value: Double?, val currency: String?)

    private val channel = Channel<Pending>(capacity = 200, onBufferOverflow = BufferOverflow.DROP_OLDEST)

    init {
        core.sdkScope.scope.launch {
            // Wait for the cached config so a stored kill switch is honoured from the first action.
            core.config.loadCached()
            for (p in channel) accept(p.name, p.params, p.value, p.currency)
        }
    }

    /** Queues an event. Returns false at once if the name or value is invalid. */
    fun track(name: String, params: Map<String, String> = emptyMap(), value: Double? = null, currency: String? = null): Boolean {
        val n = name.trim().lowercase()
        if (!NAME.matches(n) || n in RESERVED) return false
        if (value != null && (value.isNaN() || value.isInfinite() || value < 0)) return false
        if (currency != null && !CURRENCY.matches(currency)) return false
        return channel.trySend(Pending(n, sanitize(params), value, currency)).isSuccess
    }

    /** Applies the rules and writes the event. Returns false when it was dropped. */
    suspend fun accept(name: String, params: Map<String, String>, value: Double?, currency: String?): Boolean {
        if (core.config.current.value.killSwitch || core.config.unauthorized.value) return false
        if (!filter.allows(name)) return false
        val mode = core.privacy.currentMode()
        if (!mode.analyticsActionsAllowed || core.privacy.blockReason(mode) != null) return false
        core.events.track(name, params = params, value = value, currency = currency)
        return true
    }

    private fun sanitize(params: Map<String, String>): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for ((k, v) in params) {
            if (out.size >= MAX_PARAMS) break
            val key = k.trim().lowercase()
            if (NAME.matches(key)) out[key] = v.take(MAX_VALUE_LENGTH)
        }
        return out
    }

    private companion object {
        const val MAX_PARAMS = 10
        const val MAX_VALUE_LENGTH = 100
        val NAME = Regex("[a-z][a-z0-9_]{0,39}")
        val CURRENCY = Regex("[A-Z]{3}")

        /** Names that belong to the ads SDK; an app cannot fake these. */
        val RESERVED = setOf(
            EventNames.IMPRESSION, EventNames.VIEWABLE_IMPRESSION,
            EventNames.CLICK, EventNames.VIDEO_START, EventNames.VIDEO_Q1, EventNames.VIDEO_MID, EventNames.VIDEO_Q3,
            EventNames.VIDEO_COMPLETE, EventNames.SKIP, EventNames.CLOSE, EventNames.REWARD_EARNED,
            EventNames.PLAYABLE_COMPLETE, EventNames.END_CARD_SHOWN, EventNames.ERROR,
        )
    }
}
