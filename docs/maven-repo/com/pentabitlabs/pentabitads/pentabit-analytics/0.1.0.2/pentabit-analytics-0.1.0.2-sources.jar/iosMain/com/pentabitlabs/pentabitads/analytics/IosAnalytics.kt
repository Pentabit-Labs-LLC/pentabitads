@file:OptIn(ExperimentalForeignApi::class)

package com.pentabitlabs.pentabitads.analytics

import com.pentabitlabs.pentabitads.platform.PlatformContext
import kotlinx.cinterop.ExperimentalForeignApi
import platform.StoreKit.SKAdNetwork
import platform.UIKit.UIDevice

internal actual fun createInstallSource(context: PlatformContext): InstallSource = object : InstallSource {
    override suspend fun referrer(): String? = null // iOS has no install referrer; SKAdNetwork covers attribution
}

internal actual fun createConversionValueSink(): ConversionValueSink = object : ConversionValueSink {
    override fun update(value: Int) {
        val v = value.toLong()
        val parts = UIDevice.currentDevice.systemVersion.split('.')
        val major = parts.getOrNull(0)?.toIntOrNull() ?: 0
        val minor = parts.getOrNull(1)?.toIntOrNull() ?: 0
        if (major > 15 || (major == 15 && minor >= 4)) {
            SKAdNetwork.updatePostbackConversionValue(v) { _ -> }
        } else {
            @Suppress("DEPRECATION")
            SKAdNetwork.updateConversionValue(v)
        }
    }
}
