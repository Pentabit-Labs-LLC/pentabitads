package com.pentabitlabs.pentabitads.video

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.pentabitlabs.pentabitads.ads.AndroidVideoPlayer
import com.pentabitlabs.pentabitads.ads.AndroidVideoPlayerFactory
import com.pentabitlabs.pentabitads.ads.AndroidVideoSupport
import com.pentabitlabs.pentabitads.ads.VideoListener
import java.io.File

public actual object PentabitAdsVideo {
    public actual fun install() {
        AndroidVideoSupport.factory = Media3Factory
    }
}

private object Media3Factory : AndroidVideoPlayerFactory {
    override fun create(context: Context, filePath: String, listener: VideoListener): AndroidVideoPlayer =
        Media3Player(context, filePath, listener)
}

/** Plays a cached mp4 with Media3. Progress is polled so quartile events follow real playback. */
private class Media3Player(context: Context, filePath: String, private val listener: VideoListener) : AndroidVideoPlayer {
    private val handler = Handler(Looper.getMainLooper())
    private val player: ExoPlayer = ExoPlayer.Builder(context).build()
    private var released = false
    private var userPaused = false
    private var finished = false

    override val view: View = PlayerView(context).also {
        it.useController = false
        it.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        it.player = player
    }

    private val poll = object : Runnable {
        override fun run() {
            if (released) return
            if (player.isPlaying) listener.onPosition(player.currentPosition)
            handler.postDelayed(this, 250)
        }
    }

    init {
        player.setAudioAttributes(
            AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
            /* handleAudioFocus = */ true,
        )
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && !finished) {
                    finished = true
                    listener.onCompleted()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                listener.onError("video playback failed: ${error.errorCodeName}")
            }
        })
        player.setMediaItem(MediaItem.fromUri(Uri.fromFile(File(filePath))))
        player.prepare()
        handler.post(poll)
    }

    override fun play() {
        if (released || finished) return
        if (userPaused) {
            userPaused = false
            listener.onResumed()
        }
        player.play()
    }

    override fun pause() {
        if (released || finished) return
        if (player.isPlaying) {
            userPaused = true
            player.pause()
            listener.onPaused()
        }
    }

    override fun setMuted(muted: Boolean) {
        if (released) return
        player.volume = if (muted) 0f else 1f
        listener.onMuteChanged(muted)
    }

    override fun release() {
        if (released) return
        released = true
        handler.removeCallbacksAndMessages(null)
        player.release()
    }
}
