package com.pentabitlabs.pentabitads.ads

import com.pentabitlabs.pentabitads.core.ad.LoadedAd
import com.pentabitlabs.pentabitads.core.error.AdError
import com.pentabitlabs.pentabitads.core.privacy.AudienceProfile

public data class PentabitAdsOptions(
    val appKey: String,
    /** Declare the audience once. CHILD_DIRECTED forces the strictest mode regardless of consent signals. */
    val audience: AudienceProfile = AudienceProfile.GENERAL,
    /**
     * Debug builds. Shows Pentabit **test ads** (never live ads, no revenue, nothing billed or counted in live
     * reporting) and turns on logging. Pass `BuildConfig.DEBUG` on Android. Must be false in release builds.
     */
    val debug: Boolean = false,
)

public data class RewardItem(val type: String, val amount: Int)

public enum class ValuePrecision { UNKNOWN, ESTIMATED, PRECISE }

/**
 * Revenue for one impression, like AdMob's paid event. [valueMicros] is in millionths of [currencyCode]
 * (1_000_000 = 1 USD). It is 0 while only cross-promotion is served.
 */
public data class AdValue(
    val valueMicros: Long,
    val currencyCode: String = "USD",
    val precision: ValuePrecision = ValuePrecision.PRECISE,
)

internal fun LoadedAd.adValue(): AdValue = AdValue(response.paidMicros, response.paidCurrency)

/** Open classes with no-op methods: implement only what you need (works from Swift too). */
public open class AdLoadListener {
    public open fun onLoaded() {}
    public open fun onLoadFailed(error: AdError) {}
}

public open class AdShowListener {
    public open fun onShown() {}
    /** The ad was counted as an impression (once per ad). */
    public open fun onAdImpression() {}
    /** Revenue earned by that impression; right after [onAdImpression]. */
    public open fun onAdPaid(value: AdValue) {}
    public open fun onClicked() {}
    public open fun onRewardEarned(reward: RewardItem) {}
    public open fun onClosed() {}
    public open fun onShowFailed(error: AdError) {}
}
