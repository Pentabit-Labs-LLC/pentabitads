@file:OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)

package com.pentabitlabs.pentabitads.ads

import com.pentabitlabs.pentabitads.core.mraid.CreativeHtml
import com.pentabitlabs.pentabitads.core.mraid.UrlPolicy
import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.ObjCSignatureOverride
import kotlinx.cinterop.readValue
import kotlinx.cinterop.useContents
import platform.CoreGraphics.CGRectZero
import platform.Foundation.NSData
import platform.Foundation.NSError
import platform.Foundation.NSHTTPURLResponse
import platform.darwin.NSObject
import platform.Foundation.NSURL
import platform.Foundation.dataWithContentsOfFile
import platform.UIKit.UIColor
import platform.UIKit.UIScrollViewContentInsetAdjustmentBehavior
import platform.UIKit.UIView
import platform.UIKit.UIViewAutoresizingFlexibleHeight
import platform.UIKit.UIViewAutoresizingFlexibleWidth
import platform.UIKit.UIScreen
import platform.WebKit.WKAudiovisualMediaTypeNone
import platform.WebKit.WKNavigation
import platform.WebKit.WKNavigationAction
import platform.WebKit.WKNavigationActionPolicy
import platform.WebKit.WKNavigationDelegateProtocol
import platform.WebKit.WKNavigationTypeLinkActivated
import platform.WebKit.WKNavigationTypeOther
import platform.WebKit.WKScriptMessage
import platform.WebKit.WKScriptMessageHandlerProtocol
import platform.WebKit.WKURLSchemeHandlerProtocol
import platform.WebKit.WKURLSchemeTaskProtocol
import platform.WebKit.WKUserContentController
import platform.WebKit.WKWebView
import platform.WebKit.WKWebViewConfiguration
import platform.WebKit.WKWebsiteDataStore

internal const val IOS_ASSET_SCHEME = "aks-asset"
private const val ASSET_BASE = "$IOS_ASSET_SCHEME://${CreativeHtml.ASSET_HOST}/"
private const val ASSET_ORIGINS = "$IOS_ASSET_SCHEME:"

private class ScriptHandler(private val onMessage: (String) -> Unit) : NSObject(), WKScriptMessageHandlerProtocol {
    override fun userContentController(userContentController: WKUserContentController, didReceiveScriptMessage: WKScriptMessage) {
        (didReceiveScriptMessage.body as? String)?.let(onMessage)
    }
}

/** Serves cached assets to the page. Anything else is refused, so a creative cannot reach the network. */
private class AssetSchemeHandler(private val model: AdScreenModel) : NSObject(), WKURLSchemeHandlerProtocol {
    @ObjCSignatureOverride
    override fun webView(webView: WKWebView, startURLSchemeTask: WKURLSchemeTaskProtocol) {
        val url = startURLSchemeTask.request.URL
        val key = url?.lastPathComponent
        val path = if (key != null) model.ad.assets[key]?.path else null
        val data = if (path != null) NSData.dataWithContentsOfFile(path) else null
        if (url == null || data == null) {
            startURLSchemeTask.didFailWithError(NSError.errorWithDomain("aks", 404, null))
            return
        }
        val mime = model.ad.response.creative.assets.firstOrNull { it.key == key }?.mime ?: mimeFor(key.orEmpty())
        val response = NSHTTPURLResponse(
            uRL = url, statusCode = 200, HTTPVersion = "HTTP/1.1",
            headerFields = mapOf("Content-Type" to mime, "Access-Control-Allow-Origin" to "*"),
        )
        startURLSchemeTask.didReceiveResponse(response)
        startURLSchemeTask.didReceiveData(data)
        startURLSchemeTask.didFinish()
    }

    @ObjCSignatureOverride
    override fun webView(webView: WKWebView, stopURLSchemeTask: WKURLSchemeTaskProtocol) {}

    private fun mimeFor(key: String): String = when (key.substringAfterLast('.', "").lowercase()) {
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "gif" -> "image/gif"
        "webp" -> "image/webp"
        "svg" -> "image/svg+xml"
        "css" -> "text/css"
        "js" -> "application/javascript"
        "mp4" -> "video/mp4"
        "mp3" -> "audio/mpeg"
        "woff2" -> "font/woff2"
        else -> "application/octet-stream"
    }
}

private class NavDelegate(private val model: AdScreenModel) : NSObject(), WKNavigationDelegateProtocol {
    override fun webView(webView: WKWebView, didFinishNavigation: WKNavigation?) {
        var bw = 0.0; var bh = 0.0; var sw = 0.0; var sh = 0.0
        webView.bounds.useContents { bw = size.width; bh = size.height }
        UIScreen.mainScreen.bounds.useContents { sw = size.width; sh = size.height }
        model.onPageFinished(bw.toInt(), bh.toInt(), sw.toInt(), sh.toInt())
    }

    override fun webView(webView: WKWebView, decidePolicyForNavigationAction: WKNavigationAction, decisionHandler: (WKNavigationActionPolicy) -> Unit) {
        val url = decidePolicyForNavigationAction.request.URL?.absoluteString
        val type = decidePolicyForNavigationAction.navigationType
        val initial = type == WKNavigationTypeOther && (url == null || url.startsWith("about:") || url.startsWith(IOS_ASSET_SCHEME))
        if (initial) {
            decisionHandler(WKNavigationActionPolicy.WKNavigationActionPolicyAllow)
            return
        }
        if (type == WKNavigationTypeLinkActivated && url != null && UrlPolicy.isAllowedOpenUrl(url)) model.onOpen(url)
        decisionHandler(WKNavigationActionPolicy.WKNavigationActionPolicyCancel)
    }

    @ObjCSignatureOverride
    override fun webView(webView: WKWebView, didFailNavigation: WKNavigation?, withError: NSError) =
        model.onContentError("the creative could not be loaded")

    @ObjCSignatureOverride
    override fun webView(webView: WKWebView, didFailProvisionalNavigation: WKNavigation?, withError: NSError) =
        model.onContentError("the creative could not be loaded")

    override fun webViewWebContentProcessDidTerminate(webView: WKWebView) =
        model.onContentError("the web view crashed")
}

/** The one WKWebView every web creative uses, locked down the same way as on Android. */
internal class IosAdWebView(private val model: AdScreenModel) {
    private val scriptHandler = ScriptHandler { model.onWebMessage(it) }
    private val schemeHandler = AssetSchemeHandler(model)
    private var disposed = false
    private val navDelegate = NavDelegate(model)

    val web: WKWebView = run {
        val config = WKWebViewConfiguration()
        config.userContentController.addScriptMessageHandler(scriptHandler, name = "aks")
        config.setURLSchemeHandler(schemeHandler, forURLScheme = IOS_ASSET_SCHEME)
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = WKAudiovisualMediaTypeNone
        config.websiteDataStore = WKWebsiteDataStore.nonPersistentDataStore()
        WKWebView(frame = CGRectZero.readValue(), configuration = config)
    }

    val view: UIView get() = web

    init {
        web.navigationDelegate = navDelegate
        web.opaque = false
        web.backgroundColor = UIColor.clearColor
        web.scrollView.scrollEnabled = false
        web.scrollView.bounces = false
        web.scrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentBehavior.UIScrollViewContentInsetAdjustmentNever
        web.autoresizingMask = UIViewAutoresizingFlexibleWidth or UIViewAutoresizingFlexibleHeight
        model.runScript = { js -> if (!disposed) web.evaluateJavaScript(js, completionHandler = null) }
    }

    fun showMain(): Boolean {
        val html = model.mainHtml(ASSET_BASE, ASSET_ORIGINS) ?: return false
        web.loadHTMLString(html, baseURL = NSURL.URLWithString(ASSET_BASE))
        return true
    }

    fun showEndCard(): Boolean {
        val html = model.endCardHtml(ASSET_BASE, ASSET_ORIGINS) ?: return false
        web.loadHTMLString(html, baseURL = NSURL.URLWithString(ASSET_BASE))
        return true
    }

    fun dispose() {
        if (disposed) return
        disposed = true
        web.stopLoading()
        web.navigationDelegate = null
        web.configuration.userContentController.removeScriptMessageHandlerForName("aks")
        web.removeFromSuperview()
    }
}
