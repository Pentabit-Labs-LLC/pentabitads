package com.pentabitlabs.pentabitads.ads

import com.pentabitlabs.pentabitads.core.CoreGraph
import com.pentabitlabs.pentabitads.core.SdkDefaults
import com.pentabitlabs.pentabitads.core.ad.LoadedAd
import com.pentabitlabs.pentabitads.core.events.EventNames
import com.pentabitlabs.pentabitads.core.events.ViewabilityTracker
import com.pentabitlabs.pentabitads.core.vast.VastEvents

/** Every event and tracking pixel for one shown ad, each fired once where the standards say so. */
internal class AdTelemetry(private val core: CoreGraph, private val ad: LoadedAd) {
    private var impressed = false
    private val viewability: ViewabilityTracker = ViewabilityTracker(
        SdkDefaults.VIEWABLE_AREA_PERCENT,
        if (ad.vast != null) SdkDefaults.VIEWABLE_VIDEO_MS else SdkDefaults.VIEWABLE_MS,
    )

    private fun track(name: String, params: Map<String, String> = emptyMap()) =
        core.events.track(name, requestId = ad.requestId, placementId = ad.placementId, params = params)

    /** Returns true only the first time, when the impression is really counted. */
    fun impression(): Boolean {
        if (impressed) return false
        impressed = true
        track(EventNames.IMPRESSION)
        core.pixels.fire(ad.vast?.impressions.orEmpty())
        return true
    }

    /** Feed the current visible percentage; counts a viewable impression once. */
    fun exposure(percent: Double) {
        if (viewability.onExposure(percent, core.platform.clock.nowMillis())) track(EventNames.VIEWABLE_IMPRESSION)
    }

    fun click() {
        track(EventNames.CLICK)
        core.pixels.fire(ad.vast?.clickTracking.orEmpty())
    }

    fun video(vastEvent: String) {
        VastEvents.toPentabitEvent(vastEvent)?.let { track(it) }
        val urls = ad.vast?.tracking.orEmpty().filter { it.event == vastEvent }.map { it.url }
        if (urls.isNotEmpty()) core.pixels.fire(urls)
    }

    fun playableComplete() = track(EventNames.PLAYABLE_COMPLETE)
    fun endCardShown() = track(EventNames.END_CARD_SHOWN)
    fun close() = track(EventNames.CLOSE)
    fun error(message: String) = track(EventNames.ERROR, mapOf("message" to message.take(200)))
}
