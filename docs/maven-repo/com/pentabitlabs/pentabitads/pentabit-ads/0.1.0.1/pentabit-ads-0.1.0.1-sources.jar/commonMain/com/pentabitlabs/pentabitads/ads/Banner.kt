package com.pentabitlabs.pentabitads.ads

import com.pentabitlabs.pentabitads.core.ad.LoadedAd
import com.pentabitlabs.pentabitads.core.error.AdError
import com.pentabitlabs.pentabitads.core.error.AdErrorCode
import com.pentabitlabs.pentabitads.core.error.AdResult
import com.pentabitlabs.pentabitads.core.model.AdFormat
import com.pentabitlabs.pentabitads.core.model.CreativeType
import kotlinx.coroutines.withContext

public open class BannerListener {
    public open fun onLoaded() {}
    public open fun onLoadFailed(error: AdError) {}
    public open fun onShown() {}
    public open fun onAdImpression() {}
    public open fun onAdPaid(value: AdValue) {}
    public open fun onClicked() {}
}

/** The banner sizes (in dp). Set [PentabitBannerView.adSize] before `load`: the backend returns a banner of exactly that size, or no ad. */
public enum class BannerSize(public val width: Int, public val height: Int) {
    BANNER(320, 50),
    LARGE_BANNER(320, 100),
    MEDIUM_RECTANGLE(300, 250),
}

/** Loads a banner for the platform view. Banners are always web creatives, so they go through MRAID. */
internal suspend fun AdsGraph.loadBanner(placementId: String, size: BannerSize): AdResult<LoadedAd> {
    val result = withContext(core.platform.dispatchers.default) { loader.load(placementId, AdFormat.BANNER, "${size.width}x${size.height}") }
    if (result is AdResult.Success) {
        val type = result.value.response.creative.type
        if (type != CreativeType.HTML && type != CreativeType.IMAGE) {
            releaseAssets(result.value)
            return AdResult.Failure(AdError(AdErrorCode.INTERNAL, "banners must be HTML or image creatives"))
        }
    }
    return result
}
