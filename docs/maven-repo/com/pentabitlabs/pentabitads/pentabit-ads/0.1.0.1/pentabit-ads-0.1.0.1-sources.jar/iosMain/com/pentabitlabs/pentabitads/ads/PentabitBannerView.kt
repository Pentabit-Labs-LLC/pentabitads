@file:OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)

package com.pentabitlabs.pentabitads.ads

import com.pentabitlabs.pentabitads.core.ad.LoadedAd
import com.pentabitlabs.pentabitads.core.error.AdError
import com.pentabitlabs.pentabitads.core.error.AdErrorCode
import com.pentabitlabs.pentabitads.core.error.AdResult
import com.pentabitlabs.pentabitads.core.mraid.MraidPlacement
import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.CValue
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.useContents
import platform.CoreGraphics.CGRect
import platform.CoreGraphics.CGRectMake
import platform.Foundation.NSTimer
import platform.UIKit.UIView
import kotlin.math.max
import kotlin.math.min

/**
 * Drop-in banner. Add it to your view, give it a frame, then call [load]. Banners are HTML creatives
 * rendered through the same MRAID web view as every other web ad. Call [destroy] when you are done.
 */
public class PentabitBannerView(frame: CValue<CGRect>) : UIView(frame) {
    /** The banner size to request. Set it before [load]; the default is 320x50. */
    public var adSize: BannerSize = BannerSize.BANNER

    private var model: AdScreenModel? = null
    private var web: IosAdWebView? = null
    private var ad: LoadedAd? = null
    private var graph: AdsGraph? = null
    private var generation = 0
    private var timer: NSTimer? = null

    public fun load(placementId: String, listener: BannerListener = BannerListener()) {
        val g = PentabitAds.graphOrNull()
        if (g == null) {
            listener.onLoadFailed(AdError(AdErrorCode.NOT_INITIALIZED, "call PentabitAds.initialize first"))
            return
        }
        clear()
        val mine = ++generation
        g.launchMain {
            val result = g.loadBanner(placementId, adSize)
            if (mine != generation) {
                if (result is AdResult.Success) g.releaseAssets(result.value)
                return@launchMain
            }
            when (result) {
                is AdResult.Failure -> g.safe { listener.onLoadFailed(result.error) }
                is AdResult.Success -> show(g, result.value, listener)
            }
        }
    }

    private fun show(g: AdsGraph, loaded: LoadedAd, listener: BannerListener) {
        val events = object : PresentationEvents {
            override fun shown() = g.safe { listener.onShown() }
            override fun impression(value: AdValue) = g.safe { listener.onAdImpression(); listener.onAdPaid(value) }
            override fun clicked() = g.safe { listener.onClicked() }
            override fun completed() {}
            override fun closed() {}
            override fun failed(message: String) {
                g.safe { listener.onLoadFailed(AdError(AdErrorCode.INTERNAL, message)) }
                clear()
            }
        }
        val m = AdScreenModel(g, loaded, events, MraidPlacement.INLINE, g.uiScope())
        model = m
        ad = loaded
        graph = g
        val w = IosAdWebView(m)
        web = w
        val creative = loaded.response.creative
        var bw = 0.0; var bh = 0.0
        this.bounds.useContents { bw = size.width; bh = size.height }
        val cw = creative.width?.toDouble() ?: bw
        val ch = creative.height?.toDouble() ?: bh
        w.view.setFrame(CGRectMake((bw - cw) / 2, (bh - ch) / 2, cw, ch))
        addSubview(w.view)
        m.arm()
        startExposureTimer()
        if (w.showMain()) g.safe { listener.onLoaded() } else m.onContentError("the creative has no content")
    }

    private fun startExposureTimer() {
        timer?.invalidate()
        timer = NSTimer.scheduledTimerWithTimeInterval(0.25, repeats = true) { _ -> model?.exposurePercent = visiblePercent() }
    }

    private fun visiblePercent(): Double {
        val window = this.window ?: return 0.0
        if (hidden || alpha < 0.01) return 0.0
        var total = 0.0
        bounds.useContents { total = size.width * size.height }
        if (total <= 0.0) return 0.0
        val r = convertRect(bounds, toView = window)
        var visible = 0.0
        var winW = 0.0; var winH = 0.0
        window.bounds.useContents { winW = size.width; winH = size.height }
        r.useContents {
            val w = max(0.0, min(origin.x + size.width, winW) - max(origin.x, 0.0))
            val h = max(0.0, min(origin.y + size.height, winH) - max(origin.y, 0.0))
            visible = w * h
        }
        return visible * 100.0 / total
    }

    private fun clear() {
        timer?.invalidate()
        timer = null
        model?.onScreenGone()
        model = null
        web?.dispose()
        web = null
        ad?.let { graph?.releaseAssets(it) }
        ad = null
    }

    public fun destroy() {
        generation++
        clear()
    }
}
