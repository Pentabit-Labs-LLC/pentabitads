package com.pentabitlabs.pentabitads.ads

import com.pentabitlabs.pentabitads.core.CoreGraph
import com.pentabitlabs.pentabitads.platform.PlatformContext

/** Android: the current Activity. iOS: the UIViewController to present from. */
public expect open class AdHost

/**
 * Callbacks from a full-screen (or inline) presentation, always on the main thread.
 * The presenter calls [failed] and then dismisses itself; [closed] means the user is done.
 */
internal interface PresentationEvents {
    fun shown()
    /** First counted impression of this ad, with what it earned. */
    fun impression(value: AdValue) {}
    fun clicked()
    fun completed()
    fun closed()
    fun failed(message: String)
}

internal interface AdPresenter {
    /** Starts showing [model]'s ad. Returns false if it could not even start. */
    fun present(host: AdHost, model: AdScreenModel): Boolean
}

internal interface AdPlatform {
    val presenter: AdPresenter
    val supportsVideo: Boolean
    fun openUrl(url: String): Boolean
}

internal expect fun createAdPlatform(context: PlatformContext, core: CoreGraph): AdPlatform
