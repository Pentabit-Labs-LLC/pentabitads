package com.pentabitlabs.pentabitads.ads

import com.pentabitlabs.pentabitads.core.ad.LoadedAd
import com.pentabitlabs.pentabitads.core.error.AdError
import com.pentabitlabs.pentabitads.core.error.AdErrorCode
import com.pentabitlabs.pentabitads.core.error.AdResult
import com.pentabitlabs.pentabitads.core.model.AdFormat
import kotlinx.coroutines.withContext

internal const val DEFAULT_PRIVACY_URL: String = "https://pentabitapps.com/privacy-policy/"

/** Optional: impression and revenue callbacks for a native or icon ad. Set with [NativeAd.setEventListener]. */
public open class NativeAdEventListener {
    public open fun onAdImpression() {}
    public open fun onAdPaid(value: AdValue) {}
    public open fun onClicked() {}
}

public open class NativeAdListener {
    public open fun onLoaded(ad: NativeAd) {}
    public open fun onLoadFailed(error: AdError) {}
}

/**
 * Native and Icon ads are plain assets: you draw them with your own views, so no WebView or MRAID is
 * involved. Report what the user sees and does with [recordImpression], [onExposure] and [recordClick].
 */
public class NativeAd internal constructor(
    private val graph: AdsGraph,
    private val ad: LoadedAd,
) {
    private val telemetry = AdTelemetry(graph.core, ad)
    private val assets = ad.response.creative.native
    private var destroyed = false
    private var eventListener: NativeAdEventListener? = null

    public fun setEventListener(listener: NativeAdEventListener?) { eventListener = listener }

    public val title: String? get() = assets?.title
    public val body: String? get() = assets?.body
    public val callToAction: String? get() = assets?.callToAction
    /** Always show this label next to the ad. Google Play and Apple require ads to be identifiable. */
    public val sponsoredLabel: String get() = assets?.sponsoredLabel ?: "Ad"
    /** The page the (i) button opens: why this ad is shown and the privacy policy. */
    public val privacyUrl: String get() = assets?.privacyUrl ?: DEFAULT_PRIVACY_URL
    /** Local file path of the cached icon image, or null. */
    public val iconPath: String? get() = assets?.iconAssetKey?.let { ad.assets[it]?.path }
    /** Local file path of the cached main image, or null. */
    public val imagePath: String? get() = assets?.imageAssetKey?.let { ad.assets[it]?.path }

    /** Call when the ad is first drawn on screen. Safe to call again. */
    public fun recordImpression() {
        if (destroyed) return
        if (telemetry.impression()) eventListener?.let { graph.safe { it.onAdImpression(); it.onAdPaid(ad.adValue()) } }
    }

    /** Optionally feed how much of the ad is visible (0..100); a viewable impression is counted once. */
    public fun onExposure(percent: Double) {
        if (!destroyed) telemetry.exposure(percent)
    }

    /** Records the click and opens the destination. Returns false if there was nothing to open. */
    public fun recordClick(): Boolean {
        if (destroyed) return false
        telemetry.click()
        eventListener?.let { graph.safe { it.onClicked() } }
        val url = ad.response.creative.clickUrl ?: return false
        return graph.platform.openUrl(url)
    }

    /** Opens [privacyUrl]. The ad views call this from their (i) button. */
    public fun openPrivacyPolicy(): Boolean = !destroyed && graph.platform.openUrl(privacyUrl)

    public fun destroy() {
        if (destroyed) return
        destroyed = true
        graph.releaseAssets(ad)
    }
}

public class NativeAdLoader internal constructor(
    private val placementId: String,
    private val format: AdFormat,
    private val graphProvider: () -> AdsGraph?,
) {
    public fun load(listener: NativeAdListener) {
        val g = graphProvider()
        if (g == null) {
            listener.onLoadFailed(AdError(AdErrorCode.NOT_INITIALIZED, "call PentabitAds.initialize first"))
            return
        }
        g.launchMain {
            when (val r = withContext(g.core.platform.dispatchers.default) { g.loader.load(placementId, format) }) {
                is AdResult.Failure -> g.safe { listener.onLoadFailed(r.error) }
                is AdResult.Success -> {
                    if (r.value.response.creative.native == null) {
                        g.releaseAssets(r.value)
                        g.safe { listener.onLoadFailed(AdError(AdErrorCode.INTERNAL, "the response had no native assets")) }
                    } else {
                        g.safe { listener.onLoaded(NativeAd(g, r.value)) }
                    }
                }
            }
        }
    }
}
