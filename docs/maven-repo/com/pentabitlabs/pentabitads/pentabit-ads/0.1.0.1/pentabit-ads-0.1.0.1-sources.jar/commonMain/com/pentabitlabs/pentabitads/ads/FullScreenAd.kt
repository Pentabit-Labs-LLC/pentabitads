package com.pentabitlabs.pentabitads.ads

import com.pentabitlabs.pentabitads.core.ad.AdSession
import com.pentabitlabs.pentabitads.core.ad.AdStage
import com.pentabitlabs.pentabitads.core.ad.LoadedAd
import com.pentabitlabs.pentabitads.core.error.AdError
import com.pentabitlabs.pentabitads.core.error.AdErrorCode
import com.pentabitlabs.pentabitads.core.error.AdResult
import com.pentabitlabs.pentabitads.core.events.EventNames
import com.pentabitlabs.pentabitads.core.model.AdFormat
import com.pentabitlabs.pentabitads.core.mraid.MraidPlacement
import kotlinx.coroutines.withContext

/**
 * Shared behaviour of interstitial, rewarded and app open ads: load once, show once, then make a
 * new object (or call load again) for the next ad. Call every method from the main thread.
 */
public abstract class FullScreenAd internal constructor(
    public val placementId: String,
    private val format: AdFormat,
    private val graphProvider: () -> AdsGraph?,
) {
    private var session: AdSession? = null

    public val isReady: Boolean
        get() {
            val g = graphProvider() ?: return false
            val s = session ?: return false
            return s.stage.value == AdStage.READY && !s.isExpired(g.core.platform.clock.nowMillis())
        }

    public fun load(listener: AdLoadListener = AdLoadListener()) {
        val g = graphProvider()
        if (g == null) {
            listener.onLoadFailed(AdError(AdErrorCode.NOT_INITIALIZED, "call PentabitAds.initialize first"))
            return
        }
        val current = session
        if (current != null) {
            when {
                current.stage.value == AdStage.LOADING -> return
                isReady -> { g.safe { listener.onLoaded() }; return }
            }
        }
        val s = AdSession(g.core.platform.ids.newId())
        s.transition(AdStage.LOADING)
        session = s
        g.launchMain {
            val result = withContext(g.core.platform.dispatchers.default) { g.loader.load(placementId, format) }
            if (session !== s || s.stage.value != AdStage.LOADING) {
                // Destroyed or replaced while loading: free whatever was downloaded.
                if (result is AdResult.Success) g.releaseAssets(result.value)
                return@launchMain
            }
            when (result) {
                is AdResult.Success -> {
                    val ad = result.value
                    if (ad.vast != null && !g.platform.supportsVideo) {
                        g.releaseAssets(ad)
                        val e = AdError(AdErrorCode.INTERNAL, "this ad is a video but pentabit-ads-video is not installed")
                        s.markFailed(e)
                        g.safe { listener.onLoadFailed(e) }
                    } else {
                        s.markLoaded(ad)
                        g.safe { listener.onLoaded() }
                    }
                }
                is AdResult.Failure -> {
                    s.markFailed(result.error)
                    g.safe { listener.onLoadFailed(result.error) }
                }
            }
        }
    }

    public fun show(host: AdHost, listener: AdShowListener = AdShowListener()) {
        val g = graphProvider()
        if (g == null) {
            listener.onShowFailed(AdError(AdErrorCode.NOT_INITIALIZED, "call PentabitAds.initialize first"))
            return
        }
        val s = session
        val ad = s?.loaded
        if (s == null || ad == null || s.stage.value != AdStage.READY) {
            g.safe { listener.onShowFailed(AdError(AdErrorCode.INTERNAL, "the ad is not ready, call load first")) }
            return
        }
        if (s.isExpired(g.core.platform.clock.nowMillis())) {
            s.transition(AdStage.EXPIRED)
            g.releaseAssets(ad)
            g.safe { listener.onShowFailed(AdError(AdErrorCode.EXPIRED, "the ad expired, load a new one")) }
            return
        }
        s.transition(AdStage.SHOWING)
        val events = Events(g, s, ad, listener)
        val model = AdScreenModel(g, ad, events, MraidPlacement.INTERSTITIAL, g.uiScope())
        val started = try {
            g.platform.presenter.present(host, model)
        } catch (t: Throwable) {
            g.core.platform.logger.error("PentabitAds", "presenter failed", t)
            false
        }
        if (!started) events.failed("the ad screen could not be opened")
    }

    /** Releases the loaded ad. The object can be loaded again afterwards. */
    public fun destroy() {
        val g = graphProvider()
        val s = session ?: return
        val ad = s.loaded
        if (s.stage.value == AdStage.SHOWING) return // the screen cleans up when it closes
        s.transition(AdStage.DESTROYED)
        if (g != null && ad != null) g.releaseAssets(ad)
        session = null
    }

    private inner class Events(
        private val g: AdsGraph,
        private val s: AdSession,
        private val ad: LoadedAd,
        private val listener: AdShowListener,
    ) : PresentationEvents {
        override fun shown() = g.safe { listener.onShown() }
        override fun impression(value: AdValue) = g.safe { listener.onAdImpression(); listener.onAdPaid(value) }
        override fun clicked() = g.safe { listener.onClicked() }

        override fun completed() {
            if (format != AdFormat.REWARDED) return
            g.core.events.track(EventNames.REWARD_EARNED, requestId = ad.requestId, placementId = ad.placementId)
            val spec = ad.response.reward
            g.launchMain { g.safe { listener.onRewardEarned(RewardItem(spec?.type ?: "reward", spec?.amount ?: 1)) } }
        }

        override fun closed() {
            s.transition(AdStage.COMPLETED)
            g.releaseAssets(ad)
            g.safe { listener.onClosed() }
        }

        override fun failed(message: String) {
            val e = AdError(AdErrorCode.INTERNAL, message)
            s.markFailed(e)
            g.releaseAssets(ad)
            g.safe { listener.onShowFailed(e) }
        }
    }
}

public class InterstitialAd internal constructor(placementId: String, graphProvider: () -> AdsGraph?) :
    FullScreenAd(placementId, AdFormat.INTERSTITIAL, graphProvider)

public class RewardedAd internal constructor(placementId: String, graphProvider: () -> AdsGraph?) :
    FullScreenAd(placementId, AdFormat.REWARDED, graphProvider)

public class AppOpenAd internal constructor(placementId: String, graphProvider: () -> AdsGraph?) :
    FullScreenAd(placementId, AdFormat.APP_OPEN, graphProvider)
