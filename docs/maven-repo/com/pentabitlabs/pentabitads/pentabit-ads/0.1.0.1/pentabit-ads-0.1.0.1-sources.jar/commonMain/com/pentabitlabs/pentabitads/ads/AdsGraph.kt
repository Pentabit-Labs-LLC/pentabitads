package com.pentabitlabs.pentabitads.ads

import com.pentabitlabs.pentabitads.core.CoreGraph
import com.pentabitlabs.pentabitads.core.ad.AdLoader
import com.pentabitlabs.pentabitads.core.ad.LoadedAd
import com.pentabitlabs.pentabitads.core.net.PixelClient
import com.pentabitlabs.pentabitads.core.vast.VastParser
import com.pentabitlabs.pentabitads.core.vast.VastResolver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/** Composition root of the ads module. Built once by [PentabitAds.initialize]. */
internal class AdsGraph(val core: CoreGraph, val platform: AdPlatform) {
    private val p = core.platform

    val loader: AdLoader = AdLoader(
        config = core.config,
        privacy = core.privacy,
        deviceInfo = p.deviceInfo,
        api = core.api,
        assets = p.assetStore,
        vastFactory = { depth, timeout, bitrate ->
            VastResolver(p.http, VastParser(), PixelClient(p.http, core.sdkScope.scope, p.clock, p.logger), depth, timeout, bitrate)
        },
        clock = p.clock,
        ids = p.ids,
        events = core.events,
        sdk = core.sdkInfo,
        testMode = core.options.debug,
    )


    /** Runs [block] on the main thread inside the SDK scope. */
    fun launchMain(block: suspend () -> Unit) {
        core.sdkScope.scope.launch(p.dispatchers.main) { block() }
    }

    /** A scope that runs on the main thread and is cancelled on its own, never cancelling the SDK. */
    fun uiScope(): CoroutineScope {
        val child = core.sdkScope.child()
        return CoroutineScope(child.coroutineContext + p.dispatchers.main)
    }

    /** Publisher callbacks must never be able to crash the SDK. */
    fun safe(block: () -> Unit) {
        try {
            block()
        } catch (t: Throwable) {
            p.logger.error("PentabitAds", "listener threw an exception", t)
        }
    }

    fun releaseAssets(ad: LoadedAd) {
        core.sdkScope.scope.launch {
            for (a in ad.assets.values) p.assetStore.release(a.key)
        }
    }
}
