package com.pentabitlabs.pentabitads.ads

/** What a native video player reports back. Implemented by the ads module, called by pentabit-ads-video. */
public interface VideoListener {
    public fun onPosition(positionMs: Long)
    public fun onCompleted()
    public fun onError(message: String)
    public fun onPaused()
    public fun onResumed()
    public fun onMuteChanged(muted: Boolean)
}

/** A player created by pentabit-ads-video. The platform-specific subtype carries the actual view. */
public interface VideoPlayerHandle {
    public fun play()
    public fun pause()
    public fun setMuted(muted: Boolean)
    public fun release()
}
