@file:OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)

package com.pentabitlabs.pentabitads.ads

import com.pentabitlabs.pentabitads.core.CoreGraph
import com.pentabitlabs.pentabitads.core.mraid.UrlPolicy
import com.pentabitlabs.pentabitads.platform.PlatformContext
import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import platform.Foundation.NSURL
import platform.UIKit.UIApplication
import platform.UIKit.UIView
import platform.UIKit.UIViewController

public actual typealias AdHost = UIViewController

/** An iOS video player: the view to show plus the shared controls. Created by pentabit-ads-video. */
public interface IosVideoPlayer : VideoPlayerHandle {
    public val view: UIView
}

public interface IosVideoPlayerFactory {
    public fun create(filePath: String, listener: VideoListener): IosVideoPlayer
}

/** pentabit-ads-video registers itself here. */
public object IosVideoSupport {
    public var factory: IosVideoPlayerFactory? = null
}

internal fun openExternalUrl(url: String): Boolean {
    if (!UrlPolicy.isAllowedOpenUrl(url)) return false
    val nsUrl = NSURL.URLWithString(url) ?: return false
    UIApplication.sharedApplication.openURL(nsUrl, options = emptyMap<Any?, Any>(), completionHandler = null)
    return true
}

private class IosPresenter : AdPresenter {
    override fun present(host: AdHost, model: AdScreenModel): Boolean {
        var top: UIViewController = host
        while (true) top = top.presentedViewController ?: break
        model.arm()
        val vc = PentabitAdViewController(model)
        top.presentViewController(vc, animated = true, completion = null)
        return true
    }
}

internal actual fun createAdPlatform(context: PlatformContext, core: CoreGraph): AdPlatform = object : AdPlatform {
    override val presenter: AdPresenter = IosPresenter()
    override val supportsVideo: Boolean get() = IosVideoSupport.factory != null
    override fun openUrl(url: String): Boolean = openExternalUrl(url)
}
