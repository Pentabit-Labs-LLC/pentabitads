package com.pentabitlabs.pentabitads.ads

import com.pentabitlabs.pentabitads.core.PentabitEndpoints
import com.pentabitlabs.pentabitads.core.PentabitVersion
import com.pentabitlabs.pentabitads.core.CoreGraph
import com.pentabitlabs.pentabitads.core.CoreOptions
import com.pentabitlabs.pentabitads.core.model.AdFormat
import com.pentabitlabs.pentabitads.analytics.AnalyticsOptions
import com.pentabitlabs.pentabitads.analytics.PentabitAnalytics
import com.pentabitlabs.pentabitads.core.privacy.ConsentSignals
import com.pentabitlabs.pentabitads.platform.PlatformContext
import com.pentabitlabs.pentabitads.platform.createPlatformModule

/** Entry point of the Pentabit Ads SDK for publishers. Call [initialize] once at app start. */
public object PentabitAds {
    private var graph: AdsGraph? = null

    public val isInitialized: Boolean get() = graph != null

    /**
     * Starts the SDK. Returns at once: event upload happens on background threads.
     * Calling it again does nothing. A failure here never throws; ad calls then report NOT_INITIALIZED.
     */
    public fun initialize(context: PlatformContext, options: PentabitAdsOptions) {
        if (graph != null) return
        try {
            val platform = createPlatformModule(context, options.debug)
            if (PentabitEndpoints.BASE_URL.endsWith(".invalid")) {
                platform.logger.warn("PentabitAds", "the SDK still has the placeholder backend URL, so no ads can load")
            }
            val core = CoreGraph(
                platform,
                CoreOptions(options.appKey, PentabitEndpoints.BASE_URL, options.audience, "pentabit-ads", PentabitVersion.VERSION, options.debug, reportUrl = PentabitEndpoints.REPORT_URL),
            )
            val g = AdsGraph(core, createAdPlatform(context, core))
            core.start()
            graph = g
            // Report the app's actions (installs, retention, purchases) too: advertisers are billed on them. Same key, audience and debug.
            PentabitAnalytics.initialize(context, AnalyticsOptions(options.appKey, options.audience, options.debug))
        } catch (t: Throwable) {
            // Never crash the host app because of an SDK start-up problem.
            println("PentabitAds: initialization failed: ${t.message}")
        }
    }

    /** Pass the user's consent and age signals. Call again whenever they change. */
    public fun setConsent(signals: ConsentSignals) {
        graph?.core?.privacy?.update(signals)
        PentabitAnalytics.setConsent(signals)
    }

    public fun interstitial(placementId: String): InterstitialAd = InterstitialAd(placementId) { graph }
    public fun rewarded(placementId: String): RewardedAd = RewardedAd(placementId) { graph }
    public fun appOpen(placementId: String): AppOpenAd = AppOpenAd(placementId) { graph }
    public fun nativeAds(placementId: String): NativeAdLoader = NativeAdLoader(placementId, AdFormat.NATIVE) { graph }
    public fun iconAds(placementId: String): NativeAdLoader = NativeAdLoader(placementId, AdFormat.ICON) { graph }

    public fun shutdown() {
        graph?.core?.shutdown()
        graph = null
    }

    internal fun graphOrNull(): AdsGraph? = graph
}
