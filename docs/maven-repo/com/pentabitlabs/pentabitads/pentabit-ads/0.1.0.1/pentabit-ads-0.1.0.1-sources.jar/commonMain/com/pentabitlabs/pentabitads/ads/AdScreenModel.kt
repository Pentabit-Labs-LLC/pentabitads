package com.pentabitlabs.pentabitads.ads

import com.pentabitlabs.pentabitads.core.ad.LoadedAd
import com.pentabitlabs.pentabitads.core.model.AdFormat
import com.pentabitlabs.pentabitads.core.model.CreativeType
import com.pentabitlabs.pentabitads.core.mraid.CreativeHtml
import com.pentabitlabs.pentabitads.core.mraid.MraidController
import com.pentabitlabs.pentabitads.core.mraid.MraidListener
import com.pentabitlabs.pentabitads.core.mraid.MraidPlacement
import com.pentabitlabs.pentabitads.core.mraid.MraidState
import com.pentabitlabs.pentabitads.core.vast.VastEvents
import com.pentabitlabs.pentabitads.core.vast.VideoProgressTracker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * All presentation logic shared by Android and iOS: MRAID wiring, the close-control timer, reward
 * completion, video progress, viewability and tracking. The platform screen only draws views and
 * forwards what the user and the web view do. Hooks are plain callbacks so Swift can use them.
 */
internal class AdScreenModel(
    private val graph: AdsGraph,
    val ad: LoadedAd,
    private val events: PresentationEvents,
    private val placement: MraidPlacement,
    private val scope: CoroutineScope,
) : MraidListener {

    val telemetry = AdTelemetry(graph.core, ad)
    val isVideo: Boolean = ad.vast != null
    val isFullScreen: Boolean = placement == MraidPlacement.INTERSTITIAL
    val hasEndCard: Boolean get() = ad.endCardMarkup != null
    val isRewarded: Boolean = ad.format == AdFormat.REWARDED
    private val rewardLabel: String = ad.response.reward?.let { "+${it.amount} ${it.type}" } ?: "your reward"

    // Hooks set by the platform screen.
    var runScript: (String) -> Unit = {}
    var onCloseAvailable: () -> Unit = {}
    var onShowEndCard: () -> Unit = {}
    /** Rewarded ads: how far along the reward is (0..1), the text to show ("Reward in 5s", "Reward granted: +50 coins") and whether it was granted. */
    var onReward: (fraction: Float, text: String, granted: Boolean) -> Unit = { _, _, _ -> }
    var onDismiss: () -> Unit = {}

    /** The platform sets this from what is really visible (0..100). */
    var exposurePercent: Double = 0.0

    var closeAvailable: Boolean = false
        private set

    /** True once the ad has closed or failed; a screen that starts late should then just finish. */
    val isFinished: Boolean get() = terminal

    private var mraid = MraidController(placement, this)
    private var began = false
    private var terminal = false
    private var completedFired = false
    private var playable = false
    private var videoDone = false
    private var lastViewable: Boolean? = null
    private var lastExposure = -1.0

    private val progress: VideoProgressTracker? =
        ad.vast?.let { v -> VideoProgressTracker(v.durationMs) { onVastEvent(it) } }

    // ---------- Content ----------

    /** HTML for the main web creative, or null for video ads and creatives with no usable content. */
    fun mainHtml(assetBase: String, assetOrigins: String): String? {
        val c = ad.response.creative
        return when (c.type) {
            CreativeType.HTML -> c.markup?.let { CreativeHtml.prepare(CreativeHtml.expandAssets(it, assetBase), assetOrigins) }
            CreativeType.IMAGE -> {
                val key = (c.assets.firstOrNull { it.role == "image" } ?: c.assets.firstOrNull())?.key ?: return null
                CreativeHtml.prepare(CreativeHtml.staticImagePage(assetBase + key, c.clickUrl, compact = placement == MraidPlacement.INLINE), assetOrigins)
            }
            else -> null
        }
    }

    fun endCardHtml(assetBase: String, assetOrigins: String): String? =
        ad.endCardMarkup?.let { CreativeHtml.prepare(CreativeHtml.expandAssets(it, assetBase), assetOrigins) }

    // ---------- Lifecycle ----------

    /** Call when loading starts. If nothing renders in time, the show fails instead of hanging. */
    fun arm() {
        scope.launch {
            delay(RENDER_TIMEOUT_MS)
            if (!began) fatal("the ad did not render in time")
        }
    }

    fun onPageFinished(maxWidth: Int, maxHeight: Int, screenWidth: Int, screenHeight: Int) {
        for (s in mraid.readyScripts(maxWidth, maxHeight, screenWidth, screenHeight)) runScript(s)
        begin()
    }

    fun onWebMessage(raw: String) {
        mraid.handleRaw(raw)
    }

    /** The creative failed to load (network, asset or WebView crash). */
    fun onContentError(message: String) = fatal(message)

    /** The user pressed the close control or the system back button (only when [closeAvailable]). */
    fun userClose() {
        if (terminal) return
        if (isVideo && !videoDone) telemetry.video(VastEvents.SKIP)
        terminal = true
        telemetry.close()
        events.closed()
        destroy()
        onDismiss()
    }

    /** The platform screen went away without the user closing it (rotation is handled elsewhere). */
    fun onScreenGone() {
        if (!terminal) {
            terminal = true
            events.closed()
        }
        destroy()
    }

    fun destroy() {
        if (scope.isActive) scope.cancel()
    }

    private fun fatal(message: String) {
        if (terminal) return
        terminal = true
        telemetry.error(message)
        events.failed(message)
        destroy()
        onDismiss()
    }

    private fun begin() {
        if (began || terminal) return
        began = true
        events.shown()
        if (telemetry.impression()) events.impression(ad.adValue())
        ad.vast?.durationMs?.let { pushReward(0f, it) }
        startCloseTimer()
        scope.launch {
            while (isActive) {
                tick()
                delay(TICK_MS)
            }
        }
    }

    /** The server decides how long before the close control shows. */
    private val closeDelayMs: Long get() = ad.response.closeDelaySeconds * 1_000L

    private fun startCloseTimer() {
        if (!isFullScreen) return
        val rewarded = ad.format == AdFormat.REWARDED
        val closeAfterMs: Long? = when {
            isVideo && rewarded -> null // only after the video completes
            isVideo -> (ad.vast?.skipOffsetMs ?: closeDelayMs)
            else -> closeDelayMs
        }?.coerceIn(0, MAX_CLOSE_DELAY_MS)
        if (closeAfterMs == null) return
        if (rewarded && !isVideo) scope.launch { // the countdown of a web reward
            var t = 0L
            while (isActive && !completedFired && t < closeAfterMs) {
                if (!playable) pushReward(t.toFloat() / closeAfterMs, closeAfterMs - t)
                delay(TICK_MS)
                t += TICK_MS
            }
        }
        scope.launch {
            delay(closeAfterMs)
            makeCloseAvailable()
            // A rewarded web ad that is not a playable counts as watched once the timer has run.
            if (!isVideo && rewarded && !playable) fireCompleted()
        }
    }

    private fun makeCloseAvailable() {
        if (closeAvailable) return
        closeAvailable = true
        onCloseAvailable()
    }

    private fun fireCompleted() {
        if (completedFired) return
        completedFired = true
        events.completed()
        if (isRewarded) { // tell the user, and let them leave: the ad never closes by itself after a reward
            onReward(1f, "Reward granted: $rewardLabel", true)
            makeCloseAvailable()
        }
    }

    private fun pushReward(fraction: Float, remainingMs: Long) {
        if (!isRewarded || completedFired) return
        onReward(fraction.coerceIn(0f, 1f), "Reward in ${((remainingMs + 999) / 1000).coerceAtLeast(1)}s", false)
    }

    private fun tick() {
        val p = exposurePercent
        telemetry.exposure(p)
        if (mraid.state != MraidState.DEFAULT) return
        val viewable = p > 0.0
        if (viewable != lastViewable) {
            lastViewable = viewable
            runScript(mraid.viewableScript(viewable))
        }
        if (kotlin.math.abs(p - lastExposure) >= 1.0) {
            lastExposure = p
            runScript(mraid.exposureScript(p))
        }
    }

    // ---------- Video ----------

    private fun onVastEvent(name: String) {
        telemetry.video(name)
        if (name == VastEvents.START) begin()
    }

    val videoListener: VideoListener = object : VideoListener {
        override fun onPosition(positionMs: Long) {
            progress?.onPosition(positionMs)
            ad.vast?.durationMs?.takeIf { it > 0 }?.let { pushReward(positionMs.toFloat() / it, it - positionMs) }
        }

        override fun onCompleted() {
            if (videoDone || terminal) return
            videoDone = true
            progress?.onCompleted()
            fireCompleted()
            if (hasEndCard) {
                mraid = MraidController(placement, this@AdScreenModel)
                lastViewable = null
                lastExposure = -1.0
                telemetry.endCardShown()
                makeCloseAvailable()
                onShowEndCard()
            } else if (!isRewarded) {
                userClose()
            } // a rewarded video stays on its last frame with the "Reward granted" card until the user taps Continue
        }

        override fun onError(message: String) = fatal(message)
        override fun onPaused() = telemetry.video(VastEvents.PAUSE)
        override fun onResumed() = telemetry.video(VastEvents.RESUME)
        override fun onMuteChanged(muted: Boolean) = telemetry.video(if (muted) VastEvents.MUTE else VastEvents.UNMUTE)
    }

    // ---------- MRAID listener ----------

    /** A tap on the video, or on its install button: the VAST ClickThrough opens (click trackers fire with it). */
    fun onVideoClick() {
        if (terminal) return
        ad.vast?.clickThrough?.let { onOpen(it) }
    }

    /** The (i) button: opens the privacy page. Not a click on the ad. */
    fun openPrivacyPolicy() { graph.platform.openUrl(CreativeHtml.PRIVACY_URL) }

    override fun onOpen(url: String) {
        if (url == CreativeHtml.PRIVACY_URL) { openPrivacyPolicy(); return } // the (i) button of an image or test ad
        telemetry.click()
        events.clicked()
        if (!graph.platform.openUrl(url)) telemetry.error("could not open the link")
    }

    override fun onClose() {
        if (isFullScreen) userClose()
    }

    override fun onPlayableReady() {
        playable = true
        if (isRewarded && !completedFired) onReward(0f, "Finish the game to earn $rewardLabel", false)
    }

    override fun onPlayableComplete() {
        telemetry.playableComplete()
        fireCompleted()
    }

    override fun onPlayableCta() {
        ad.response.creative.clickUrl?.let { onOpen(it) }
    }

    override fun onCreativeError(message: String) = telemetry.error(message)

    /** Orientation requests are ignored in v1: the screen follows the app and the device. */
    override fun onOrientation(allowChange: Boolean, force: String) {}

    companion object {
        const val RENDER_TIMEOUT_MS: Long = 10_000
        const val TICK_MS: Long = 250
        /** Google Play expects a way to close within 15 seconds. */
        const val MAX_CLOSE_DELAY_MS: Long = 15_000
    }
}
