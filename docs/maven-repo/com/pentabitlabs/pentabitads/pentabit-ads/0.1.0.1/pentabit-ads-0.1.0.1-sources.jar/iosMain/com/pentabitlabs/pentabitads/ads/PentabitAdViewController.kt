@file:OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)

package com.pentabitlabs.pentabitads.ads

import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.useContents
import platform.CoreGraphics.CGRectMake
import platform.Foundation.NSNotificationCenter
import platform.Foundation.NSOperationQueue
import platform.UIKit.UIAction
import platform.UIKit.UIApplicationDidBecomeActiveNotification
import platform.UIKit.UIApplicationWillResignActiveNotification
import platform.UIKit.UIButton
import platform.UIKit.UIButtonTypeCustom
import platform.UIKit.UIColor
import platform.UIKit.UIControlEventTouchUpInside
import platform.UIKit.UIFont
import platform.UIKit.UILabel
import platform.UIKit.UIProgressView
import platform.UIKit.UIProgressViewStyle
import platform.UIKit.accessibilityLabel
import platform.UIKit.modalInPresentation
import platform.UIKit.UIControlStateNormal
import platform.UIKit.UIModalPresentationFullScreen
import platform.UIKit.UIViewController

/**
 * The full-screen host for interstitial, rewarded and app open ads. It only draws: every decision
 * lives in [AdScreenModel]. Requires iOS 14 or later (UIAction).
 */
internal class PentabitAdViewController(private val model: AdScreenModel) : UIViewController(nibName = null, bundle = null) {
    private var web: IosAdWebView? = null
    private var player: IosVideoPlayer? = null
    private var closeButton: UIButton? = null
    private var infoButton: UIButton? = null
    private var videoTap: UIButton? = null
    private var videoCta: UIButton? = null
    private var rewardLabel: UILabel? = null
    private var rewardProgress: UIProgressView? = null
    private var rewardCard: UIButton? = null
    private val observers = mutableListOf<Any>()

    init {
        modalPresentationStyle = UIModalPresentationFullScreen
        modalInPresentation = true
    }

    override fun prefersStatusBarHidden(): Boolean = true

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.blackColor
        if (model.isFinished) {
            dismissViewControllerAnimated(false, null)
            return
        }
        model.onDismiss = { dismissViewControllerAnimated(true, null) }
        model.onCloseAvailable = { closeButton?.setHidden(false) }
        model.onShowEndCard = { showEndCard() }
        addRewardUi()
        addCloseButton()
        if (model.isVideo) startVideo() else startWeb()
        observeAppState()
    }

    private fun startWeb() {
        val w = IosAdWebView(model)
        web = w
        w.view.setFrame(view.bounds)
        view.insertSubview(w.view, atIndex = 0)
        if (!w.showMain()) model.onContentError("the creative has no content")
    }

    private fun startVideo() {
        val factory = IosVideoSupport.factory
        val file = model.ad.videoAsset?.path
        if (factory == null || file == null) {
            model.onContentError("video playback is not available")
            return
        }
        val p = factory.create(file, model.videoListener)
        player = p
        p.view.setFrame(view.bounds)
        view.insertSubview(p.view, atIndex = 0)
        // Tapping the video, or the install button, follows the VAST ClickThrough.
        val tap = UIButton.buttonWithType(UIButtonTypeCustom)
        tap.addAction(UIAction.actionWithHandler { _ -> model.onVideoClick() }, forControlEvents = UIControlEventTouchUpInside)
        videoTap = tap
        view.insertSubview(tap, atIndex = 1)
        val cta = UIButton.buttonWithType(UIButtonTypeCustom)
        cta.setTitle("Install now", forState = UIControlStateNormal)
        cta.setTitleColor(UIColor.blackColor, forState = UIControlStateNormal)
        cta.titleLabel?.font = UIFont.boldSystemFontOfSize(16.0)
        cta.backgroundColor = UIColor.greenColor
        cta.layer.cornerRadius = 24.0
        cta.addAction(UIAction.actionWithHandler { _ -> model.onVideoClick() }, forControlEvents = UIControlEventTouchUpInside)
        videoCta = cta
        view.addSubview(cta)
        p.play()
    }

    private fun showEndCard() {
        videoTap?.removeFromSuperview(); videoCta?.removeFromSuperview(); videoTap = null; videoCta = null
        player?.release()
        player?.view?.removeFromSuperview()
        player = null
        val w = IosAdWebView(model)
        web = w
        w.view.setFrame(view.bounds)
        view.insertSubview(w.view, atIndex = 0)
        if (!w.showEndCard()) model.userClose()
    }

    /** Rewarded ads: "Reward in 5s" with a progress bar on top, then a "Reward granted" button to continue. */
    private fun addRewardUi() {
        if (!model.isRewarded) return
        val l = UILabel()
        l.textColor = UIColor.whiteColor
        l.font = UIFont.systemFontOfSize(14.0)
        l.backgroundColor = UIColor.blackColor.colorWithAlphaComponent(0.6)
        val p = UIProgressView(progressViewStyle = UIProgressViewStyle.UIProgressViewStyleDefault)
        val card = UIButton.buttonWithType(UIButtonTypeCustom)
        card.titleLabel?.numberOfLines = 0
        card.setTitleColor(UIColor.whiteColor, forState = UIControlStateNormal)
        card.titleLabel?.font = UIFont.boldSystemFontOfSize(18.0)
        card.backgroundColor = UIColor.blackColor.colorWithAlphaComponent(0.8)
        card.layer.cornerRadius = 16.0
        card.setHidden(true)
        card.addAction(UIAction.actionWithHandler { _ -> model.userClose() }, forControlEvents = UIControlEventTouchUpInside)
        rewardLabel = l; rewardProgress = p; rewardCard = card
        view.addSubview(l); view.addSubview(p); view.addSubview(card)
        model.onReward = { fraction, text, granted ->
            if (granted && model.hasEndCard) {
                l.text = "  " + text
                p.setProgress(1.0f, animated = false)
            } else if (granted) {
                l.setHidden(true); p.setHidden(true)
                card.setTitle(text + "\nTap to continue", forState = UIControlStateNormal)
                card.setHidden(false)
            } else {
                l.text = "  " + text
                p.setProgress(fraction, animated = false)
            }
        }
    }

    private fun addCloseButton() {
        val b = UIButton.buttonWithType(UIButtonTypeCustom)
        b.setTitle("✕", forState = UIControlStateNormal)
        b.setTitleColor(UIColor.whiteColor, forState = UIControlStateNormal)
        b.titleLabel?.font = UIFont.systemFontOfSize(20.0)
        b.backgroundColor = UIColor.blackColor.colorWithAlphaComponent(0.6)
        b.layer.cornerRadius = 25.0
        b.accessibilityLabel = "Close ad"
        b.setHidden(!model.closeAvailable)
        b.addAction(UIAction.actionWithHandler { _ -> model.userClose() }, forControlEvents = UIControlEventTouchUpInside)
        closeButton = b
        view.addSubview(b)
        if (model.isVideo) {
            val i = UIButton.buttonWithType(UIButtonTypeCustom)
            i.setTitle("i", forState = UIControlStateNormal)
            i.setTitleColor(UIColor.whiteColor, forState = UIControlStateNormal)
            i.titleLabel?.font = UIFont.italicSystemFontOfSize(12.0)
            i.backgroundColor = UIColor.blackColor.colorWithAlphaComponent(0.4)
            i.layer.cornerRadius = 11.0
            i.layer.borderWidth = 1.0
            i.layer.borderColor = UIColor.whiteColor.colorWithAlphaComponent(0.85).CGColor
            i.accessibilityLabel = "Ad info and privacy policy"
            i.addAction(UIAction.actionWithHandler { _ -> model.openPrivacyPolicy() }, forControlEvents = UIControlEventTouchUpInside)
            infoButton = i
            view.addSubview(i)
        }
    }

    override fun viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        val width = view.bounds.useContents { size.width }
        var top = 0.0
        var right = 0.0
        view.safeAreaInsets.useContents { top = this.top; right = this.right }
        closeButton?.setFrame(CGRectMake(width - 50.0 - 8.0 - right, top + 8.0, 50.0, 50.0))
        videoTap?.setFrame(view.bounds)
        videoCta?.setFrame(CGRectMake(width / 2.0 - 110.0, view.bounds.useContents { size.height } - 90.0, 220.0, 48.0))
        rewardLabel?.setFrame(CGRectMake(0.0, 0.0, width, top + 34.0))
        rewardProgress?.setFrame(CGRectMake(0.0, top + 34.0, width, 4.0))
        rewardCard?.setFrame(CGRectMake(width / 2.0 - 130.0, view.bounds.useContents { size.height } - 230.0, 260.0, 90.0))
        rewardLabel?.let { view.bringSubviewToFront(it) }; rewardProgress?.let { view.bringSubviewToFront(it) }; rewardCard?.let { view.bringSubviewToFront(it) }
        var bottom = 0.0
        var left = 0.0
        view.safeAreaInsets.useContents { bottom = this.bottom; left = this.left }
        val height = view.bounds.useContents { size.height }
        infoButton?.let { it.setFrame(CGRectMake(left + 12.0, height - bottom - 34.0, 22.0, 22.0)); view.bringSubviewToFront(it) }
        view.bringSubviewToFront(closeButton ?: return)
    }

    private fun observeAppState() {
        val center = NSNotificationCenter.defaultCenter
        observers += center.addObserverForName(UIApplicationWillResignActiveNotification, null, NSOperationQueue.mainQueue) { _ ->
            model.exposurePercent = 0.0
            player?.pause()
        }
        observers += center.addObserverForName(UIApplicationDidBecomeActiveNotification, null, NSOperationQueue.mainQueue) { _ ->
            model.exposurePercent = 100.0
            player?.play()
        }
    }

    override fun viewDidAppear(animated: Boolean) {
        super.viewDidAppear(animated)
        model.exposurePercent = 100.0
    }

    override fun viewWillDisappear(animated: Boolean) {
        model.exposurePercent = 0.0
        super.viewWillDisappear(animated)
    }

    override fun viewDidDisappear(animated: Boolean) {
        super.viewDidDisappear(animated)
        if (isBeingDismissed() || isMovingFromParentViewController()) cleanup()
    }

    private fun cleanup() {
        observers.forEach { NSNotificationCenter.defaultCenter.removeObserver(it) }
        observers.clear()
        web?.dispose()
        player?.release()
        model.onScreenGone()
    }
}
