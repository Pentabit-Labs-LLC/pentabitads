package com.pentabitlabs.pentabitads.ads

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.min

/**
 * The top-corner control of a full-screen ad: a ring that fills while the ad counts down, with the seconds left in the middle.
 * When the ad can be closed it turns into a plain close mark; it only reacts to taps then.
 */
internal class CloseRing(context: Context, private val onClose: () -> Unit) : View(context) {
    private var fraction = 0f
    private var seconds = 0
    private var closable = false

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x99000000.toInt() }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x55FFFFFF; strokeWidth = context.dp(2.5f).toFloat() }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFFFFFFFF.toInt(); strokeWidth = context.dp(2.5f).toFloat(); strokeCap = Paint.Cap.ROUND }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); textAlign = Paint.Align.CENTER; textSize = context.dp(15f).toFloat(); isFakeBoldText = true }
    private val cross = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFFFFFFFF.toInt(); strokeWidth = context.dp(2f).toFloat(); strokeCap = Paint.Cap.ROUND }
    private val box = RectF()

    init {
        contentDescription = "Ad closes in a moment"
        setOnClickListener { if (closable) onClose() }
    }

    fun setCountdown(fraction: Float, secondsLeft: Int) {
        if (closable) return
        this.fraction = fraction.coerceIn(0f, 1f)
        seconds = secondsLeft
        invalidate()
    }

    fun makeClosable() {
        closable = true
        contentDescription = "Close ad"
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(cx, cy)
        canvas.drawCircle(cx, cy, r, fill)
        if (closable) {
            val d = r * 0.32f
            canvas.drawLine(cx - d, cy - d, cx + d, cy + d, cross)
            canvas.drawLine(cx - d, cy + d, cx + d, cy - d, cross)
            return
        }
        val inset = track.strokeWidth
        box.set(cx - r + inset, cy - r + inset, cx + r - inset, cy + r - inset)
        canvas.drawArc(box, 0f, 360f, false, track)
        canvas.drawArc(box, -90f, 360f * fraction, false, arc)
        canvas.drawText(seconds.coerceAtLeast(0).toString(), cx, cy - (text.ascent() + text.descent()) / 2f, text)
    }
}
