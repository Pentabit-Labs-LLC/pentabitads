package com.pentabitlabs.pentabitads.ads

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * The full-screen host for interstitial, rewarded and app open ads. It only draws: every decision
 * (close timing, rewards, tracking) lives in [AdScreenModel].
 */
public class PentabitAdActivity : Activity() {
    private var token: String? = null
    private var model: AdScreenModel? = null
    private var webView: AdWebView? = null
    private var player: AndroidVideoPlayer? = null
    private var closeRing: CloseRing? = null
    private var simidView: AdWebView? = null
    private var videoOverlay: List<View> = emptyList()
    private lateinit var root: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        token = intent?.getStringExtra(EXTRA_TOKEN)
        val m = ScreenRegistry.get(token)
        if (m == null || m.isFinished) {
            finish() // the process was recreated or the ad already failed
            return
        }
        model = m
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        setContentView(root)
        m.onDismiss = { if (!isFinishing) finish() }
        m.onCloseAvailable = { runOnUiThread { closeRing?.makeClosable() } }
        m.onCountdown = { f, secs -> runOnUiThread { closeRing?.setCountdown(f, secs) } }
        m.onShowEndCard = { showEndCard() }
        addRewardUi(m)
        addCloseButton(m)
        if (m.isVideo) addInfoButton(m)
        try {
            if (m.isVideo) startVideo(m) else startWeb(m)
        } catch (t: Throwable) {
            m.onContentError("the ad screen could not start: ${t.javaClass.simpleName}")
        }
    }

    private fun startWeb(m: AdScreenModel) {
        val web = AdWebView(this, m)
        webView = web
        root.addView(web, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        if (!web.showMain()) m.onContentError("the creative has no content")
    }

    private fun startVideo(m: AdScreenModel) {
        val factory = AndroidVideoSupport.factory
        val file = m.ad.videoAsset?.path
        if (factory == null || file == null) {
            m.onContentError("video playback is not available")
            return
        }
        val p = factory.create(this, file, m.videoListener)
        player = p
        root.addView(p.view, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        // Tapping the video, or the install button, follows the VAST ClickThrough. The tap layer sits above the player and below the controls.
        val tap = View(this).apply { setOnClickListener { m.onVideoClick() } }
        root.addView(tap, 1, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        videoOverlay = listOf(tap)
        if (m.hasSimid) addSimidOverlay(m)
        p.play()
    }

    /** The SIMID overlay: a transparent web view over the bottom band of the video. It stays hidden until the creative says it is ready. */
    private fun addSimidOverlay(m: AdScreenModel) {
        val band = dp(120)
        val d = resources.displayMetrics
        val web = AdWebView(this, m)
        web.visibility = View.INVISIBLE
        simidView = web
        m.onSimidShow = { runOnUiThread { simidView?.visibility = View.VISIBLE } }
        m.onSimidRemove = { runOnUiThread { removeSimid() } }
        root.addView(web, 2, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, band, Gravity.BOTTOM))
        m.configureSimid("https://${com.pentabitlabs.pentabitads.core.mraid.CreativeHtml.ASSET_HOST}/", (d.widthPixels / d.density).toInt(), (d.heightPixels / d.density).toInt(), 120)
        web.showSimid()
    }

    private fun removeSimid() {
        simidView?.dispose()
        simidView = null
    }

    private fun showEndCard() {
        val m = model ?: return
        m.endSimid()
        removeSimid()
        videoOverlay.forEach { root.removeView(it) } // the end card has its own install button
        videoOverlay = emptyList()
        player?.release()
        player?.view?.let { root.removeView(it) }
        player = null
        val web = AdWebView(this, m)
        webView = web
        root.addView(web, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        if (!web.showEndCard()) m.userClose()
    }

    /** The (i) button over a video ad (image and HTML ads draw their own inside the page). */
    private fun addInfoButton(m: AdScreenModel) {
        val b = infoButton(this) { m.openPrivacyPolicy() }
        root.addView(b, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(8), 0, 0, dp(8)) })
    }

    /** Rewarded ads: the countdown ring shows the time left; a "Reward granted" card with a Continue button appears when it is earned. */
    private fun addRewardUi(m: AdScreenModel) {
        if (!m.isRewarded) return
        val label = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0x99000000.toInt()) }
            visibility = View.GONE
        }
        root.addView(label, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START).apply { setMargins(dp(12), dp(16), dp(12), 0) })
        val title = TextView(this).apply { setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f); gravity = Gravity.CENTER }
        val go = TextView(this).apply {
            text = "Continue"
            setTextColor(Color.parseColor("#10213F"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(Color.parseColor("#B6F25A")) }
            setOnClickListener { m.userClose() }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(20), dp(24), dp(20))
            background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(0xEE1B1038.toInt()) }
            visibility = View.GONE
            addView(title)
            addView(go, LinearLayout.LayoutParams(dp(220), dp(46)).apply { topMargin = dp(16) })
        }
        root.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM).apply { bottomMargin = dp(110) })
        m.onReward = { _, text, granted ->
            runOnUiThread {
                if (granted && !m.hasEndCard) { label.visibility = View.GONE; title.text = text; card.visibility = View.VISIBLE }
                else if (granted || !text.startsWith("Reward in")) { label.text = text; label.visibility = View.VISIBLE } // the ring already shows the countdown
            }
        }
    }

    /** The countdown ring in the top corner; it becomes the close mark when the ad can be closed. */
    private fun addCloseButton(m: AdScreenModel) {
        val ring = CloseRing(this) { m.userClose() }
        if (m.closeAvailable) ring.makeClosable()
        closeRing = ring
        root.addView(ring, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.END).apply { setMargins(dp(12), dp(12), dp(12), dp(12)) })
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Back only works once the close control is available, like the control itself.
        val m = model
        if (m == null || m.closeAvailable) {
            if (m != null) m.userClose() else super.onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        model?.exposurePercent = 100.0
        player?.play()
    }

    override fun onPause() {
        model?.exposurePercent = 0.0
        player?.pause()
        super.onPause()
    }

    override fun onDestroy() {
        webView?.dispose()
        simidView?.dispose()
        player?.release()
        ScreenRegistry.remove(token)
        if (isFinishing) model?.onScreenGone()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
