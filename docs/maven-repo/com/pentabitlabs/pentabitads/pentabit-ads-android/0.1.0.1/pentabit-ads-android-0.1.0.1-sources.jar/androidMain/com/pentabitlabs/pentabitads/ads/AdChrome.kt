package com.pentabitlabs.pentabitads.ads

import android.content.Context
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

private const val AD_YELLOW = 0xFFFBC02D.toInt()
private const val INFO_BLUE = 0xFF00AEEF.toInt()

internal fun Context.dp(v: Float): Int = (v * resources.displayMetrics.density).toInt()

/** The small yellow "Ad" tag. Google Play and Apple require native ads to be identifiable. */
internal fun adBadge(context: Context): TextView = TextView(context).apply {
    text = "Ad"
    setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
    setTypeface(typeface, Typeface.BOLD)
    setTextColor(Color.WHITE)
    includeFontPadding = false
    gravity = Gravity.CENTER
    setPadding(context.dp(4f), 0, context.dp(4f), 0)
    background = GradientDrawable().apply { setColor(AD_YELLOW); cornerRadius = context.dp(3f).toFloat() }
    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, context.dp(13f))
}

/** The round (i) button: a small ring in a 28 dp tap area. */
internal fun infoButton(context: Context, onTap: () -> Unit): TextView = TextView(context).apply {
    text = "i"
    setTextSize(TypedValue.COMPLEX_UNIT_SP, 7f)
    setTypeface(typeface, Typeface.BOLD)
    setTextColor(INFO_BLUE)
    includeFontPadding = false
    gravity = Gravity.CENTER
    contentDescription = "Ad info and privacy policy"
    background = InsetDrawable(GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT); setStroke(context.dp(1f), INFO_BLUE) }, context.dp(8.5f))
    isClickable = true
    setOnClickListener { onTap() }
}

/** Counts the impression once the ad is on screen, and feeds visibility so a viewable impression is counted too. */
internal class ImpressionWatcher(private val view: View, private val ad: NativeAd) {
    private val handler = Handler(Looper.getMainLooper())
    private var counted = false
    private val tick = object : Runnable {
        override fun run() {
            val p = visiblePercent()
            ad.onExposure(p)
            if (!counted && p > 0.0) { counted = true; ad.recordImpression() }
            handler.postDelayed(this, 250)
        }
    }

    fun start() { handler.removeCallbacks(tick); handler.post(tick) }
    fun stop() = handler.removeCallbacks(tick)

    private fun visiblePercent(): Double {
        if (!view.isShown || !view.hasWindowFocus() || view.width == 0 || view.height == 0) return 0.0
        val r = Rect()
        if (!view.getGlobalVisibleRect(r)) return 0.0
        return (r.width().toDouble() * r.height()) * 100.0 / (view.width.toDouble() * view.height)
    }
}
