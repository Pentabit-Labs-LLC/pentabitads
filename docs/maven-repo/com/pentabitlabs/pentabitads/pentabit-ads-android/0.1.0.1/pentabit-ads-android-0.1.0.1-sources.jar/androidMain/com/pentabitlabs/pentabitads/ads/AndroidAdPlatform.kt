package com.pentabitlabs.pentabitads.ads

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.View
import com.pentabitlabs.pentabitads.core.CoreGraph
import com.pentabitlabs.pentabitads.core.mraid.UrlPolicy
import com.pentabitlabs.pentabitads.platform.PlatformContext
import java.util.concurrent.ConcurrentHashMap

public actual typealias AdHost = Activity

/** An Android video player: the view to show plus the shared controls. Created by pentabit-ads-video. */
public interface AndroidVideoPlayer : VideoPlayerHandle {
    public val view: View
}

public interface AndroidVideoPlayerFactory {
    public fun create(context: Context, filePath: String, listener: VideoListener): AndroidVideoPlayer
}

/** pentabit-ads-video registers itself here. Without it, video ads are never requested to be shown. */
public object AndroidVideoSupport {
    @Volatile
    public var factory: AndroidVideoPlayerFactory? = null
}

/** Models cannot cross an Intent, so the Activity looks its model up by token. */
internal object ScreenRegistry {
    private val models = ConcurrentHashMap<String, AdScreenModel>()
    fun put(token: String, model: AdScreenModel) { models[token] = model }
    fun get(token: String?): AdScreenModel? = if (token == null) null else models[token]
    fun remove(token: String?) { if (token != null) models.remove(token) }
}

internal const val EXTRA_TOKEN = "aks.token"

internal fun openExternalUrl(context: Context, url: String): Boolean {
    if (!UrlPolicy.isAllowedOpenUrl(url)) return false
    return try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false // no app can open it
    }
}

private class AndroidPresenter(private val core: CoreGraph) : AdPresenter {
    override fun present(host: AdHost, model: AdScreenModel): Boolean {
        if (host.isFinishing) return false
        val token = core.platform.ids.newId()
        ScreenRegistry.put(token, model)
        model.arm()
        return try {
            host.startActivity(Intent(host, PentabitAdActivity::class.java).putExtra(EXTRA_TOKEN, token))
            true
        } catch (e: Exception) {
            ScreenRegistry.remove(token)
            false
        }
    }
}

internal actual fun createAdPlatform(context: PlatformContext, core: CoreGraph): AdPlatform {
    val app = context.applicationContext
    return object : AdPlatform {
        override val presenter: AdPresenter = AndroidPresenter(core)
        override val supportsVideo: Boolean get() = AndroidVideoSupport.factory != null
        override fun openUrl(url: String): Boolean = openExternalUrl(app, url)
    }
}
