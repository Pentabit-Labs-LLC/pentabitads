package com.pentabitlabs.pentabitads.ads

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/**
 * The full-screen host for interstitial, rewarded and app open ads. It only draws: every decision
 * (close timing, rewards, tracking) lives in [AdScreenModel].
 */
public class PentabitAdActivity : Activity() {
    private var token: String? = null
    private var model: AdScreenModel? = null
    private var webView: AdWebView? = null
    private var player: AndroidVideoPlayer? = null
    private var closeButton: TextView? = null
    private var videoOverlay: List<View> = emptyList()
    private lateinit var root: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        token = intent?.getStringExtra(EXTRA_TOKEN)
        val m = ScreenRegistry.get(token)
        if (m == null || m.isFinished) {
            finish() // the process was recreated or the ad already failed
            return
        }
        model = m
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        setContentView(root)
        m.onDismiss = { if (!isFinishing) finish() }
        m.onCloseAvailable = { closeButton?.visibility = View.VISIBLE }
        m.onShowEndCard = { showEndCard() }
        addRewardUi(m)
        addCloseButton(m)
        if (m.isVideo) addInfoButton(m)
        try {
            if (m.isVideo) startVideo(m) else startWeb(m)
        } catch (t: Throwable) {
            m.onContentError("the ad screen could not start: ${t.javaClass.simpleName}")
        }
    }

    private fun startWeb(m: AdScreenModel) {
        val web = AdWebView(this, m)
        webView = web
        root.addView(web, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        if (!web.showMain()) m.onContentError("the creative has no content")
    }

    private fun startVideo(m: AdScreenModel) {
        val factory = AndroidVideoSupport.factory
        val file = m.ad.videoAsset?.path
        if (factory == null || file == null) {
            m.onContentError("video playback is not available")
            return
        }
        val p = factory.create(this, file, m.videoListener)
        player = p
        root.addView(p.view, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        // Tapping the video, or the install button, follows the VAST ClickThrough. The tap layer sits above the player and below the controls.
        val tap = View(this).apply { setOnClickListener { m.onVideoClick() } }
        root.addView(tap, 1, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val cta = TextView(this).apply {
            text = "Install now"
            setTextColor(Color.parseColor("#10213F"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { cornerRadius = dp(24).toFloat(); setColor(Color.parseColor("#B6F25A")) }
            setOnClickListener { m.onVideoClick() }
        }
        root.addView(cta, FrameLayout.LayoutParams(dp(220), dp(48), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(28) })
        videoOverlay = listOf(tap, cta)
        p.play()
    }

    private fun showEndCard() {
        val m = model ?: return
        videoOverlay.forEach { root.removeView(it) } // the end card has its own install button
        videoOverlay = emptyList()
        player?.release()
        player?.view?.let { root.removeView(it) }
        player = null
        val web = AdWebView(this, m)
        webView = web
        root.addView(web, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        if (!web.showEndCard()) m.userClose()
    }

    /** The (i) button over a video ad (image and HTML ads draw their own inside the page). */
    private fun addInfoButton(m: AdScreenModel) {
        val b = infoButton(this) { m.openPrivacyPolicy() }
        root.addView(b, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(8), 0, 0, dp(8)) })
    }

    /** Rewarded ads: a bar on top with "Reward in 5s" and its progress, then a "Reward granted" card with a Continue button when it is earned. */
    private fun addRewardUi(m: AdScreenModel) {
        if (!m.isRewarded) return
        val label = TextView(this).apply { setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f); setPadding(dp(14), dp(10), dp(70), dp(6)) }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0x99000000.toInt())
            addView(label)
            addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4)))
        }
        root.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        val title = TextView(this).apply { setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f); gravity = Gravity.CENTER }
        val go = TextView(this).apply {
            text = "Continue"
            setTextColor(Color.parseColor("#10213F"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(Color.parseColor("#B6F25A")) }
            setOnClickListener { m.userClose() }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(20), dp(24), dp(20))
            background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(0xEE1B1038.toInt()) }
            visibility = View.GONE
            addView(title)
            addView(go, LinearLayout.LayoutParams(dp(220), dp(46)).apply { topMargin = dp(16) })
        }
        root.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM).apply { bottomMargin = dp(110) })
        m.onReward = { fraction, text, granted ->
            runOnUiThread {
                if (granted && m.hasEndCard) { label.text = text; bar.progress = 1000 } // the app card takes the screen: the reward is just a line on top
                else if (granted) { box.visibility = View.GONE; title.text = text; card.visibility = View.VISIBLE }
                else { label.text = text; bar.progress = (fraction * 1000).toInt() }
            }
        }
    }

    private fun addCloseButton(m: AdScreenModel) {
        val size = dp(50)
        val button = TextView(this).apply {
            text = "✕"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            gravity = Gravity.CENTER
            contentDescription = "Close ad"
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x99000000.toInt()) }
            visibility = if (m.closeAvailable) View.VISIBLE else View.GONE
            setOnClickListener { m.userClose() }
        }
        closeButton = button
        val lp = FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.END).apply { setMargins(dp(8), dp(8), dp(8), dp(8)) }
        root.addView(button, lp)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Back only works once the close control is available, like the control itself.
        val m = model
        if (m == null || m.closeAvailable) {
            if (m != null) m.userClose() else super.onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        model?.exposurePercent = 100.0
        player?.play()
    }

    override fun onPause() {
        model?.exposurePercent = 0.0
        player?.pause()
        super.onPause()
    }

    override fun onDestroy() {
        webView?.dispose()
        player?.release()
        ScreenRegistry.remove(token)
        if (isFinishing) model?.onScreenGone()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
