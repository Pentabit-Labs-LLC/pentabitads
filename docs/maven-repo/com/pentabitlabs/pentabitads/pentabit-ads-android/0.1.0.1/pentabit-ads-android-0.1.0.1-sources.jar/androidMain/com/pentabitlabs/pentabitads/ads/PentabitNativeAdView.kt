package com.pentabitlabs.pentabitads.ads

import android.content.Context
import android.graphics.BitmapFactory
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * The container for a native ad, used like AdMob's NativeAdView. Put your own views inside it, tell it which view
 * shows which asset, then call [setNativeAd]:
 *
 * ```
 * nativeAdView.headlineView = titleText
 * nativeAdView.bodyView = bodyText
 * nativeAdView.callToActionView = installButton
 * nativeAdView.iconView = iconImage
 * nativeAdView.mediaView = mainImage
 * nativeAdView.setNativeAd(ad)
 * ```
 *
 * It fills the views, hides the ones the ad has no asset for, counts the impression when the ad is on screen,
 * records clicks on the registered views, and draws the "Ad" tag and the (i) privacy button in the top-end corner.
 * Call [destroy] when you remove it (the [NativeAd] itself is still destroyed by you).
 */
public class PentabitNativeAdView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : FrameLayout(context, attrs) {

    public var headlineView: View? = null
    public var bodyView: View? = null
    public var callToActionView: View? = null
    public var iconView: View? = null
    /** The main image. */
    public var mediaView: ImageView? = null

    private var ad: NativeAd? = null
    private var watcher: ImpressionWatcher? = null
    private var chrome: View? = null

    public fun setNativeAd(nativeAd: NativeAd) {
        destroy()
        ad = nativeAd
        fill(headlineView, nativeAd.title)
        fill(bodyView, nativeAd.body)
        fill(callToActionView, nativeAd.callToAction)
        picture(iconView as? ImageView, nativeAd.iconPath)
        picture(mediaView, nativeAd.imagePath)
        listOfNotNull(headlineView, bodyView, callToActionView, iconView, mediaView).forEach { v ->
            v.isClickable = true
            v.setOnClickListener { nativeAd.recordClick() }
        }
        val bar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(adBadge(context))
            addView(infoButton(context) { nativeAd.openPrivacyPolicy() }, LinearLayout.LayoutParams(context.dp(28f), context.dp(28f)))
        }
        addView(bar, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply { setMargins(0, context.dp(2f), context.dp(2f), 0) })
        chrome = bar
        watcher = ImpressionWatcher(this, nativeAd).also { if (isAttachedToWindow) it.start() }
    }

    /** Stops impression tracking and removes the "Ad" tag. Safe to call more than once. */
    public fun destroy() {
        watcher?.stop()
        watcher = null
        chrome?.let { removeView(it) }
        chrome = null
        ad = null
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        watcher?.start()
    }

    override fun onDetachedFromWindow() {
        watcher?.stop()
        super.onDetachedFromWindow()
    }

    private fun fill(v: View?, text: String?) {
        if (v == null) return
        if (text == null) { v.visibility = View.GONE; return }
        (v as? TextView)?.text = text
        v.visibility = View.VISIBLE
    }

    private fun picture(v: ImageView?, path: String?) {
        if (v == null) return
        val bmp = path?.let { BitmapFactory.decodeFile(it) }
        if (bmp == null) { v.visibility = View.GONE; return }
        v.setImageBitmap(bmp)
        v.visibility = View.VISIBLE
    }
}
