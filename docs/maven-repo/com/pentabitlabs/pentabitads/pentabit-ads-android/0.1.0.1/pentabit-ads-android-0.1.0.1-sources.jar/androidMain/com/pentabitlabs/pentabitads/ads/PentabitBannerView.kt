package com.pentabitlabs.pentabitads.ads

import android.content.Context
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.Gravity
import android.widget.FrameLayout
import com.pentabitlabs.pentabitads.core.error.AdError
import com.pentabitlabs.pentabitads.core.error.AdErrorCode
import com.pentabitlabs.pentabitads.core.error.AdResult
import com.pentabitlabs.pentabitads.core.mraid.MraidPlacement

/**
 * Drop-in banner. Put it in your layout, then call [load]. Banners are HTML creatives rendered through
 * the same MRAID web view as every other web ad. Call [destroy] from onDestroy.
 */
public class PentabitBannerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : FrameLayout(context, attrs) {

    /** The banner size to request. Set it before [load]; the default is 320x50. */
    public var adSize: BannerSize = BannerSize.BANNER

    private var model: AdScreenModel? = null
    private var web: AdWebView? = null
    private var ad: com.pentabitlabs.pentabitads.core.ad.LoadedAd? = null
    private var graph: AdsGraph? = null
    private var loadGeneration = 0
    private val handler = Handler(Looper.getMainLooper())
    private val exposureTick = object : Runnable {
        override fun run() {
            model?.exposurePercent = visiblePercent()
            handler.postDelayed(this, 250)
        }
    }

    public fun load(placementId: String, listener: BannerListener = BannerListener()) {
        val g = PentabitAds.graphOrNull()
        if (g == null) {
            listener.onLoadFailed(AdError(AdErrorCode.NOT_INITIALIZED, "call PentabitAds.initialize first"))
            return
        }
        clear()
        val generation = ++loadGeneration
        g.launchMain {
            val result = g.loadBanner(placementId, adSize)
            if (generation != loadGeneration) {
                if (result is AdResult.Success) g.releaseAssets(result.value)
                return@launchMain
            }
            when (result) {
                is AdResult.Failure -> g.safe { listener.onLoadFailed(result.error) }
                is AdResult.Success -> show(g, result.value, listener)
            }
        }
    }

    private fun show(g: AdsGraph, ad: com.pentabitlabs.pentabitads.core.ad.LoadedAd, listener: BannerListener) {
        val events = object : PresentationEvents {
            override fun shown() = g.safe { listener.onShown() }
            override fun impression(value: AdValue) = g.safe { listener.onAdImpression(); listener.onAdPaid(value) }
            override fun clicked() = g.safe { listener.onClicked() }
            override fun completed() {}
            override fun closed() {}
            override fun failed(message: String) {
                g.safe { listener.onLoadFailed(AdError(AdErrorCode.INTERNAL, message)) }
                clear()
            }
        }
        val m = AdScreenModel(g, ad, events, MraidPlacement.INLINE, g.uiScope())
        model = m
        this.ad = ad
        graph = g
        try {
            val view = AdWebView(context, m)
            web = view
            val d = resources.displayMetrics.density
            val w = ad.response.creative.width?.let { (it * d).toInt() } ?: LayoutParams.MATCH_PARENT
            val h = ad.response.creative.height?.let { (it * d).toInt() } ?: LayoutParams.WRAP_CONTENT
            addView(view, LayoutParams(w, h, Gravity.CENTER))
            m.arm()
            if (view.showMain()) g.safe { listener.onLoaded() } else m.onContentError("the creative has no content")
        } catch (t: Throwable) {
            m.onContentError("the banner could not start: ${t.javaClass.simpleName}")
        }
    }

    private fun visiblePercent(): Double {
        if (!isShown || !hasWindowFocus() || width == 0 || height == 0) return 0.0
        val r = Rect()
        if (!getGlobalVisibleRect(r)) return 0.0
        return (r.width().toDouble() * r.height()) * 100.0 / (width.toDouble() * height)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        handler.post(exposureTick)
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(exposureTick)
        super.onDetachedFromWindow()
    }

    private fun clear() {
        model?.onScreenGone()
        model = null
        ad?.let { graph?.releaseAssets(it) }
        ad = null
        web?.dispose()
        web = null
    }

    public fun destroy() {
        loadGeneration++
        clear()
    }
}
