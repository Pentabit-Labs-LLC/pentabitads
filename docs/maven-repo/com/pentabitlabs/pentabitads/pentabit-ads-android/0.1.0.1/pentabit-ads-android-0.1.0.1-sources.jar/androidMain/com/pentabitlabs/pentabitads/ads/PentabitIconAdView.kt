package com.pentabitlabs.pentabitads.ads

import android.animation.Animator
import android.animation.Keyframe
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.Context
import android.graphics.BitmapFactory
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView

/** The box an icon ad is drawn in. */
public enum class IconAdSize(public val dp: Int) { SMALL(64), MEDIUM(96), LARGE(128) }

/** The attention animation of an icon ad: one burst, a pause, repeat. */
public enum class IconAdAnimation { NONE, SHAKE, WIGGLE, BOUNCE, ROTATE, PULSE }

/**
 * Draws an icon ad: the app icon in a fixed box with an "Ad" tag (top-end) and the (i) privacy button (bottom-start).
 * Load it with `PentabitAds.iconAds(id)`, then:
 *
 * ```
 * iconAdView.adSize = IconAdSize.MEDIUM
 * iconAdView.animation = IconAdAnimation.PULSE
 * iconAdView.setNativeAd(ad)
 * ```
 *
 * Set [adSize] and [animation] before [setNativeAd]. The impression is counted when the icon is on screen and a tap opens the
 * advertiser's page. Call [destroy] when you remove it.
 */
public class PentabitIconAdView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : FrameLayout(context, attrs) {

    public var adSize: IconAdSize = IconAdSize.MEDIUM
    public var animation: IconAdAnimation = IconAdAnimation.NONE
    /** Pause between animation bursts, in seconds. */
    public var animationDelaySeconds: Int = 3
    /** Play the animation once instead of repeating. */
    public var animateOnce: Boolean = false

    private var watcher: ImpressionWatcher? = null
    private var animator: Animator? = null

    init {
        clipChildren = false
        clipToPadding = false
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val side = context.dp(adSize.dp.toFloat())
        super.onMeasure(MeasureSpec.makeMeasureSpec(side, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(side, MeasureSpec.EXACTLY))
    }

    public fun setNativeAd(nativeAd: NativeAd) {
        destroy()
        val side = context.dp(adSize.dp.toFloat())
        val margin = (side * 0.115f).toInt() // the icon fills 77% of the box so animations have room
        val icon = ImageView(context).apply {
            path(nativeAd.iconPath)?.let { setImageBitmap(it) }
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Sponsored app icon"
            isClickable = true
            setOnClickListener { nativeAd.recordClick() }
        }
        addView(icon, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, Gravity.CENTER).apply { setMargins(margin, margin, margin, margin) })
        addView(adBadge(context), LayoutParams(LayoutParams.WRAP_CONTENT, context.dp(13f), Gravity.TOP or Gravity.END).apply { setMargins(0, context.dp(3f), context.dp(3f), 0) })
        addView(infoButton(context) { nativeAd.openPrivacyPolicy() }, LayoutParams(context.dp(28f), context.dp(28f), Gravity.BOTTOM or Gravity.START).apply { setMargins(-context.dp(5.5f), 0, 0, -context.dp(5.5f)) })
        animator = makeAnimator(icon, side.toFloat())
        watcher = ImpressionWatcher(this, nativeAd).also { if (isAttachedToWindow) { it.start(); animator?.start() } }
    }

    /** Stops tracking and animation and clears the ad. Safe to call more than once. */
    public fun destroy() {
        watcher?.stop(); watcher = null
        animator?.cancel(); animator = null
        removeAllViews()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        watcher?.start()
        animator?.let { if (!it.isStarted) it.start() }
    }

    override fun onDetachedFromWindow() {
        watcher?.stop()
        animator?.cancel()
        super.onDetachedFromWindow()
    }

    private fun path(p: String?) = p?.let { BitmapFactory.decodeFile(it) }

    // Timings and distances follow the icon ads of the Apps Kit SDK.
    private fun makeAnimator(target: View, side: Float): Animator? {
        if (animation == IconAdAnimation.NONE) return null
        val once = animateOnce
        val delay = animationDelaySeconds
        fun prop(name: String, burstMs: Long, frames: List<Pair<Float, Float>>): PropertyValuesHolder {
            val cycle = if (once) burstMs else burstMs + delay * 1000L
            val k = frames.map { (t, v) -> Keyframe.ofFloat(t * burstMs / cycle, v) }.toMutableList()
            if (!once && delay > 0) k.add(Keyframe.ofFloat(1f, frames.last().second))
            return PropertyValuesHolder.ofKeyframe(name, *k.toTypedArray())
        }
        fun run(burstMs: Long, vararg h: PropertyValuesHolder): Animator = ObjectAnimator.ofPropertyValuesHolder(target, *h).apply {
            duration = if (once) burstMs else burstMs + delay * 1000L
            repeatCount = if (once) 0 else ObjectAnimator.INFINITE
            interpolator = LinearInterpolator()
        }
        return when (animation) {
            IconAdAnimation.SHAKE -> run(840, prop("translationX", 840, listOf(0f to 0f, .143f to -.08f * side, .286f to .08f * side, .429f to -.08f * side, .571f to .08f * side, .714f to -.04f * side, .857f to .04f * side, 1f to 0f)))
            IconAdAnimation.WIGGLE -> run(750, prop("rotation", 750, listOf(0f to 0f, .2f to -10f, .4f to 10f, .6f to -10f, .8f to 10f, 1f to 0f)))
            IconAdAnimation.BOUNCE -> run(1250, prop("translationY", 1250, listOf(0f to 0f, .3f to -.11f * side, .6f to 0f, .8f to -.05f * side, 1f to 0f)))
            IconAdAnimation.ROTATE -> run(1200, prop("rotation", 1200, listOf(0f to 0f, .25f to 45f, .5f to 180f, .75f to 315f, 1f to 360f)))
            IconAdAnimation.PULSE -> { val f = listOf(0f to 1f, .25f to 1.075f, .5f to 1.15f, .75f to 1.075f, 1f to 1f); run(1200, prop("scaleX", 1200, f), prop("scaleY", 1200, f)) }
            IconAdAnimation.NONE -> null
        }
    }
}
