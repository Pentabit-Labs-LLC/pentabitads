package com.pentabitlabs.pentabitads.ads

import android.content.Context
import com.pentabitlabs.pentabitads.platform.PlatformContext

/** Android convenience: `PentabitAds.initialize(applicationContext, options)`. */
public fun PentabitAds.initialize(context: Context, options: PentabitAdsOptions) {
    initialize(PlatformContext(context.applicationContext), options)
}
