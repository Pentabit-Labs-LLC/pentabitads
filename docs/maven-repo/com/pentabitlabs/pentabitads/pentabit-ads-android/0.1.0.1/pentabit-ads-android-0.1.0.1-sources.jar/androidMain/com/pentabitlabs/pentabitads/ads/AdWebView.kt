package com.pentabitlabs.pentabitads.ads

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.pentabitlabs.pentabitads.core.mraid.CreativeHtml
import com.pentabitlabs.pentabitads.core.mraid.UrlPolicy
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream

private const val ASSET_BASE = "https://${CreativeHtml.ASSET_HOST}/"
private const val ASSET_ORIGINS = "https://${CreativeHtml.ASSET_HOST}"

/**
 * The one WebView every web creative uses. It is locked down: no file or content access, no storage,
 * every navigation blocked, and only cached assets can be loaded (everything else gets a 403).
 */
@SuppressLint("SetJavaScriptEnabled", "ViewConstructor")
internal class AdWebView(context: Context, private val model: AdScreenModel) : WebView(context) {
    private val main = Handler(Looper.getMainLooper())
    private var disposed = false

    init {
        with(settings) {
            javaScriptEnabled = true
            domStorageEnabled = false
            allowFileAccess = false
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = false
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
        }
        setBackgroundColor(0)
        overScrollMode = OVER_SCROLL_NEVER
        isVerticalScrollBarEnabled = false
        isHorizontalScrollBarEnabled = false
        addJavascriptInterface(Bridge(), "AksNative")
        webViewClient = Client()
        model.runScript = { js -> if (!disposed) evaluateJavascript(js, null) }
    }

    /** Loads the already prepared page (see [AdScreenModel.mainHtml]). */
    fun showHtml(html: String) {
        loadDataWithBaseURL(ASSET_BASE, html, "text/html", "utf-8", null)
    }

    fun showMain(): Boolean {
        val html = model.mainHtml(ASSET_BASE, ASSET_ORIGINS) ?: return false
        showHtml(html)
        return true
    }

    fun showEndCard(): Boolean {
        val html = model.endCardHtml(ASSET_BASE, ASSET_ORIGINS) ?: return false
        showHtml(html)
        return true
    }

    fun dispose() {
        if (disposed) return
        disposed = true
        try {
            stopLoading()
            removeJavascriptInterface("AksNative")
            (parent as? ViewGroup)?.removeView(this)
            destroy()
        } catch (e: Exception) {
            // Already torn down by the system; nothing more to do.
        }
    }

    private inner class Bridge {
        // Called on a background thread by WebView; hop to the main thread.
        @JavascriptInterface
        fun post(message: String) {
            main.post { if (!disposed) model.onWebMessage(message) }
        }
    }

    private inner class Client : WebViewClient() {
        override fun onPageFinished(view: WebView, url: String?) {
            if (disposed || url == "about:blank") return
            val d = resources.displayMetrics
            val w = (view.width / d.density).toInt().takeIf { it > 0 } ?: (d.widthPixels / d.density).toInt()
            val h = (view.height / d.density).toInt().takeIf { it > 0 } ?: (d.heightPixels / d.density).toInt()
            model.onPageFinished(w, h, (d.widthPixels / d.density).toInt(), (d.heightPixels / d.density).toInt())
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {}

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            // A creative may not navigate. A tap that tried to is treated as a click-out.
            if (request.hasGesture() && UrlPolicy.isAllowedOpenUrl(request.url.toString())) model.onOpen(request.url.toString())
            return true
        }

        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            val uri = request.url
            // The creative page itself is loaded as a data: URL (loadDataWithBaseURL). It is our own content, not the network.
            if (uri.scheme == "data") return null
            if (uri.host == CreativeHtml.ASSET_HOST) {
                val key = uri.lastPathSegment
                val asset = if (key != null) model.ad.assets[key] else null
                val file = asset?.let { File(it.path) }
                if (file != null && file.isFile) {
                    val declared = model.ad.response.creative.assets.firstOrNull { it.key == key }?.mime
                    val ext = MimeTypeMap.getFileExtensionFromUrl(uri.toString())
                    val mime = declared ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
                    return try {
                        WebResourceResponse(mime, null, 200, "OK", mapOf("Access-Control-Allow-Origin" to "*"), FileInputStream(file))
                    } catch (e: Exception) {
                        blocked(404, "Not Found")
                    }
                }
                return blocked(404, "Not Found")
            }
            return blocked(403, "Blocked")
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (request.isForMainFrame) main.post { model.onContentError("the creative could not be loaded: ${error.description} (${request.url})") }
        }

        override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
            if (request.isForMainFrame) main.post { model.onContentError("the creative page got HTTP ${errorResponse.statusCode} (${request.url})") }
        }

        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
            main.post { model.onContentError("the web view crashed") }
            return true
        }

        private fun blocked(code: Int, reason: String) =
            WebResourceResponse("text/plain", "utf-8", code, reason, emptyMap(), ByteArrayInputStream(ByteArray(0)))
    }
}
