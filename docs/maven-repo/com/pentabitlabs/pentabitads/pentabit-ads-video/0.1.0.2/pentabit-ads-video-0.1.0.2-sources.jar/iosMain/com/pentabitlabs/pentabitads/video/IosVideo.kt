@file:OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)

package com.pentabitlabs.pentabitads.video

import com.pentabitlabs.pentabitads.ads.IosVideoPlayer
import com.pentabitlabs.pentabitads.ads.IosVideoPlayerFactory
import com.pentabitlabs.pentabitads.ads.IosVideoSupport
import com.pentabitlabs.pentabitads.ads.VideoListener
import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.readValue
import platform.AVFoundation.AVLayerVideoGravityResizeAspect
import platform.AVFoundation.AVPlayer
import platform.AVFoundation.AVPlayerItem
import platform.AVFoundation.AVPlayerItemDidPlayToEndTimeNotification
import platform.AVFoundation.AVPlayerItemStatusFailed
import platform.AVFoundation.AVPlayerLayer
import platform.AVFoundation.currentItem
import platform.AVFoundation.currentTime
import platform.AVFoundation.muted
import platform.AVFoundation.pause
import platform.AVFoundation.play
import platform.CoreGraphics.CGRectZero
import platform.CoreMedia.CMTimeGetSeconds
import platform.Foundation.NSNotificationCenter
import platform.Foundation.NSOperationQueue
import platform.Foundation.NSTimer
import platform.Foundation.NSURL
import platform.UIKit.UIColor
import platform.UIKit.UIView

public actual object PentabitAdsVideo {
    public actual fun install() {
        IosVideoSupport.factory = AvFactory
    }
}

private object AvFactory : IosVideoPlayerFactory {
    override fun create(filePath: String, listener: VideoListener): IosVideoPlayer = AvPlayer(filePath, listener)
}

/** Hosts the player layer and keeps it the size of the view. */
private class PlayerHostView(private val layer0: AVPlayerLayer) : UIView(frame = CGRectZero.readValue()) {
    init {
        backgroundColor = UIColor.blackColor
        layer.addSublayer(layer0)
    }

    override fun layoutSubviews() {
        super.layoutSubviews()
        layer0.setFrame(bounds)
    }
}

/** Plays a cached mp4 with AVPlayer. A 4 Hz timer reports progress and notices failures. */
private class AvPlayer(filePath: String, private val listener: VideoListener) : IosVideoPlayer {
    private val item = AVPlayerItem.playerItemWithURL(NSURL.fileURLWithPath(filePath))
    private val player = AVPlayer.playerWithPlayerItem(item)
    private val playerLayer = AVPlayerLayer.playerLayerWithPlayer(player).also { it.videoGravity = AVLayerVideoGravityResizeAspect }
    override val view: UIView = PlayerHostView(playerLayer)
    private var released = false
    private var userPaused = false
    private var finished = false
    private var playing = false
    private var timer: NSTimer? = null
    private val endObserver: Any

    init {
        endObserver = NSNotificationCenter.defaultCenter.addObserverForName(
            AVPlayerItemDidPlayToEndTimeNotification, item, NSOperationQueue.mainQueue,
        ) { _ ->
            if (!finished && !released) {
                finished = true
                listener.onCompleted()
            }
        }
        timer = NSTimer.scheduledTimerWithTimeInterval(0.25, repeats = true) { _ -> tick() }
    }

    private fun tick() {
        if (released || finished) return
        if (item.status == AVPlayerItemStatusFailed) {
            listener.onError("video playback failed")
            return
        }
        if (playing) listener.onPosition((CMTimeGetSeconds(player.currentTime()) * 1000).toLong())
    }

    override fun play() {
        if (released || finished) return
        if (userPaused) {
            userPaused = false
            listener.onResumed()
        }
        playing = true
        player.play()
    }

    override fun pause() {
        if (released || finished || !playing) return
        playing = false
        userPaused = true
        player.pause()
        listener.onPaused()
    }

    override fun setMuted(muted: Boolean) {
        if (released) return
        player.muted = muted
        listener.onMuteChanged(muted)
    }

    override fun release() {
        if (released) return
        released = true
        timer?.invalidate()
        timer = null
        NSNotificationCenter.defaultCenter.removeObserver(endObserver)
        player.pause()
        playerLayer.removeFromSuperlayer()
    }
}
