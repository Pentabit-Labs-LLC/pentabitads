package com.pentabitlabs.pentabitads.video

/**
 * Optional video support (VAST ads, played natively with Media3 on Android and AVPlayer on iOS).
 * Call [install] once, before `PentabitAds.initialize`. Without it, apps stay small and video ads
 * are reported as a load failure instead of being shown.
 */
public expect object PentabitAdsVideo {
    public fun install()
}
