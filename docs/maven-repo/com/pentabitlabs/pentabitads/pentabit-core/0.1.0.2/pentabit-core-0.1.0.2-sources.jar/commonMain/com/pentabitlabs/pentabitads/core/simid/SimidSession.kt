package com.pentabitlabs.pentabitads.core.simid

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/**
 * The player (host) side of SIMID for one video ad. The platform screen shows an iframe over the video, hands every message the iframe posts to
 * [onRaw] and delivers everything [send] emits to the iframe. All decisions live here, so Android and iOS behave the same and it can be tested.
 *
 * UNVERIFIED against SIMID 1.2 section 8 (messaging protocol) when written: the envelope {sessionId, messageId, type, timestamp, args}, the
 * createSession handshake (the creative creates the session and the player answers `resolve`), and the resolve/reject shape
 * (args = {messageId: <id answered>, value}) follow the author's recollection of the spec. The message names and their arguments
 * (Player:init, startCreative, adStopped, adSkipped, Creative:requestNavigation, clickThru, getMediaState, ...) come from the spec text
 * read for this work. Check the envelope against section 8 before relying on third-party SIMID creatives.
 *
 * Not implemented: SIMID:Media:* events, requestPause/Play/ChangeVolume/Fullscreen/Resize/ChangeAdDuration/expandNonlinear (all rejected,
 * because variableDurationAllowed and fullscreenAllowed are false).
 */
public class SimidSession(
    private val env: Environment,
    private val creativeData: CreativeData,
    private val now: () -> Long,
    private val send: (String) -> Unit,
    private val mediaState: () -> MediaState,
    private val listener: Listener,
) {
    public class Environment(
        public val appId: String,
        public val videoWidth: Int, public val videoHeight: Int,
        public val creativeX: Int, public val creativeY: Int, public val creativeWidth: Int, public val creativeHeight: Int,
        /** "playerHandles" when the player draws a skip control (a skipoffset exists), else "notSkippable". */
        public val skippableState: String,
        public val skipOffset: String?,
        public val version: String = "1.2",
    )

    public class CreativeData(public val adParameters: String, public val clickThruUrl: String?)

    public class MediaState(public val currentTimeSec: Double, public val durationSec: Double, public val ended: Boolean, public val paused: Boolean, public val muted: Boolean, public val volume: Double)

    public interface Listener {
        /** The creative asked the player to open [uri] after a user tap (SIMID:Creative:requestNavigation or clickThru with playerHandles). */
        public fun onNavigate(uri: String)
        /** The creative resolved startCreative: show the iframe now. */
        public fun onShow()
        /** The creative rejected init or startCreative, or sent a fatalError: remove the iframe; the video goes on. */
        public fun onFailed(reason: String)
        /** SIMID:Creative:reportTracking. */
        public fun onTrack(urls: List<String>)
    }

    private var sessionId: String? = null
    private var nextId = 1
    private val pending = HashMap<Int, String>()
    private var initResolved = false
    private var videoStarted = false
    private var startSent = false
    private var closed = false

    /** Call when the first video frame is on screen. */
    public fun mediaStarted() {
        videoStarted = true
        maybeStart()
    }

    /** The user skipped with the player's Skip control. */
    public fun adSkipped(): Unit = lifecycleMessage("SIMID:Player:adSkipped", buildJsonObject {})

    /** The ad ended for another reason. Codes: 1 user close, 2 media complete, 3 player closed before completion, 4 creative closed. */
    public fun adStopped(code: Int): Unit = lifecycleMessage("SIMID:Player:adStopped", buildJsonObject { put("code", code) })

    public fun appBackgrounded() { if (sessionId != null && !closed) request("SIMID:Player:appBackgrounded", buildJsonObject {}) }
    public fun appForegrounded() { if (sessionId != null && !closed) request("SIMID:Player:appForegrounded", buildJsonObject {}) }

    private fun lifecycleMessage(type: String, args: JsonObject) {
        if (closed || sessionId == null) return
        closed = true
        request(type, args)
    }

    public fun onRaw(raw: String) {
        val msg = try { Json.parseToJsonElement(raw).jsonObject } catch (e: Exception) { return }
        val type = msg["type"]?.jsonPrimitive?.contentOrNull ?: return
        val sid = msg["sessionId"]?.jsonPrimitive?.contentOrNull ?: return
        val args = (msg["args"] as? JsonObject) ?: buildJsonObject {}
        val id = msg["messageId"]?.jsonPrimitive?.intOrNull ?: return

        if (type == "createSession") {
            if (sessionId != null) return // one session per ad
            sessionId = sid
            reply(id, "resolve", buildJsonObject {})
            request("SIMID:Player:init", buildJsonObject {
                put("environmentData", environmentData())
                put("creativeData", buildJsonObject {
                    put("adParameters", creativeData.adParameters)
                    creativeData.clickThruUrl?.let { put("clickThruUrl", it) }
                })
            })
            return
        }
        if (sid != sessionId) return // another session or a stray message

        when (type) {
            "resolve", "reject" -> answer(type, args)
            "SIMID:Creative:requestNavigation" -> {
                val uri = args["uri"]?.jsonPrimitive?.contentOrNull
                if (uri.isNullOrBlank()) reply(id, "reject", reason(1100, "no uri")) else { reply(id, "resolve", buildJsonObject {}); listener.onNavigate(uri) }
            }
            "SIMID:Creative:clickThru" -> {
                val playerHandles = args["playerHandles"]?.jsonPrimitive?.booleanOrNull == true
                val url = args["url"]?.jsonPrimitive?.contentOrNull ?: creativeData.clickThruUrl
                reply(id, "resolve", buildJsonObject {})
                if (playerHandles && !url.isNullOrBlank()) listener.onNavigate(url)
            }
            "SIMID:Creative:getMediaState" -> {
                val m = mediaState()
                reply(id, "resolve", buildJsonObject {
                    put("currentTime", m.currentTimeSec); put("duration", m.durationSec); put("ended", m.ended)
                    put("muted", m.muted); put("paused", m.paused); put("volume", m.volume); put("fullscreen", true)
                })
            }
            "SIMID:Creative:reportTracking" -> {
                val urls = (args["trackingUrls"] as? JsonArray)?.mapNotNull { it.jsonPrimitive.contentOrNull }.orEmpty()
                reply(id, "resolve", buildJsonObject {})
                if (urls.isNotEmpty()) listener.onTrack(urls)
            }
            "SIMID:Creative:fatalError" -> { reply(id, "resolve", buildJsonObject {}); closed = true; listener.onFailed(args["errorMessage"]?.jsonPrimitive?.contentOrNull ?: "fatal error") }
            "SIMID:Creative:log" -> reply(id, "resolve", buildJsonObject {})
            // Everything that would change playback or layout is refused: this player does not allow it.
            "SIMID:Creative:requestSkip", "SIMID:Creative:requestStop", "SIMID:Creative:requestPause", "SIMID:Creative:requestPlay",
            "SIMID:Creative:requestChangeVolume", "SIMID:Creative:requestFullscreen", "SIMID:Creative:requestExitFullscreen",
            "SIMID:Creative:requestResize", "SIMID:Creative:requestChangeAdDuration", "SIMID:Creative:expandNonlinear",
            -> reply(id, "reject", reason(1101, "not supported by this player"))
            else -> reply(id, "reject", reason(1100, "unknown message"))
        }
    }

    private fun answer(kind: String, args: JsonObject) {
        val answered = args["messageId"]?.jsonPrimitive?.intOrNull ?: return
        val type = pending.remove(answered) ?: return
        val ok = kind == "resolve"
        when (type) {
            "SIMID:Player:init" -> if (ok) { initResolved = true; maybeStart() } else fail(args)
            "SIMID:Player:startCreative" -> if (ok) listener.onShow() else fail(args)
        }
    }

    private fun fail(args: JsonObject) {
        closed = true
        val value = args["value"] as? JsonObject
        listener.onFailed(value?.get("reason")?.jsonPrimitive?.contentOrNull ?: "the interactive creative could not start")
    }

    private fun maybeStart() {
        if (closed || startSent || !initResolved || !videoStarted) return
        startSent = true
        request("SIMID:Player:startCreative", buildJsonObject {})
    }

    private fun environmentData(): JsonObject = buildJsonObject {
        put("videoDimensions", rect(0, 0, env.videoWidth, env.videoHeight))
        put("creativeDimensions", rect(env.creativeX, env.creativeY, env.creativeWidth, env.creativeHeight))
        put("fullscreen", true)
        put("fullscreenAllowed", false)
        put("variableDurationAllowed", false)
        put("skippableState", env.skippableState)
        env.skipOffset?.let { put("skipoffset", it) }
        put("version", env.version)
        put("appId", env.appId)
        put("navigationSupport", "playerHandles")
        put("closeButtonSupport", "playerHandles")
        put("muted", false)
        put("volume", 1.0)
    }

    private fun rect(x: Int, y: Int, w: Int, h: Int) = buildJsonObject { put("x", x); put("y", y); put("width", w); put("height", h) }
    private fun reason(code: Int, text: String) = buildJsonObject { put("errorCode", code); put("reason", text) }

    private fun request(type: String, args: JsonObject) {
        val sid = sessionId ?: return
        val id = nextId++
        pending[id] = type
        send(envelope(sid, id, type, args))
    }

    private fun reply(to: Int, kind: String, value: JsonObject) {
        val sid = sessionId ?: return
        send(envelope(sid, nextId++, kind, buildJsonObject { put("messageId", to); put("value", value) }))
    }

    private fun envelope(sid: String, id: Int, type: String, args: JsonObject): String =
        buildJsonObject { put("sessionId", sid); put("messageId", id); put("type", type); put("timestamp", now()); put("args", args) }.toString()

    public companion object {
        /** The key the cached overlay page is served under to the host page (".html" so it is served as text/html). */
        public const val ASSET_KEY: String = "simid.html"

        /** Formats a skip offset in ms as HH:MM:SS.mmm (SIMID environmentData.skipoffset). */
        public fun clock(ms: Long): String {
            val t = ms.coerceAtLeast(0)
            fun p(n: Long, w: Int = 2) = n.toString().padStart(w, '0')
            return "${p(t / 3_600_000)}:${p(t / 60_000 % 60)}:${p(t / 1000 % 60)}.${p(t % 1000, 3)}"
        }
    }
}
