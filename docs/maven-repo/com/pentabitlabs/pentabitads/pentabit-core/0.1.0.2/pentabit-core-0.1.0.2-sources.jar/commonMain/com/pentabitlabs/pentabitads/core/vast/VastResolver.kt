package com.pentabitlabs.pentabitads.core.vast

import com.pentabitlabs.pentabitads.core.error.AdErrorCode
import com.pentabitlabs.pentabitads.core.error.AdResult
import com.pentabitlabs.pentabitads.core.error.failure
import com.pentabitlabs.pentabitads.core.net.PixelClient
import com.pentabitlabs.pentabitads.core.ports.HttpClientPort
import com.pentabitlabs.pentabitads.core.ports.HttpRequest
import com.pentabitlabs.pentabitads.core.ports.NetworkException
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.cancellation.CancellationException

/**
 * Follows a wrapper chain with a depth limit and an overall timeout, then returns one playable ad.
 * Impressions, errors and tracking from every wrapper are merged into the final ad.
 */
public class VastResolver(
    private val http: HttpClientPort,
    private val parser: VastParser,
    private val pixels: PixelClient,
    private val maxDepth: Int,
    private val timeoutMs: Long,
    private val maxBitrateKbps: Int,
) {
    public suspend fun resolve(xml: String?, url: String?): AdResult<ResolvedVast> {
        val result = withTimeoutOrNull(timeoutMs) { resolveInternal(xml, url) }
            ?: return failure(AdErrorCode.TIMEOUT, "VAST resolution timed out")
        return result
    }

    private suspend fun resolveInternal(initialXml: String?, initialUrl: String?): AdResult<ResolvedVast> {
        val impressions = ArrayList<String>()
        val errors = ArrayList<String>()
        val tracking = ArrayList<VastTracking>()
        val clickTracking = ArrayList<String>()

        var xml = initialXml ?: fetch(initialUrl ?: return failure(AdErrorCode.NO_FILL, "no VAST xml or url"))
            ?: return fail(errors, "301", "could not fetch VAST")
        var depth = 0
        while (true) {
            val ad = when (val parsed = parser.parse(xml)) {
                is AdResult.Failure -> return fail(errors, "100", parsed.error.message)
                is AdResult.Success -> parsed.value
            }
            impressions += ad.impressions
            errors += ad.errors
            ad.linear?.let { tracking += it.tracking; clickTracking += it.clickTracking }

            if (ad.isWrapper) {
                if (depth >= maxDepth) return fail(errors, "302", "wrapper depth limit reached")
                val next = ad.wrapperUrl ?: return fail(errors, "300", "wrapper without a target")
                xml = fetch(next) ?: return fail(errors, "301", "could not fetch wrapper")
                depth++
                continue
            }

            val linear = ad.linear ?: return fail(errors, "403", "no linear creative")
            val media = MediaSelector.pick(linear.mediaFiles, maxBitrateKbps)
                ?: return fail(errors, "403", "no playable media file")
            val duration = linear.durationMs ?: return fail(errors, "202", "missing duration")
            return AdResult.Success(
                ResolvedVast(
                    impressions = impressions,
                    errors = errors,
                    durationMs = duration,
                    skipOffsetMs = skipOffsetMs(linear.skipOffset, duration),
                    media = media,
                    tracking = tracking,
                    clickThrough = linear.clickThrough,
                    clickTracking = clickTracking,
                    companion = ad.companions.firstOrNull { it.resourceType == "html" || it.resourceType == "static" },
                    interactive = linear.interactive,
                ),
            )
        }
    }

    private suspend fun fetch(url: String): String? =
        try {
            val r = http.execute(HttpRequest(url = url, timeoutMillis = timeoutMs))
            if (r.status in 200..299) r.body else null
        } catch (e: CancellationException) {
            throw e
        } catch (e: NetworkException) {
            null
        }

    private fun fail(errors: List<String>, code: String, message: String): AdResult.Failure {
        pixels.fire(errors, mapOf("ERRORCODE" to code))
        return failure(AdErrorCode.NO_FILL, "VAST error $code: $message")
    }

    private fun skipOffsetMs(raw: String?, durationMs: Long): Long? {
        if (raw.isNullOrBlank()) return null
        return if (raw.endsWith("%")) {
            val pct = raw.removeSuffix("%").toDoubleOrNull() ?: return null
            (durationMs * pct / 100.0).toLong()
        } else {
            VastParser.parseTimeMs(raw)
        }
    }
}

public object MediaSelector {
    /** MP4 only in v1. Prefers the highest bitrate at or below the cap, else the lowest available. */
    public fun pick(files: List<VastMedia>, maxBitrateKbps: Int): VastMedia? {
        val mp4 = files.filter { it.mime.equals("video/mp4", ignoreCase = true) && !it.delivery.equals("streaming", ignoreCase = true) }
        if (mp4.isEmpty()) return null
        val within = mp4.filter { (it.bitrateKbps ?: 0) <= maxBitrateKbps }
        return if (within.isNotEmpty()) within.maxByOrNull { it.bitrateKbps ?: 0 } else mp4.minByOrNull { it.bitrateKbps ?: Int.MAX_VALUE }
    }
}
