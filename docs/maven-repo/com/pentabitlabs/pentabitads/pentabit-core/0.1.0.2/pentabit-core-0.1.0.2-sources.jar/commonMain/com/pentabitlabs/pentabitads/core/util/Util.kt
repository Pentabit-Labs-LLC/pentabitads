package com.pentabitlabs.pentabitads.core.util

import com.pentabitlabs.pentabitads.core.ports.Clock
import com.pentabitlabs.pentabitads.core.ports.IdGenerator
import kotlin.uuid.Uuid

public object SystemIds : IdGenerator {
    override fun newId(): String = Uuid.random().toString()
}

/** Percent-encodes everything except RFC 3986 unreserved characters. */
public fun percentEncode(value: String): String {
    val sb = StringBuilder()
    for (b in value.encodeToByteArray()) {
        val c = b.toInt() and 0xFF
        val ch = c.toChar()
        if (ch in 'a'..'z' || ch in 'A'..'Z' || ch in '0'..'9' || ch == '-' || ch == '_' || ch == '.' || ch == '~') {
            sb.append(ch)
        } else {
            sb.append('%')
            sb.append("0123456789ABCDEF"[c shr 4])
            sb.append("0123456789ABCDEF"[c and 0xF])
        }
    }
    return sb.toString()
}

public fun htmlEscape(value: String): String =
    value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;")

public fun Clock.elapsedSince(startMillis: Long): Long = nowMillis() - startMillis
