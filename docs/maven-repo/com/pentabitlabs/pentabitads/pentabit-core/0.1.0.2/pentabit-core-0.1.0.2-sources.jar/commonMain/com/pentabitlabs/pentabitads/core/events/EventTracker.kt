package com.pentabitlabs.pentabitads.core.events

import com.pentabitlabs.pentabitads.core.net.PentabitJson
import com.pentabitlabs.pentabitads.core.ports.Clock
import com.pentabitlabs.pentabitads.core.ports.EventStore
import com.pentabitlabs.pentabitads.core.ports.IdGenerator
import com.pentabitlabs.pentabitads.core.ports.Logger
import com.pentabitlabs.pentabitads.core.ports.StoredEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlin.coroutines.cancellation.CancellationException

/**
 * Single entry point for events. It never blocks the caller: the event is written to the durable
 * queue on a background coroutine, then flushed in a batch (or at once for important events).
 */
public class EventTracker(
    private val store: EventStore,
    private val clock: Clock,
    private val ids: IdGenerator,
    private val scope: CoroutineScope,
    private val logger: Logger,
) {
    private var flusher: EventFlusher? = null

    public fun attach(flusher: EventFlusher) {
        this.flusher = flusher
    }

    public fun track(
        name: String,
        requestId: String? = null,
        placementId: String? = null,
        params: Map<String, String> = emptyMap(),
        value: Double? = null,
        currency: String? = null,
    ) {
        val event = PentabitEvent(
            id = ids.newId(),
            name = name,
            timestamp = clock.nowMillis(),
            requestId = requestId,
            placementId = placementId,
            params = params,
            value = value,
            currency = currency,
        )
        scope.launch {
            try {
                store.insert(listOf(StoredEvent(event.id, event.timestamp, PentabitJson.encodeToString(event))))
                if (name in EventNames.IMMEDIATE) flusher?.flushNow()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                logger.warn("PentabitEvents", "could not store event $name", e)
            }
        }
    }
}
