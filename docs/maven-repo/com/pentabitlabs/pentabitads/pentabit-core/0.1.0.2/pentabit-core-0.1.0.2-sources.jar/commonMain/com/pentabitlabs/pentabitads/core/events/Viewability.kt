package com.pentabitlabs.pentabitads.core.events

/**
 * Counts an impression once, when at least [minAreaPercent] of the ad has been visible for
 * [minDurationMs] without a break. The defaults live in SdkDefaults.
 */
public class ViewabilityTracker(
    private val minAreaPercent: Int,
    private val minDurationMs: Long,
) {
    private var visibleSince: Long = -1
    public var isCounted: Boolean = false
        private set

    /** Feed exposure readings. Returns true exactly once, when the rule is first met. */
    public fun onExposure(percent: Double, nowMillis: Long): Boolean {
        if (isCounted) return false
        if (percent >= minAreaPercent) {
            if (visibleSince < 0) visibleSince = nowMillis
            if (nowMillis - visibleSince >= minDurationMs) {
                isCounted = true
                return true
            }
        } else {
            visibleSince = -1
        }
        return false
    }

    /** True while the ad is above the area threshold but the time has not elapsed yet. */
    public fun isPending(): Boolean = visibleSince >= 0 && !isCounted

    public fun millisUntilCounted(nowMillis: Long): Long =
        if (visibleSince < 0 || isCounted) -1 else (minDurationMs - (nowMillis - visibleSince)).coerceAtLeast(0)
}
