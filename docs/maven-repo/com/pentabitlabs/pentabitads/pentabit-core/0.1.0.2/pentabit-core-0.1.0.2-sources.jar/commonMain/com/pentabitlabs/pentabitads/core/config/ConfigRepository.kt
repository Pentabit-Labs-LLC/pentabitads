package com.pentabitlabs.pentabitads.core.config

import com.pentabitlabs.pentabitads.core.error.AdErrorCode
import com.pentabitlabs.pentabitads.core.error.AdResult
import com.pentabitlabs.pentabitads.core.error.failure
import com.pentabitlabs.pentabitads.core.error.guard
import com.pentabitlabs.pentabitads.core.net.ApiClient
import com.pentabitlabs.pentabitads.core.net.PentabitJson
import com.pentabitlabs.pentabitads.core.ports.Clock
import com.pentabitlabs.pentabitads.core.ports.KeyValueStore
import com.pentabitlabs.pentabitads.core.ports.Logger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.SerializationException
import kotlinx.serialization.encodeToString

public object ConfigParser {
    public fun parse(text: String): AdResult<SdkConfig> =
        try {
            validate(PentabitJson.decodeFromString<SdkConfig>(text))
        } catch (e: SerializationException) {
            failure(AdErrorCode.INTERNAL, "config is not valid JSON: ${e.message}")
        } catch (e: IllegalArgumentException) {
            failure(AdErrorCode.INTERNAL, "config is not valid: ${e.message}")
        }

    public fun validate(config: SdkConfig): AdResult<SdkConfig> {
        fun bad(msg: String) = failure(AdErrorCode.INTERNAL, "invalid config: $msg")
        if (config.version < 0) return bad("negative version")
        if (config.refreshIntervalSeconds < 60) return bad("refreshIntervalSeconds below 60")
        val ids = HashSet<String>()
        for (p in config.placements) {
            if (p.id.isBlank()) return bad("blank placement id")
            if (!ids.add(p.id)) return bad("duplicate placement id ${p.id}")
        }
        if (config.events.batchSize !in 1..200) return bad("event batch size")
        if (config.events.flushIntervalSeconds < 5) return bad("event flush interval below 5")
        return AdResult.Success(config)
    }
}

/**
 * Holds the current config. The last good config is kept on disk, so the SDK works offline.
 * An invalid config is rejected and the previous one stays.
 */
public class ConfigRepository(
    private val api: ApiClient,
    private val store: KeyValueStore,
    private val clock: Clock,
    private val logger: Logger,
) {
    private val _current = MutableStateFlow(SdkConfig.SAFE_DEFAULT)
    public val current: StateFlow<SdkConfig> get() = _current

    private val _unauthorized = MutableStateFlow(false)

    /** True while the backend rejects this app key for this app. No ads are shown and no actions are sent. */
    public val unauthorized: StateFlow<Boolean> get() = _unauthorized

    /** Called on HTTP 401/403 from any ad or config call: forget the config so nothing can load. */
    public suspend fun markUnauthorized() {
        _unauthorized.value = true
        _current.value = SdkConfig.SAFE_DEFAULT
        store.remove(KEY)
    }

    private val mutex = Mutex()
    private var lastFetchMillis: Long = 0

    public suspend fun loadCached() {
        val text = store.getString(KEY) ?: return
        val parsed = ConfigParser.parse(text)
        if (parsed is AdResult.Success) {
            _current.value = parsed.value
        } else {
            logger.warn(TAG, "cached config rejected, removing it")
            store.remove(KEY)
        }
    }

    /** Fetches a new config unless one was fetched recently. */
    public suspend fun refresh(force: Boolean = false): AdResult<SdkConfig> = guard {
        mutex.withLock {
            val cfg = _current.value
            val age = clock.nowMillis() - lastFetchMillis
            if (!force && lastFetchMillis != 0L && age < cfg.refreshIntervalSeconds * 1_000L) {
                return@withLock AdResult.Success(cfg)
            }
            val response = when (val r = api.get("/v1/config", timeoutMs = 8_000, retryable = true)) {
                is AdResult.Failure -> return@withLock r
                is AdResult.Success -> r.value
            }
            if (response.status == 401 || response.status == 403) {
                markUnauthorized()
                return@withLock failure(AdErrorCode.APP_NOT_AUTHORIZED, "the backend rejected this app key for this app")
            }
            if (response.status !in 200..299) {
                return@withLock failure(AdErrorCode.NETWORK, "config HTTP ${response.status}")
            }
            lastFetchMillis = clock.nowMillis()
            when (val parsed = ConfigParser.parse(response.body)) {
                is AdResult.Failure -> {
                    logger.warn(TAG, parsed.error.message)
                    parsed
                }
                is AdResult.Success -> {
                    _current.value = parsed.value
                    _unauthorized.value = false
                    store.putString(KEY, PentabitJson.encodeToString(parsed.value))
                    parsed
                }
            }
        }
    }

    public fun findPlacement(id: String): AdResult<PlacementConfig> {
        if (_unauthorized.value) return failure(AdErrorCode.APP_NOT_AUTHORIZED, "the backend rejected this app key for this app")
        val cfg = _current.value
        if (cfg.killSwitch) return failure(AdErrorCode.KILL_SWITCH, "kill switch is on")
        val p = cfg.placements.firstOrNull { it.id == id }
            ?: return failure(AdErrorCode.PLACEMENT_NOT_FOUND, "placement $id is not in config")
        if (!p.enabled) return failure(AdErrorCode.PLACEMENT_DISABLED, "placement $id is disabled")
        return AdResult.Success(p)
    }

    private companion object {
        const val KEY = "aks.config.v1"
        const val TAG = "PentabitConfig"
    }
}
