package com.pentabitlabs.pentabitads.core.mraid

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.boolean
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

public enum class MraidPlacement(public val wire: String) { INLINE("inline"), INTERSTITIAL("interstitial") }

public enum class MraidState(public val wire: String) { LOADING("loading"), DEFAULT("default"), HIDDEN("hidden") }

/** Messages the creative can send to the host. */
public sealed interface MraidMessage {
    public data class Open(val url: String) : MraidMessage
    public data object Close : MraidMessage
    public data object Unload : MraidMessage
    public data class Orientation(val allowChange: Boolean, val force: String) : MraidMessage
    public data object PlayableReady : MraidMessage
    public data object PlayableComplete : MraidMessage
    public data object PlayableCta : MraidMessage
    public data class PlayableError(val message: String) : MraidMessage
}

public interface MraidListener {
    public fun onOpen(url: String)
    public fun onClose()
    public fun onPlayableReady()
    public fun onPlayableComplete()
    public fun onPlayableCta()
    public fun onCreativeError(message: String)
    public fun onOrientation(allowChange: Boolean, force: String)
}

/** Only these schemes may be opened from a creative. Everything else is ignored. */
public object UrlPolicy {
    private val allowed = setOf("http", "https", "market", "itms-apps", "itms-appss", "itms")

    public fun isAllowedOpenUrl(url: String): Boolean {
        val i = url.indexOf(':')
        if (i <= 0) return false
        return url.substring(0, i).lowercase() in allowed
    }
}

/**
 * The MRAID state machine and message handling, shared by Android and iOS. The platform only
 * injects the script, forwards raw messages here and runs the scripts this class returns.
 */
public class MraidController(
    private val placement: MraidPlacement,
    private val listener: MraidListener,
) {
    public var state: MraidState = MraidState.LOADING
        private set
    private var completedOnce = false
    private var readyReported = false

    public fun handleRaw(raw: String): MraidMessage? {
        val msg = parse(raw) ?: return null
        handle(msg)
        return msg
    }

    public fun handle(msg: MraidMessage) {
        when (msg) {
            is MraidMessage.Open -> if (state == MraidState.DEFAULT && UrlPolicy.isAllowedOpenUrl(msg.url)) listener.onOpen(msg.url)
            MraidMessage.Close, MraidMessage.Unload -> if (state == MraidState.DEFAULT) {
                state = MraidState.HIDDEN
                listener.onClose()
            }
            is MraidMessage.Orientation -> listener.onOrientation(msg.allowChange, msg.force)
            MraidMessage.PlayableReady -> if (!readyReported) { readyReported = true; listener.onPlayableReady() }
            MraidMessage.PlayableComplete -> if (!completedOnce) { completedOnce = true; listener.onPlayableComplete() }
            MraidMessage.PlayableCta -> if (state == MraidState.DEFAULT) listener.onPlayableCta()
            is MraidMessage.PlayableError -> listener.onCreativeError(msg.message)
        }
    }

    /** Scripts to run once the page has loaded. Moves the state from loading to default. */
    public fun readyScripts(maxWidth: Int, maxHeight: Int, screenWidth: Int, screenHeight: Int): List<String> {
        if (state != MraidState.LOADING) return emptyList()
        state = MraidState.DEFAULT
        return listOf(
            "window.__aks.init('${placement.wire}', $maxWidth, $maxHeight, $screenWidth, $screenHeight);",
            "window.__aks.ready();",
        )
    }

    public fun viewableScript(viewable: Boolean): String = "window.__aks.setViewable($viewable);"

    public fun exposureScript(percent: Double): String = "window.__aks.setExposure(${percent.coerceIn(0.0, 100.0)});"

    public fun hiddenScript(): String = "window.__aks.setState('hidden');"

    public companion object {
        private val json = Json { ignoreUnknownKeys = true }

        public fun parse(raw: String): MraidMessage? {
            if (raw.length > 4_096) return null
            val obj: JsonObject = try {
                json.parseToJsonElement(raw).jsonObject
            } catch (e: Exception) {
                return null
            }
            val cmd = obj["cmd"]?.jsonPrimitive?.contentOrNull ?: return null
            return when (cmd) {
                "open" -> obj["url"]?.jsonPrimitive?.contentOrNull?.let { MraidMessage.Open(it) }
                "close" -> MraidMessage.Close
                "unload" -> MraidMessage.Unload
                "orientation" -> MraidMessage.Orientation(
                    allowChange = obj["allow"]?.jsonPrimitive?.booleanOrNull ?: true,
                    force = obj["force"]?.jsonPrimitive?.contentOrNull ?: "none",
                )
                "aks.ready" -> MraidMessage.PlayableReady
                "aks.complete" -> MraidMessage.PlayableComplete
                "aks.cta" -> MraidMessage.PlayableCta
                "aks.error" -> MraidMessage.PlayableError(obj["msg"]?.jsonPrimitive?.contentOrNull.orEmpty().take(200))
                else -> null
            }
        }
    }
}
