package com.pentabitlabs.pentabitads.core.simid

/**
 * The page the platform WebView loads over a video: a transparent document with one sandboxed iframe holding the SIMID creative.
 * Messages the creative posts are passed to the platform as "simid:" + the raw JSON (through the same AksNative / webkit "aks" bridge the
 * MRAID pages use), and the platform sends player messages back by running [deliver].
 */
public object SimidHost {
    public const val PREFIX: String = "simid:"

    /** [iframeSrc] is the cached overlay page served from the asset host. The sandbox gives the creative an opaque origin (cross-origin, as SIMID requires). */
    public fun page(iframeSrc: String): String = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
<style>html,body{margin:0;height:100%;background:transparent;overflow:hidden}iframe{border:0;width:100%;height:100%;background:transparent}</style></head>
<body><iframe id="c" sandbox="allow-scripts" src="${iframeSrc.replace("\"", "&quot;")}"></iframe><script>
(function(){
  var f = document.getElementById("c");
  function post(s){
    if (window.AksNative && window.AksNative.post) { window.AksNative.post(s); }
    else if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.aks) { window.webkit.messageHandlers.aks.postMessage(s); }
  }
  window.addEventListener("message", function(e){ if (e.source === f.contentWindow && typeof e.data === "string") post("$PREFIX" + e.data); });
  window.aksSimidSend = function(s){ if (f.contentWindow) f.contentWindow.postMessage(s, "*"); };
})();
</script></body></html>"""

    /** JavaScript that delivers [json] to the creative. */
    public fun deliver(json: String): String = "window.aksSimidSend(" + quote(json) + ");"

    private fun quote(s: String): String {
        val b = StringBuilder("\"")
        for (c in s) when (c) {
            '\\' -> b.append("\\\\"); '"' -> b.append("\\\""); '\n' -> b.append("\\n"); '\r' -> b.append("\\r")
            ' ' -> b.append("\\u2028"); ' ' -> b.append("\\u2029"); '<' -> b.append("\\u003c")
            else -> b.append(c)
        }
        return b.append('"').toString()
    }
}
