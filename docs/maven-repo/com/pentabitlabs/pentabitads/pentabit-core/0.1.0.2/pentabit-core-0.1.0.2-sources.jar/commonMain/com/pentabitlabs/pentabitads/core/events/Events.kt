package com.pentabitlabs.pentabitads.core.events

import com.pentabitlabs.pentabitads.core.model.AppInfo
import com.pentabitlabs.pentabitads.core.model.DeviceContext
import com.pentabitlabs.pentabitads.core.model.PrivacyContext
import com.pentabitlabs.pentabitads.core.model.SdkInfo
import kotlinx.serialization.Serializable

/** Standard event names used by both SDKs. */
public object EventNames {
    public const val IMPRESSION: String = "impression"
    public const val VIEWABLE_IMPRESSION: String = "viewable_impression"
    public const val CLICK: String = "click"
    public const val VIDEO_START: String = "video_start"
    public const val VIDEO_Q1: String = "video_q1"
    public const val VIDEO_MID: String = "video_mid"
    public const val VIDEO_Q3: String = "video_q3"
    public const val VIDEO_COMPLETE: String = "video_complete"
    public const val SKIP: String = "skip"
    public const val CLOSE: String = "close"
    public const val REWARD_EARNED: String = "reward_earned"
    public const val PLAYABLE_COMPLETE: String = "playable_complete"
    public const val END_CARD_SHOWN: String = "end_card_shown"
    public const val ERROR: String = "error"

    // Pentabit Analytics
    public const val FIRST_OPEN: String = "first_open"
    public const val REGISTRATION: String = "registration"
    public const val TUTORIAL_COMPLETE: String = "tutorial_complete"
    public const val LEVEL_REACHED: String = "level_reached"
    public const val FEATURE_USED: String = "feature_used"
    public const val PURCHASE: String = "purchase"
    public const val SUBSCRIBE: String = "subscribe"
    public const val DEEP_LINK_OPEN: String = "deep_link_open"

    /** Events sent at once instead of waiting for the next batch. */
    public val IMMEDIATE: Set<String> = setOf(CLICK, REWARD_EARNED, FIRST_OPEN, PURCHASE, SUBSCRIBE)
}

@Serializable
public data class PentabitEvent(
    val id: String,
    val name: String,
    val timestamp: Long,
    val requestId: String? = null,
    val placementId: String? = null,
    val params: Map<String, String> = emptyMap(),
    val value: Double? = null,
    val currency: String? = null,
)

@Serializable
public data class EventContext(
    val app: AppInfo,
    val device: DeviceContext,
    val privacy: PrivacyContext,
    val sdk: SdkInfo,
    /** Random per-process ID. Used instead of a persistent ID when the privacy mode forbids one. */
    val sessionId: String,
    /** Device clock minus last seen server time, when known. */
    val clockOffsetMs: Long? = null,
    /** True for debug builds: the backend must keep this traffic out of live reporting and billing. */
    val testMode: Boolean = false,
)


/**
 * Everything common to a batch goes in headers, so the body is only the list of events.
 * Empty values are left out. The advertising ID, instance ID and user ID are present only when
 * the privacy mode allowed them (the context already holds null otherwise).
 */
public fun EventContext.toHeaders(): Map<String, String> {
    val h = LinkedHashMap<String, String>()
    fun put(name: String, value: Any?) { if (value != null && value.toString().isNotEmpty()) h["X-Aks-$name"] = value.toString() }
    put("App-Id", app.id); put("App-Version", app.version)
    put("Platform", device.platform); put("Os-Version", device.osVersion); put("Device-Class", device.deviceClass)
    put("Country", device.country); put("Language", device.language)
    put("Ad-Id", device.advertisingId); put("Instance-Id", device.appInstanceId); put("Device-Id", device.deviceId); put("Session-Id", sessionId)
    put("Privacy-Mode", privacy.mode); put("Tcf", privacy.tcfString); put("Gpp", privacy.gppString)
    put("Under-Age", privacy.underAge); put("Us-Opt-Out", privacy.usOptOut); put("User-Id", privacy.userId)
    if (testMode) h["X-Aks-Test"] = "1"
    return h
}
