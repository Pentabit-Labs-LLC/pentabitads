package com.pentabitlabs.pentabitads.core.events

import com.pentabitlabs.pentabitads.core.net.RetryPolicy
import com.pentabitlabs.pentabitads.core.SdkDefaults
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.cancellation.CancellationException
import kotlin.random.Random

/** Runs the flush timer, with backoff after failures. Only one flush runs at a time. */
public class EventFlusher(
    private val uploader: EventUploader,
    private val scope: CoroutineScope,
    private val flushIntervalSeconds: () -> Int = { SdkDefaults.EVENT_FLUSH_SECONDS },
    private val retry: RetryPolicy = RetryPolicy(maxAttempts = 6, baseDelayMs = 5_000, maxDelayMs = 300_000),
) {
    private val mutex = Mutex()
    private var timer: Job? = null
    private var failures = 0

    public fun start() {
        if (timer?.isActive == true) return
        timer = scope.launch {
            while (isActive) {
                val interval = flushIntervalSeconds() * 1_000L
                val wait = if (failures == 0) interval else retry.delayMillis(failures - 1, Random.nextDouble())
                delay(wait)
                flushNow()
            }
        }
    }

    public fun stop() {
        timer?.cancel()
        timer = null
    }

    public fun flushNow() {
        scope.launch { flushInternal() }
    }

    /** Call when the app goes to the background so queued events are sent before the process may stop. */
    public suspend fun flushAndWait(): FlushOutcome = flushInternal()

    private suspend fun flushInternal(): FlushOutcome =
        mutex.withLock {
            try {
                val outcome = uploader.flushOnce()
                failures = if (outcome == FlushOutcome.RETRY_LATER) failures + 1 else 0
                outcome
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                failures++
                FlushOutcome.RETRY_LATER
            }
        }
}
