package com.pentabitlabs.pentabitads.core.mraid

import com.pentabitlabs.pentabitads.core.util.htmlEscape

/** Builds the HTML the WebView loads. Creatives must be self-contained, so the CSP blocks everything else. */
public object CreativeHtml {
    /** Host used for locally served assets. The platform intercepts requests to it. */
    public const val ASSET_HOST: String = "aks-assets.invalid"

    private fun csp(assetOrigins: String): String =
        "default-src 'none'; script-src 'unsafe-inline' $assetOrigins; style-src 'unsafe-inline' $assetOrigins; " +
            "img-src data: blob: $assetOrigins; media-src data: blob: $assetOrigins; font-src data: $assetOrigins"

    /**
     * Injects the MRAID script, a viewport tag and the content security policy into [markup].
     * [assetOrigins] lists the origins serving cached assets, for example
     * `https://aks-assets.invalid aks-asset://aks-assets.invalid`.
     */
    public fun prepare(markup: String, assetOrigins: String): String {
        val head = "<meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\">" +
            "<meta http-equiv=\"Content-Security-Policy\" content=\"${csp(assetOrigins)}\">" +
            "<script>${MraidScript.JS}</script>"
        val lower = markup.lowercase()
        val headIdx = lower.indexOf("<head")
        if (headIdx >= 0) {
            val close = markup.indexOf('>', headIdx)
            if (close >= 0) return markup.substring(0, close + 1) + head + markup.substring(close + 1)
        }
        val htmlIdx = lower.indexOf("<html")
        if (htmlIdx >= 0) {
            val close = markup.indexOf('>', htmlIdx)
            if (close >= 0) return markup.substring(0, close + 1) + "<head>" + head + "</head>" + markup.substring(close + 1)
        }
        return "<!DOCTYPE html><html><head>$head</head><body style=\"margin:0\">$markup</body></html>"
    }

    private val assetMacro = Regex("\\[AKS_ASSET:([A-Za-z0-9._-]+)]")

    /** Replaces `[AKS_ASSET:key]` in creative markup with the URL the platform serves that cached asset from. */
    public fun expandAssets(markup: String, assetBase: String): String =
        assetMacro.replace(markup) { assetBase + it.groupValues[1] }

    /** The page the (i) button opens. Opening it is not a click on the ad. */
    public const val PRIVACY_URL: String = "https://pentabitapps.com/privacy-policy/"

    /**
     * A static image creative becomes a tiny HTML page, so every creative uses the same MRAID path. The page carries the (i) button:
     * small in the top-right corner of a banner ([compact]), bottom-left on a full-screen ad. A tap opens [PRIVACY_URL] and not the store.
     */
    public fun staticImagePage(imageUrl: String, clickUrl: String?, compact: Boolean = false): String {
        val click = if (clickUrl != null) " data-click=\"${htmlEscape(clickUrl)}\" onclick=\"mraid.open(this.getAttribute('data-click'))\"" else ""
        val size = if (compact) 13 else 20
        val pos = if (compact) "top:2px;right:2px" else "bottom:14px;left:14px"
        val info = "<div title=\"About this ad\" onclick=\"event.stopPropagation();mraid.open('$PRIVACY_URL')\" style=\"position:fixed;$pos;width:${size}px;height:${size}px;" +
            "border-radius:50%;box-sizing:border-box;border:1.5px solid rgba(255,255,255,.85);color:#fff;background:rgba(0,0,0,.4);" +
            "font:italic 700 ${size * 62 / 100}px/${size - 3}px Georgia,serif;text-align:center;z-index:5\">i</div>"
        return "<!DOCTYPE html><html><head><style>html,body{margin:0;height:100%;background:#000}" +
            "body{display:flex;align-items:center;justify-content:center}" +
            "img{max-width:100%;max-height:100%;object-fit:contain}</style></head>" +
            "<body><img src=\"${htmlEscape(imageUrl)}\"$click>$info</body></html>"
    }
}
