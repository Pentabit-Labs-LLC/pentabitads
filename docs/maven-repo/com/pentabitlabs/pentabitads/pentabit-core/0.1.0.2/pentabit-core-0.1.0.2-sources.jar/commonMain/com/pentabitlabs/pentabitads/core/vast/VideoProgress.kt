package com.pentabitlabs.pentabitads.core.vast

import com.pentabitlabs.pentabitads.core.events.EventNames

/** Names of VAST tracking events the player reports. */
public object VastEvents {
    public const val START: String = "start"
    public const val FIRST_QUARTILE: String = "firstQuartile"
    public const val MIDPOINT: String = "midpoint"
    public const val THIRD_QUARTILE: String = "thirdQuartile"
    public const val COMPLETE: String = "complete"
    public const val SKIP: String = "skip"
    public const val PAUSE: String = "pause"
    public const val RESUME: String = "resume"
    public const val MUTE: String = "mute"
    public const val UNMUTE: String = "unmute"
    public const val CLOSE: String = "close"
    public const val CREATIVE_VIEW: String = "creativeView"

    /** The Pentabit event that matches a VAST event, if any. */
    public fun toPentabitEvent(vastEvent: String): String? = when (vastEvent) {
        START -> EventNames.VIDEO_START
        FIRST_QUARTILE -> EventNames.VIDEO_Q1
        MIDPOINT -> EventNames.VIDEO_MID
        THIRD_QUARTILE -> EventNames.VIDEO_Q3
        COMPLETE -> EventNames.VIDEO_COMPLETE
        SKIP -> EventNames.SKIP
        else -> null
    }
}

/**
 * Turns real playback position into quartile events. Each milestone fires once. Pausing or
 * seeking back never fires a milestone twice, and seeking past one fires it at the next update.
 */
public class VideoProgressTracker(
    private val durationMs: Long,
    private val emit: (String) -> Unit,
) {
    private var started = false
    private var q1 = false
    private var mid = false
    private var q3 = false
    private var completed = false

    public fun onPosition(positionMs: Long) {
        if (durationMs <= 0 || completed) return
        if (!started && positionMs > 0) { started = true; emit(VastEvents.START) }
        val p = positionMs * 100.0 / durationMs
        if (!q1 && p >= 25.0) { q1 = true; emit(VastEvents.FIRST_QUARTILE) }
        if (!mid && p >= 50.0) { mid = true; emit(VastEvents.MIDPOINT) }
        if (!q3 && p >= 75.0) { q3 = true; emit(VastEvents.THIRD_QUARTILE) }
    }

    public fun onCompleted() {
        if (completed) return
        onPosition(durationMs)
        completed = true
        emit(VastEvents.COMPLETE)
    }

    public val isCompleted: Boolean get() = completed
}
