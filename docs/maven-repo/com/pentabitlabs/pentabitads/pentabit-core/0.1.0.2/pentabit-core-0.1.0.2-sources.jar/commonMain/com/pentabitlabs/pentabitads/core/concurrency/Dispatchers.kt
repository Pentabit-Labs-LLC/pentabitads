package com.pentabitlabs.pentabitads.core.concurrency

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

/** `Dispatchers.IO` is not visible from common code on iOS, so each platform supplies it. */
internal expect fun ioDispatcher(): CoroutineDispatcher

/** All dispatchers come from here so tests can replace them with one test dispatcher. */
public interface DispatcherProvider {
    public val main: CoroutineDispatcher
    public val default: CoroutineDispatcher
    public val io: CoroutineDispatcher
}

public class DefaultDispatcherProvider : DispatcherProvider {
    override val main: CoroutineDispatcher get() = Dispatchers.Main
    override val default: CoroutineDispatcher get() = Dispatchers.Default
    override val io: CoroutineDispatcher get() = ioDispatcher()
}

/** One scope for the whole SDK. A failing child never cancels its siblings. */
public class SdkScope(
    dispatchers: DispatcherProvider,
    onUncaught: (Throwable) -> Unit,
) {
    private val root = SupervisorJob()
    public val scope: CoroutineScope = CoroutineScope(
        root + dispatchers.default + CoroutineExceptionHandler { _, t -> onUncaught(t) },
    )

    /** A scope for one ad. Cancelling it never affects the SDK scope. */
    public fun child(): CoroutineScope =
        CoroutineScope(scope.coroutineContext + Job(root))

    public fun shutdown() {
        scope.cancel()
    }
}
