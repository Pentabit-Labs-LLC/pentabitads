package com.pentabitlabs.pentabitads.core.ports

import com.pentabitlabs.pentabitads.core.concurrency.DispatcherProvider
import com.pentabitlabs.pentabitads.core.error.AdResult

public interface Clock {
    public fun nowMillis(): Long
}

public interface IdGenerator {
    public fun newId(): String
}

public interface Logger {
    public fun debug(tag: String, message: String)
    public fun warn(tag: String, message: String, error: Throwable? = null)
    public fun error(tag: String, message: String, error: Throwable? = null)
}

public object NoopLogger : Logger {
    override fun debug(tag: String, message: String) {}
    override fun warn(tag: String, message: String, error: Throwable?) {}
    override fun error(tag: String, message: String, error: Throwable?) {}
}

public interface KeyValueStore {
    public suspend fun getString(key: String): String?
    public suspend fun putString(key: String, value: String)
    public suspend fun remove(key: String)
}

public data class HttpRequest(
    val url: String,
    val method: String = "GET",
    val headers: Map<String, String> = emptyMap(),
    val body: String? = null,
    val timeoutMillis: Long = 10_000,
)

public data class HttpResponse(
    val status: Int,
    val headers: Map<String, String>,
    val body: String,
)

public class NetworkException(public val kind: Kind, message: String) : Exception(message) {
    public enum class Kind { TIMEOUT, NO_CONNECTION, OTHER }
}

public interface HttpClientPort {
    /** Throws [NetworkException] for transport failures; any HTTP status is returned as a response. */
    public suspend fun execute(request: HttpRequest): HttpResponse
}

public interface ConnectivityMonitor {
    public fun isOnline(): Boolean
}

public interface DeviceInfo {
    public val platform: String          // "android" or "ios"
    public val osVersion: String
    public val deviceClass: String       // "phone" or "tablet"
    public val appId: String
    public val appVersion: String
    public val country: String?
    public val language: String?
    public val isLowPowerMode: Boolean

    /** The advertising ID, or null when unavailable, denied or zeroed. Callers must check the privacy mode first. */
    public suspend fun advertisingId(): String?

    /**
     * A device-level ID: Android's ANDROID_ID, iOS's identifierForVendor. Null when unavailable. Callers must check the privacy mode
     * first, and send it only in NORMAL mode.
     */
    public suspend fun deviceId(): String?

    /** A random per-install ID kept in app-private storage. */
    public suspend fun appInstanceId(): String
}

public data class StoredEvent(
    val id: String,
    val createdAtMillis: Long,
    val payload: String,
)

public interface EventStore {
    public suspend fun insert(events: List<StoredEvent>)
    public suspend fun readBatch(limit: Int): List<StoredEvent>
    public suspend fun delete(ids: List<String>)
    public suspend fun count(): Long
    public suspend fun deleteOlderThan(timestampMillis: Long): Int
    /** Keeps only the newest [maxCount] events. Returns how many were removed. */
    public suspend fun trimTo(maxCount: Int): Int
}

public data class CachedAsset(
    val key: String,
    val path: String,
    val sizeBytes: Long,
)

public interface AssetStore {
    public suspend fun download(url: String, key: String, maxBytes: Long, sha256: String? = null): AdResult<CachedAsset>
    public suspend fun get(key: String): CachedAsset?
    public suspend fun release(key: String)
    public suspend fun trimTo(maxBytes: Long)
}

/** Everything the platform layer provides. Core never imports a platform class. */
public interface PlatformModule {
    public val clock: Clock
    public val ids: IdGenerator
    public val logger: Logger
    public val http: HttpClientPort
    public val keyValueStore: KeyValueStore
    public val eventStore: EventStore
    public val assetStore: AssetStore
    public val connectivity: ConnectivityMonitor
    public val deviceInfo: DeviceInfo
    public val dispatchers: DispatcherProvider
}
