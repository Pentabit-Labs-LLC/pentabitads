package com.pentabitlabs.pentabitads.core

import com.pentabitlabs.pentabitads.core.concurrency.SdkScope
import com.pentabitlabs.pentabitads.core.config.ConfigRepository
import com.pentabitlabs.pentabitads.core.events.EventContext
import com.pentabitlabs.pentabitads.core.events.EventFlusher
import com.pentabitlabs.pentabitads.core.events.EventTracker
import com.pentabitlabs.pentabitads.core.events.EventUploader
import com.pentabitlabs.pentabitads.core.model.AppInfo
import com.pentabitlabs.pentabitads.core.model.DeviceContext
import com.pentabitlabs.pentabitads.core.model.PrivacyContext
import com.pentabitlabs.pentabitads.core.model.SdkInfo
import com.pentabitlabs.pentabitads.core.net.ApiClient
import com.pentabitlabs.pentabitads.core.net.PixelClient
import com.pentabitlabs.pentabitads.core.ports.PlatformModule
import com.pentabitlabs.pentabitads.core.privacy.AudienceProfile
import com.pentabitlabs.pentabitads.core.privacy.PrivacyState
import com.pentabitlabs.pentabitads.core.privacy.TriState
import kotlinx.coroutines.launch

public object PentabitEndpoints {
    /**
     * Release builds talk to production. Set this to true only to test against staging; the
     * release script refuses to publish while it is true. Apps never set any of these.
     */
    private const val USE_STAGING: Boolean = false

    /** Ads backend: app config and ad requests. */
    public val BASE_URL: String = if (USE_STAGING) "https://api.lcl-portal.appskitsdk.com" else "https://pa-api.appskitsdk.com"

    /** Reporting backend: ad events (impressions, clicks) and in-app actions (installs, purchases). */
    public val REPORT_URL: String = if (USE_STAGING) "https://api.lcl-portal.appskitsdk.com" else "https://pa-rpt.appskitsdk.com"
}

public data class CoreOptions(
    val appKey: String,
    val baseUrl: String,
    val audience: AudienceProfile,
    val sdkName: String,
    val sdkVersion: String,
    val debug: Boolean = false,
    /** Where queued events are posted. */
    val eventsPath: String = "/v1/events",
    /** Where events and actions are sent. Defaults to [baseUrl] (one backend). */
    val reportUrl: String = baseUrl,
)

/**
 * The composition root for everything both SDKs share. Nothing outside this class (and the
 * module graphs built on it) constructs a platform or network class.
 */
public class CoreGraph(
    public val platform: PlatformModule,
    public val options: CoreOptions,
    /** Called with the raw reply of every accepted upload batch. */
    onUploadReply: (suspend (String) -> Unit)? = null,
) {
    public val sdkScope: SdkScope = SdkScope(platform.dispatchers) { t ->
        platform.logger.error("Pentabit", "uncaught error in SDK scope", t)
    }

    public val sdkInfo: SdkInfo = SdkInfo(options.sdkName, options.sdkVersion)

    public val privacy: PrivacyState = PrivacyState(options.audience, platform.deviceInfo)

    private fun newApi(url: String): ApiClient = ApiClient(
        http = platform.http,
        baseUrl = url,
        clock = platform.clock,
        connectivity = platform.connectivity,
        dispatchers = platform.dispatchers,
        headers = {
            mapOf(
                "X-Aks-App-Key" to options.appKey,
                "X-Aks-App-Id" to platform.deviceInfo.appId,
                "X-Aks-Sdk" to "${options.sdkName}/${options.sdkVersion}",
                "Accept" to "application/json",
            ) + (if (options.debug) mapOf("X-Aks-Test" to "1") else emptyMap())
        },
    )

    public val api: ApiClient = newApi(options.baseUrl)

    /** Events and actions go here (a separate host in production). */
    private val reportApi: ApiClient = if (options.reportUrl == options.baseUrl) api else newApi(options.reportUrl)

    public val config: ConfigRepository = ConfigRepository(api, platform.keyValueStore, platform.clock, platform.logger)

    public val events: EventTracker = EventTracker(
        platform.eventStore, platform.clock, platform.ids, sdkScope.scope, platform.logger,
    )

    private val sessionId: String = platform.ids.newId()

    private val uploader = EventUploader(
        api = reportApi,
        store = platform.eventStore,
        clock = platform.clock,
        logger = platform.logger,
        contextProvider = { buildEventContext() },
        path = options.eventsPath,
        batchSize = { config.current.value.events.batchSize },
        onReply = onUploadReply,
    )

    public val flusher: EventFlusher = EventFlusher(uploader, sdkScope.scope, flushIntervalSeconds = { config.current.value.events.flushIntervalSeconds })

    public val pixels: PixelClient = PixelClient(platform.http, sdkScope.scope, platform.clock, platform.logger)

    init {
        events.attach(flusher)
    }

    /** Loads the cached config, refreshes it in the background and starts the event timer. Returns at once. */
    public fun start() {
        sdkScope.scope.launch {
            config.loadCached()
            config.refresh()
        }
        flusher.start()
    }

    public fun shutdown() {
        flusher.stop()
        sdkScope.shutdown()
    }

    private suspend fun buildEventContext(): EventContext? {
        val mode = privacy.currentMode()
        if (privacy.blockReason(mode) != null) return null
        val signals = privacy.signals.value
        val d = platform.deviceInfo
        return EventContext(
            app = AppInfo(d.appId, d.appVersion),
            device = DeviceContext(
                platform = d.platform,
                osVersion = d.osVersion,
                deviceClass = d.deviceClass,
                country = d.country,
                language = d.language,
                advertisingId = if (mode.allowAdvertisingId) d.advertisingId() else null,
                appInstanceId = if (mode.persistentEventId) d.appInstanceId() else null,
                deviceId = if (mode.persistentEventId) d.deviceId() else null,
            ),
            privacy = PrivacyContext(
                mode = mode.name.lowercase(),
                tcfString = signals.tcfString,
                gppString = signals.gppString,
                underAge = when (signals.isUnderAgeOfConsent) { TriState.TRUE -> true; TriState.FALSE -> false; TriState.UNKNOWN -> null },
                usOptOut = signals.usPrivacyOptOut,
                userId = if (mode.allowUserId) signals.userId else null,
            ),
            sdk = sdkInfo,
            sessionId = sessionId,
            testMode = options.debug,
        )
    }
}
