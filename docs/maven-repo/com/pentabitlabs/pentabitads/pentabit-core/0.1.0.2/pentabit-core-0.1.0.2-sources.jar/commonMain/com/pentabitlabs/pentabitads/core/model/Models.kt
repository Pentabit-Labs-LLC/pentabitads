package com.pentabitlabs.pentabitads.core.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
public enum class AdFormat {
    @SerialName("banner") BANNER,
    @SerialName("native") NATIVE,
    @SerialName("icon") ICON,
    @SerialName("interstitial") INTERSTITIAL,
    @SerialName("rewarded") REWARDED,
    @SerialName("app_open") APP_OPEN,
}

/** Who the winning campaign belongs to: a paying advertiser, or the publisher's own cross-promotion (in-house). */
@Serializable
public enum class AdSource {
    @SerialName("advertising") ADVERTISING,
    @SerialName("cross_promotion") CROSS_PROMOTION,
}

@Serializable
public enum class CreativeType {
    @SerialName("html") HTML,
    @SerialName("image") IMAGE,
    @SerialName("vast") VAST,
    @SerialName("native") NATIVE,
}

// ---------- Wire contract: ad request ----------

@Serializable
public data class SdkInfo(val name: String, val version: String)

@Serializable
public data class AppInfo(val id: String, val version: String)

@Serializable
public data class DeviceContext(
    val platform: String,
    val osVersion: String,
    val deviceClass: String,
    val country: String? = null,
    val language: String? = null,
    /** Present only when the privacy mode allows it. */
    val advertisingId: String? = null,
    /** Present only in NORMAL mode. */
    val appInstanceId: String? = null,
    /** Device-level ID (ANDROID_ID / identifierForVendor). Present only in NORMAL mode. */
    val deviceId: String? = null,
)

@Serializable
public data class PrivacyContext(
    val mode: String,
    val tcfString: String? = null,
    val gppString: String? = null,
    val underAge: Boolean? = null,
    val usOptOut: Boolean = false,
    val userId: String? = null,
)

@Serializable
public data class AdRequest(
    val requestId: String,
    val placementId: String,
    val format: AdFormat,
    val app: AppInfo,
    val device: DeviceContext,
    val privacy: PrivacyContext,
    val sdk: SdkInfo,
    /** True for debug builds: the backend returns a Pentabit test ad and does not count or bill it. */
    val testMode: Boolean = false,
    /** Banner requests only, "320x50": the backend returns a banner of exactly this size or no ad. */
    val bannerSize: String? = null,
)

// ---------- Wire contract: ad response ----------

@Serializable
public data class CreativeAsset(
    val key: String,
    val url: String,
    val mime: String? = null,
    val sizeBytes: Long? = null,
    val sha256: String? = null,
    val role: String? = null,
)

@Serializable
public data class NativeAssets(
    val title: String? = null,
    val body: String? = null,
    val callToAction: String? = null,
    val iconAssetKey: String? = null,
    val imageAssetKey: String? = null,
    val sponsoredLabel: String? = null,
    /** Where the (i) button leads. Defaults to the Pentabit privacy policy. */
    val privacyUrl: String? = null,
)

@Serializable
public data class Creative(
    val type: CreativeType,
    val markup: String? = null,
    val vastXml: String? = null,
    val vastUrl: String? = null,
    val clickUrl: String? = null,
    val assets: List<CreativeAsset> = emptyList(),
    val native: NativeAssets? = null,
    val width: Int? = null,
    val height: Int? = null,
    val orientation: String? = null,
)

@Serializable
public data class RewardSpec(val type: String = "reward", val amount: Int = 1)

@Serializable
public data class AdResponse(
    val requestId: String,
    val ttlSeconds: Int = 3600,
    val creative: Creative,
    val reward: RewardSpec? = null,
    /** Seconds before the close control shows (server decides; the SDK caps it at 15). A rewarded ad grants its reward when this time has run (web ads) or the video completes. */
    val closeDelaySeconds: Int = 0,
    /** What this impression earned the publisher, in millionths of [paidCurrency]. 0 for cross-promotion. */
    val paidMicros: Long = 0,
    val paidCurrency: String = "USD",
    /** Whether this ad is a paid advertiser or your own cross-promotion. Test ads count as advertising. */
    val adSource: AdSource = AdSource.ADVERTISING,
)
