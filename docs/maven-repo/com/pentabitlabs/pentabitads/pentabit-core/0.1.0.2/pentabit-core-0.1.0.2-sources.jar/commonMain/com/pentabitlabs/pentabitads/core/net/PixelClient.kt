package com.pentabitlabs.pentabitads.core.net

import com.pentabitlabs.pentabitads.core.ports.Clock
import com.pentabitlabs.pentabitads.core.ports.HttpClientPort
import com.pentabitlabs.pentabitads.core.ports.HttpRequest
import com.pentabitlabs.pentabitads.core.ports.Logger
import com.pentabitlabs.pentabitads.core.ports.NetworkException
import com.pentabitlabs.pentabitads.core.util.percentEncode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlin.coroutines.cancellation.CancellationException
import kotlin.random.Random

/** Fires tracking URLs (VAST and creative trackers) on a best-effort basis with one retry. */
public class PixelClient(
    private val http: HttpClientPort,
    private val scope: CoroutineScope,
    private val clock: Clock,
    private val logger: Logger,
) {
    public fun fire(urls: List<String>, macros: Map<String, String> = emptyMap()) {
        for (raw in urls) {
            val url = expand(raw, macros)
            if (!(url.startsWith("https://") || url.startsWith("http://"))) continue
            scope.launch {
                repeat(2) { attempt ->
                    try {
                        val r = http.execute(HttpRequest(url = url, timeoutMillis = 5_000))
                        if (r.status < 500) return@launch
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: NetworkException) {
                        logger.debug("PentabitPixel", "attempt ${attempt + 1} failed")
                    }
                }
            }
        }
    }

    internal fun expand(url: String, macros: Map<String, String>): String {
        var out = url
        out = out.replace("[CACHEBUSTING]", Random.nextInt(10_000_000, 99_999_999).toString())
        out = out.replace("[TIMESTAMP]", percentEncode(clock.nowMillis().toString()))
        for ((k, v) in macros) out = out.replace("[$k]", percentEncode(v))
        return out
    }
}
