package com.pentabitlabs.pentabitads.core.ad

import com.pentabitlabs.pentabitads.core.SdkDefaults
import com.pentabitlabs.pentabitads.core.config.ConfigRepository
import com.pentabitlabs.pentabitads.core.error.AdError
import com.pentabitlabs.pentabitads.core.error.AdErrorCode
import com.pentabitlabs.pentabitads.core.error.AdResult
import com.pentabitlabs.pentabitads.core.error.failure
import com.pentabitlabs.pentabitads.core.error.guard
import com.pentabitlabs.pentabitads.core.events.EventNames
import com.pentabitlabs.pentabitads.core.events.EventTracker
import com.pentabitlabs.pentabitads.core.model.AdFormat
import com.pentabitlabs.pentabitads.core.model.AdRequest
import com.pentabitlabs.pentabitads.core.model.AdResponse
import com.pentabitlabs.pentabitads.core.model.AppInfo
import com.pentabitlabs.pentabitads.core.model.CreativeType
import com.pentabitlabs.pentabitads.core.model.DeviceContext
import com.pentabitlabs.pentabitads.core.model.PrivacyContext
import com.pentabitlabs.pentabitads.core.model.SdkInfo
import com.pentabitlabs.pentabitads.core.net.PentabitJson
import com.pentabitlabs.pentabitads.core.net.ApiClient
import com.pentabitlabs.pentabitads.core.ports.AssetStore
import com.pentabitlabs.pentabitads.core.ports.CachedAsset
import com.pentabitlabs.pentabitads.core.ports.Clock
import com.pentabitlabs.pentabitads.core.ports.DeviceInfo
import com.pentabitlabs.pentabitads.core.ports.IdGenerator
import com.pentabitlabs.pentabitads.core.privacy.PrivacyMode
import com.pentabitlabs.pentabitads.core.privacy.PrivacyState
import com.pentabitlabs.pentabitads.core.privacy.TriState
import com.pentabitlabs.pentabitads.core.simid.SimidSession
import com.pentabitlabs.pentabitads.core.vast.ResolvedVast
import com.pentabitlabs.pentabitads.core.vast.VastParser
import com.pentabitlabs.pentabitads.core.vast.VastResolver
import kotlinx.serialization.SerializationException
import kotlinx.serialization.encodeToString

/**
 * Turns a placement ID into a loaded ad: checks config and consent, asks the backend, resolves
 * VAST if needed and downloads assets. Runs entirely off the main thread (the caller picks the
 * dispatcher; network and disk hops switch to io inside the ports).
 */
public class AdLoader(
    private val config: ConfigRepository,
    private val privacy: PrivacyState,
    private val deviceInfo: DeviceInfo,
    private val api: ApiClient,
    private val assets: AssetStore,
    private val vastFactory: (maxDepth: Int, timeoutMs: Long, maxBitrate: Int) -> VastResolver,
    private val clock: Clock,
    private val ids: IdGenerator,
    private val events: EventTracker,
    private val sdk: SdkInfo,
    private val testMode: Boolean = false,
) {
    public suspend fun load(placementId: String, format: AdFormat, bannerSize: String? = null): AdResult<LoadedAd> = guard {
        // The config only says whether a placement exists and is on. Nothing else about the ad.
        val placement = when (val p = config.findPlacement(placementId)) {
            is AdResult.Failure -> return@guard p
            is AdResult.Success -> p.value
        }
        if (placement.format != format) {
            return@guard failure(AdErrorCode.PLACEMENT_NOT_FOUND, "placement $placementId is not a ${format.name.lowercase()} placement")
        }

        val mode = privacy.currentMode()
        privacy.blockReason(mode)?.let { return@guard failure(AdErrorCode.CONSENT_BLOCKED, it) }

        val requestId = ids.newId()

        val result = request(placementId, format, requestId, mode, bannerSize)
        // Requests and fills are counted by the backend itself. Only real failures are reported (no fill is normal).
        if (result is AdResult.Failure && result.error.code != AdErrorCode.NO_FILL) {
            events.track(EventNames.ERROR, requestId = requestId, placementId = placementId, params = mapOf("code" to result.error.code.name))
        }
        result
    }

    private suspend fun request(placementId: String, format: AdFormat, requestId: String, mode: PrivacyMode, bannerSize: String?): AdResult<LoadedAd> {
        val signals = privacy.signals.value

        val body = PentabitJson.encodeToString(
            AdRequest(
                requestId = requestId,
                placementId = placementId,
                format = format,
                app = AppInfo(deviceInfo.appId, deviceInfo.appVersion),
                device = DeviceContext(
                    platform = deviceInfo.platform,
                    osVersion = deviceInfo.osVersion,
                    deviceClass = deviceInfo.deviceClass,
                    country = deviceInfo.country,
                    language = deviceInfo.language,
                    advertisingId = if (mode.allowAdvertisingId) deviceInfo.advertisingId() else null,
                    appInstanceId = if (mode.persistentEventId) deviceInfo.appInstanceId() else null,
                    deviceId = if (mode.persistentEventId) deviceInfo.deviceId() else null,
                ),
                privacy = PrivacyContext(
                    mode = mode.name.lowercase(),
                    tcfString = signals.tcfString,
                    gppString = signals.gppString,
                    underAge = when (signals.isUnderAgeOfConsent) { TriState.TRUE -> true; TriState.FALSE -> false; TriState.UNKNOWN -> null },
                    usOptOut = signals.usPrivacyOptOut,
                    userId = if (mode.allowUserId) signals.userId else null,
                ),
                sdk = sdk,
                testMode = testMode,
                bannerSize = bannerSize,
            ),
        )

        val http = when (val r = api.post("/v1/ad", body, SdkDefaults.REQUEST_TIMEOUT_MS, retryable = false)) {
            is AdResult.Failure -> return r
            is AdResult.Success -> r.value
        }
        if (http.status == 401 || http.status == 403) {
            config.markUnauthorized()
            return failure(AdErrorCode.APP_NOT_AUTHORIZED, "the backend rejected this app key for this app")
        }
        when {
            http.status == 204 || http.status == 404 -> return failure(AdErrorCode.NO_FILL, "no ad available")
            http.status !in 200..299 -> return failure(AdErrorCode.NETWORK, "ad request failed with HTTP ${http.status}")
        }
        val response = try {
            PentabitJson.decodeFromString<AdResponse>(http.body)
        } catch (e: SerializationException) {
            return failure(AdErrorCode.INTERNAL, "ad response could not be read")
        }

        val creative = response.creative
        var vast: ResolvedVast? = null
        var video: CachedAsset? = null
        var endCard: String? = null
        val loadedAssets = LinkedHashMap<String, CachedAsset>()

        when (creative.type) {
            CreativeType.HTML -> if (creative.markup.isNullOrBlank()) return failure(AdErrorCode.INTERNAL, "HTML creative has no markup")
            CreativeType.IMAGE, CreativeType.NATIVE -> Unit
            CreativeType.VAST -> {
                val resolver = vastFactory(SdkDefaults.VAST_MAX_WRAPPER_DEPTH, SdkDefaults.VAST_TIMEOUT_MS, SdkDefaults.VAST_MAX_BITRATE_KBPS)
                vast = when (val r = resolver.resolve(creative.vastXml, creative.vastUrl)) {
                    is AdResult.Failure -> return r
                    is AdResult.Success -> r.value
                }
                video = when (val d = assets.download(vast.media.url, "video:" + vast.media.url.hashCode(), SdkDefaults.MAX_ASSET_BYTES)) {
                    is AdResult.Failure -> return d
                    is AdResult.Success -> d.value
                }
                loadedAssets[video.key] = video
                endCard = vast.companion?.takeIf { it.resourceType == "html" }?.resource
                // A SIMID overlay (the HTML Install button over the video) is cached like any asset and served to the page from disk.
                // If it cannot be fetched the video still plays without it: VAST says an interactive file that cannot run must not stop the ad.
                vast.interactive?.let { i ->
                    val d = assets.download(i.url, SimidSession.ASSET_KEY + "@" + i.url.hashCode().toUInt().toString(16), SdkDefaults.MAX_ASSET_BYTES)
                    if (d is AdResult.Success) loadedAssets[SimidSession.ASSET_KEY] = d.value
                }
            }
        }

        for (a in creative.assets) {
            // The creative names its assets by role ("image", "icon"), so every image ad has an asset called "image". The disk cache must be
            // keyed by the URL as well, or a banner and an interstitial share one cached file and show each other's picture.
            val d = assets.download(a.url, a.key + "@" + a.url.hashCode().toUInt().toString(16), SdkDefaults.MAX_ASSET_BYTES, a.sha256)
            when (d) {
                is AdResult.Failure -> {
                    releaseAll(loadedAssets.values)
                    return d
                }
                is AdResult.Success -> loadedAssets[a.key] = d.value
            }
        }

        val now = clock.nowMillis()
        val ttl = response.ttlSeconds.coerceIn(SdkDefaults.MIN_TTL_SECONDS, SdkDefaults.MAX_TTL_SECONDS)
        return AdResult.Success(
            LoadedAd(
                sessionId = ids.newId(),
                placementId = placementId,
                format = format,
                response = response,
                assets = loadedAssets,
                vast = vast,
                videoAsset = video,
                endCardMarkup = endCard,
                loadedAtMillis = now,
                expiresAtMillis = now + ttl * 1_000L,
                privacyMode = mode,
            ),
        )
    }

    private suspend fun releaseAll(list: Collection<CachedAsset>) {
        for (a in list) assets.release(a.key)
    }
}
