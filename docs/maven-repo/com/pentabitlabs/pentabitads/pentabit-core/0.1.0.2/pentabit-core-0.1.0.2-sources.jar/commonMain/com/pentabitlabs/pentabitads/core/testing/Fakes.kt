package com.pentabitlabs.pentabitads.core.testing

import com.pentabitlabs.pentabitads.core.concurrency.DispatcherProvider
import com.pentabitlabs.pentabitads.core.error.AdErrorCode
import com.pentabitlabs.pentabitads.core.error.AdResult
import com.pentabitlabs.pentabitads.core.error.failure
import com.pentabitlabs.pentabitads.core.ports.AssetStore
import com.pentabitlabs.pentabitads.core.ports.CachedAsset
import com.pentabitlabs.pentabitads.core.ports.Clock
import com.pentabitlabs.pentabitads.core.ports.ConnectivityMonitor
import com.pentabitlabs.pentabitads.core.ports.DeviceInfo
import com.pentabitlabs.pentabitads.core.ports.EventStore
import com.pentabitlabs.pentabitads.core.ports.HttpClientPort
import com.pentabitlabs.pentabitads.core.ports.HttpRequest
import com.pentabitlabs.pentabitads.core.ports.HttpResponse
import com.pentabitlabs.pentabitads.core.ports.IdGenerator
import com.pentabitlabs.pentabitads.core.ports.KeyValueStore
import com.pentabitlabs.pentabitads.core.ports.Logger
import com.pentabitlabs.pentabitads.core.ports.NetworkException
import com.pentabitlabs.pentabitads.core.ports.NoopLogger
import com.pentabitlabs.pentabitads.core.ports.PlatformModule
import com.pentabitlabs.pentabitads.core.ports.StoredEvent
import kotlinx.coroutines.CoroutineDispatcher

// Fakes for tests. They are tiny, so they live in core and both SDKs' tests can share them.

public class FakeClock(public var now: Long = 1_000_000L) : Clock {
    override fun nowMillis(): Long = now
    public fun advance(ms: Long) { now += ms }
}

public class SequentialIds(private val prefix: String = "id") : IdGenerator {
    private var n = 0
    override fun newId(): String = "$prefix-${++n}"
}

public class TestDispatchers(dispatcher: CoroutineDispatcher) : DispatcherProvider {
    override val main: CoroutineDispatcher = dispatcher
    override val default: CoroutineDispatcher = dispatcher
    override val io: CoroutineDispatcher = dispatcher
}

public class FakeConnectivity(public var online: Boolean = true) : ConnectivityMonitor {
    override fun isOnline(): Boolean = online
}

public class InMemoryKeyValueStore : KeyValueStore {
    public val map: MutableMap<String, String> = mutableMapOf()
    override suspend fun getString(key: String): String? = map[key]
    override suspend fun putString(key: String, value: String) { map[key] = value }
    override suspend fun remove(key: String) { map.remove(key) }
}

public class InMemoryEventStore : EventStore {
    public val rows: MutableList<StoredEvent> = mutableListOf()
    override suspend fun insert(events: List<StoredEvent>) { rows += events.filter { e -> rows.none { it.id == e.id } } }
    override suspend fun readBatch(limit: Int): List<StoredEvent> = rows.sortedBy { it.createdAtMillis }.take(limit)
    override suspend fun delete(ids: List<String>) { rows.removeAll { it.id in ids } }
    override suspend fun count(): Long = rows.size.toLong()
    override suspend fun deleteOlderThan(timestampMillis: Long): Int {
        val before = rows.size
        rows.removeAll { it.createdAtMillis < timestampMillis }
        return before - rows.size
    }
    override suspend fun trimTo(maxCount: Int): Int {
        if (rows.size <= maxCount) return 0
        val keep = rows.sortedByDescending { it.createdAtMillis }.take(maxCount).map { it.id }.toSet()
        val before = rows.size
        rows.removeAll { it.id !in keep }
        return before - rows.size
    }
}

/** A scriptable HTTP client. [handler] decides each response; throw [NetworkException] to simulate transport errors. */
public class FakeHttp(
    public var handler: (HttpRequest) -> HttpResponse = { HttpResponse(200, emptyMap(), "{}") },
) : HttpClientPort {
    public val requests: MutableList<HttpRequest> = mutableListOf()
    override suspend fun execute(request: HttpRequest): HttpResponse {
        requests += request
        return handler(request)
    }
}

public class FakeAssetStore(public var failWith: String? = null) : AssetStore {
    public val downloaded: MutableList<String> = mutableListOf()
    override suspend fun download(url: String, key: String, maxBytes: Long, sha256: String?): AdResult<CachedAsset> {
        failWith?.let { return failure(AdErrorCode.ASSET_FAILED, it) }
        downloaded += url
        return AdResult.Success(CachedAsset(key, "/fake/$key", 1_024))
    }
    override suspend fun get(key: String): CachedAsset? = null
    override suspend fun release(key: String) {}
    override suspend fun trimTo(maxBytes: Long) {}
}

public class FakeDeviceInfo(
    public var adId: String? = "ad-id-1",
    override val platform: String = "android",
) : DeviceInfo {
    override val osVersion: String = "14"
    override val deviceClass: String = "phone"
    override val appId: String = "com.example.app"
    override val appVersion: String = "1.0.0"
    override val country: String? = "US"
    override val language: String? = "en"
    override val isLowPowerMode: Boolean = false
    override suspend fun advertisingId(): String? = adId
    override suspend fun deviceId(): String? = "device-1"
    override suspend fun appInstanceId(): String = "instance-1"
}

public class FakePlatform(
    dispatcher: CoroutineDispatcher,
    override val clock: FakeClock = FakeClock(),
    override val http: FakeHttp = FakeHttp(),
    override val eventStore: InMemoryEventStore = InMemoryEventStore(),
    override val keyValueStore: InMemoryKeyValueStore = InMemoryKeyValueStore(),
    override val assetStore: FakeAssetStore = FakeAssetStore(),
    override val connectivity: FakeConnectivity = FakeConnectivity(),
    override val deviceInfo: FakeDeviceInfo = FakeDeviceInfo(),
) : PlatformModule {
    override val ids: IdGenerator = SequentialIds()
    override val logger: Logger = NoopLogger
    override val dispatchers: DispatcherProvider = TestDispatchers(dispatcher)
}
