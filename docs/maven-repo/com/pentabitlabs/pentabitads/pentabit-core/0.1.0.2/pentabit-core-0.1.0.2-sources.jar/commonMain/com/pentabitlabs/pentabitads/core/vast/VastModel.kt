package com.pentabitlabs.pentabitads.core.vast

public data class VastMedia(
    val url: String,
    val mime: String,
    val width: Int,
    val height: Int,
    val bitrateKbps: Int?,
    val delivery: String,
)

public data class VastTracking(val event: String, val url: String, val offset: String? = null)

public data class VastCompanion(
    val width: Int,
    val height: Int,
    /** "html", "static" or "iframe". */
    val resourceType: String,
    val resource: String,
    val creativeType: String?,
    val clickThrough: String?,
    val clickTracking: List<String>,
    val tracking: List<VastTracking>,
)

/** A SIMID interactive creative from <InteractiveCreativeFile>: HTML the player runs in an iframe over the video. [adParameters] is the VAST <AdParameters> text. */
public data class VastInteractive(
    val url: String,
    val apiFramework: String,
    val variableDuration: Boolean,
    val adParameters: String?,
)

public data class VastLinear(
    val durationMs: Long?,
    val skipOffset: String?,
    val mediaFiles: List<VastMedia>,
    val tracking: List<VastTracking>,
    val clickThrough: String?,
    val clickTracking: List<String>,
    val interactive: VastInteractive? = null,
)

public data class VastAd(
    val isWrapper: Boolean,
    val wrapperUrl: String?,
    val impressions: List<String>,
    val errors: List<String>,
    val linear: VastLinear?,
    val companions: List<VastCompanion>,
)

/** A wrapper chain collapsed into one playable ad. */
public data class ResolvedVast(
    val impressions: List<String>,
    val errors: List<String>,
    val durationMs: Long,
    val skipOffsetMs: Long?,
    val media: VastMedia,
    val tracking: List<VastTracking>,
    val clickThrough: String?,
    val clickTracking: List<String>,
    val companion: VastCompanion?,
    val interactive: VastInteractive? = null,
)
