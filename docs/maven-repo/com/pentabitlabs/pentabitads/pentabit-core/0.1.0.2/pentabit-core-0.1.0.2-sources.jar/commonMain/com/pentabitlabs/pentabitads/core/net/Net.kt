package com.pentabitlabs.pentabitads.core.net

import com.pentabitlabs.pentabitads.core.error.AdErrorCode
import com.pentabitlabs.pentabitads.core.error.AdResult
import com.pentabitlabs.pentabitads.core.error.failure
import com.pentabitlabs.pentabitads.core.ports.Clock
import com.pentabitlabs.pentabitads.core.ports.ConnectivityMonitor
import com.pentabitlabs.pentabitads.core.ports.HttpClientPort
import com.pentabitlabs.pentabitads.core.ports.HttpRequest
import com.pentabitlabs.pentabitads.core.ports.HttpResponse
import com.pentabitlabs.pentabitads.core.ports.NetworkException
import com.pentabitlabs.pentabitads.core.concurrency.DispatcherProvider
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.min
import kotlin.random.Random

public val PentabitJson: Json = Json {
    ignoreUnknownKeys = true
    coerceInputValues = true // an ad source this SDK does not know yet falls back to the default instead of failing the ad
    encodeDefaults = true
    explicitNulls = false
    isLenient = false
}

public class RetryPolicy(
    public val maxAttempts: Int = 3,
    private val baseDelayMs: Long = 500,
    private val maxDelayMs: Long = 8_000,
) {
    /** Exponential backoff with jitter. [attempt] starts at 0 for the first retry. [random] is in 0..1. */
    public fun delayMillis(attempt: Int, random: Double): Long {
        val exp = baseDelayMs * (1L shl min(attempt, 10))
        val capped = min(exp, maxDelayMs)
        return (capped * (0.5 + random * 0.5)).toLong()
    }
}

/** After repeated failures, calls fail fast for a cool-down so an outage does not drain battery. */
public class CircuitBreaker(
    private val clock: Clock,
    private val failureThreshold: Int = 5,
    private val cooldownMs: Long = 30_000,
) {
    private var failures = 0
    private var openedAt = 0L

    public fun isOpen(): Boolean {
        if (failures < failureThreshold) return false
        if (clock.nowMillis() - openedAt >= cooldownMs) {
            // half-open: allow one trial
            failures = failureThreshold - 1
            return false
        }
        return true
    }

    public fun recordSuccess() { failures = 0 }

    public fun recordFailure() {
        failures++
        if (failures >= failureThreshold) openedAt = clock.nowMillis()
    }
}

public class ApiClient(
    private val http: HttpClientPort,
    private val baseUrl: String,
    private val clock: Clock,
    private val connectivity: ConnectivityMonitor,
    private val dispatchers: DispatcherProvider,
    private val headers: () -> Map<String, String>,
    private val retry: RetryPolicy = RetryPolicy(),
    private val breaker: CircuitBreaker = CircuitBreaker(clock),
    private val random: () -> Double = { Random.nextDouble() },
    private val sleep: suspend (Long) -> Unit = { delay(it) },
) {
    public suspend fun get(path: String, timeoutMs: Long, retryable: Boolean): AdResult<HttpResponse> =
        send("GET", path, null, timeoutMs, retryable)

    public suspend fun post(path: String, body: String, timeoutMs: Long, retryable: Boolean, extraHeaders: Map<String, String> = emptyMap()): AdResult<HttpResponse> =
        send("POST", path, body, timeoutMs, retryable, extraHeaders)

    /**
     * Returns any HTTP response (including 4xx and 5xx) as Success once retries are used up.
     * Transport problems become Failure with NETWORK or TIMEOUT.
     */
    public suspend fun send(
        method: String,
        path: String,
        body: String?,
        timeoutMs: Long,
        retryable: Boolean,
        extraHeaders: Map<String, String> = emptyMap(),
    ): AdResult<HttpResponse> {
        if (!connectivity.isOnline()) return failure(AdErrorCode.NETWORK, "offline")
        if (breaker.isOpen()) return failure(AdErrorCode.NETWORK, "backend unavailable, backing off")

        val attempts = if (retryable) retry.maxAttempts else 1
        var last: AdResult<HttpResponse> = failure(AdErrorCode.NETWORK, "no attempt made")
        for (attempt in 0 until attempts) {
            val request = HttpRequest(
                url = baseUrl.trimEnd('/') + path,
                method = method,
                headers = headers() + extraHeaders + (if (body != null) mapOf("Content-Type" to "application/json") else emptyMap()),
                body = body,
                timeoutMillis = timeoutMs,
            )
            last = try {
                val response = withContext(dispatchers.io) { http.execute(request) }
                if (response.status >= 500 || response.status == 429) {
                    breaker.recordFailure()
                    AdResult.Success(response)
                } else {
                    breaker.recordSuccess()
                    return AdResult.Success(response)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: NetworkException) {
                breaker.recordFailure()
                val code = if (e.kind == NetworkException.Kind.TIMEOUT) AdErrorCode.TIMEOUT else AdErrorCode.NETWORK
                failure(code, e.message ?: "network error")
            }
            if (attempt < attempts - 1) {
                val retryAfter = (last as? AdResult.Success)?.value?.headers?.get("retry-after")?.toLongOrNull()
                val wait = if (retryAfter != null) min(retryAfter * 1_000, 10_000) else retry.delayMillis(attempt, random())
                sleep(wait)
            }
        }
        return last
    }
}
