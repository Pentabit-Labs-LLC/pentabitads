package com.pentabitlabs.pentabitads.core.vast

internal class XmlNode(
    val name: String,
    val attrs: Map<String, String>,
) {
    val children: MutableList<XmlNode> = mutableListOf()
    internal val raw: StringBuilder = StringBuilder()
    val text: String get() = raw.toString().trim()

    fun child(name: String): XmlNode? = children.firstOrNull { it.name == name }
    fun all(name: String): List<XmlNode> = children.filter { it.name == name }
}

/**
 * A small, strict XML reader for VAST. No DTDs, no external entities and no entity expansion beyond
 * the five predefined ones and numeric references, so it cannot be used for entity attacks.
 */
internal object MiniXml {
    private const val MAX_DEPTH = 64

    fun parse(src: String): XmlNode? {
        val n = src.length
        var i = 0
        val stack = ArrayList<XmlNode>()
        var root: XmlNode? = null

        while (i < n) {
            if (src[i] != '<') {
                val j = src.indexOf('<', i).let { if (it < 0) n else it }
                if (stack.isNotEmpty()) stack.last().raw.append(decode(src.substring(i, j)))
                i = j
                continue
            }
            when {
                src.startsWith("<!--", i) -> {
                    val e = src.indexOf("-->", i + 4)
                    if (e < 0) return null
                    i = e + 3
                }
                src.startsWith("<![CDATA[", i) -> {
                    val e = src.indexOf("]]>", i + 9)
                    if (e < 0) return null
                    if (stack.isNotEmpty()) stack.last().raw.append(src, i + 9, e)
                    i = e + 3
                }
                src.startsWith("<?", i) -> {
                    val e = src.indexOf("?>", i + 2)
                    if (e < 0) return null
                    i = e + 2
                }
                src.startsWith("<!", i) -> {
                    val e = src.indexOf('>', i + 2)
                    if (e < 0) return null
                    i = e + 1
                }
                src.startsWith("</", i) -> {
                    val e = src.indexOf('>', i + 2)
                    if (e < 0 || stack.isEmpty()) return null
                    stack.removeAt(stack.lastIndex)
                    i = e + 1
                }
                else -> {
                    var j = i + 1
                    while (j < n && !src[j].isWhitespace() && src[j] != '/' && src[j] != '>') j++
                    if (j >= n) return null
                    val name = src.substring(i + 1, j).substringAfter(':')
                    val attrs = LinkedHashMap<String, String>()
                    var selfClosing = false
                    while (true) {
                        while (j < n && src[j].isWhitespace()) j++
                        if (j >= n) return null
                        val c = src[j]
                        if (c == '>') { j++; break }
                        if (c == '/') {
                            if (j + 1 < n && src[j + 1] == '>') { selfClosing = true; j += 2; break }
                            return null
                        }
                        val ns = j
                        while (j < n && src[j] != '=' && !src[j].isWhitespace() && src[j] != '>' && src[j] != '/') j++
                        val attrName = src.substring(ns, j).substringAfter(':')
                        while (j < n && src[j].isWhitespace()) j++
                        if (j >= n || src[j] != '=') return null
                        j++
                        while (j < n && src[j].isWhitespace()) j++
                        if (j >= n) return null
                        val q = src[j]
                        if (q != '"' && q != '\'') return null
                        val ve = src.indexOf(q, j + 1)
                        if (ve < 0) return null
                        attrs[attrName] = decode(src.substring(j + 1, ve))
                        j = ve + 1
                    }
                    val node = XmlNode(name, attrs)
                    if (stack.isEmpty()) {
                        if (root != null) return root // ignore anything after the root element
                        root = node
                    } else {
                        stack.last().children.add(node)
                    }
                    if (!selfClosing) {
                        if (stack.size >= MAX_DEPTH) return null
                        stack.add(node)
                    }
                    i = j
                }
            }
        }
        return if (stack.isEmpty()) root else null
    }

    private fun decode(s: String): String {
        if (!s.contains('&')) return s
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '&') {
                val e = s.indexOf(';', i)
                if (e > i && e - i <= 10) {
                    val replacement = when (val ent = s.substring(i + 1, e)) {
                        "amp" -> "&"
                        "lt" -> "<"
                        "gt" -> ">"
                        "quot" -> "\""
                        "apos" -> "'"
                        else -> numeric(ent)
                    }
                    if (replacement != null) {
                        sb.append(replacement)
                        i = e + 1
                        continue
                    }
                }
            }
            sb.append(c)
            i++
        }
        return sb.toString()
    }

    private fun numeric(ent: String): String? {
        if (!ent.startsWith("#")) return null
        val code = if (ent.startsWith("#x") || ent.startsWith("#X")) ent.substring(2).toIntOrNull(16) else ent.substring(1).toIntOrNull()
        if (code == null || code <= 0 || code > 0xFFFF) return null
        return code.toChar().toString()
    }
}
