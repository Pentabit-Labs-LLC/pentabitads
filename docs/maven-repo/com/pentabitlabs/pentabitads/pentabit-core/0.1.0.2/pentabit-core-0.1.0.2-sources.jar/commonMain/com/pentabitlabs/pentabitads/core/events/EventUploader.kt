package com.pentabitlabs.pentabitads.core.events

import com.pentabitlabs.pentabitads.core.SdkDefaults
import kotlin.coroutines.cancellation.CancellationException
import com.pentabitlabs.pentabitads.core.error.AdResult
import com.pentabitlabs.pentabitads.core.net.PentabitJson
import com.pentabitlabs.pentabitads.core.net.ApiClient
import com.pentabitlabs.pentabitads.core.ports.Clock
import com.pentabitlabs.pentabitads.core.ports.EventStore
import com.pentabitlabs.pentabitads.core.ports.Logger
import kotlinx.serialization.SerializationException
import kotlinx.serialization.encodeToString

public enum class FlushOutcome { NOTHING_TO_SEND, SENT, RETRY_LATER, BLOCKED }

/**
 * Reads batches from the durable queue and posts them. An event is deleted only after the backend
 * confirmed it (2xx) or rejected it as invalid (4xx). Retries are safe because the backend
 * de-duplicates by event ID.
 */
public class EventUploader(
    private val api: ApiClient,
    private val store: EventStore,
    private val clock: Clock,
    private val logger: Logger,
    /** Returns the context for this batch, or null when consent forbids sending right now. */
    private val contextProvider: suspend () -> EventContext?,
    private val maxBatchesPerFlush: Int = 5,
    /** Ads SDK reports to /v1/events; Analytics reports advertiser actions to /v1/actions. */
    private val path: String = "/v1/events",
    /** Gets the raw reply of each accepted batch (Analytics reads the SKAdNetwork value from it). */
    /** Events per request; the server may change it through the config. */
    private val batchSize: () -> Int = { SdkDefaults.EVENT_BATCH_SIZE },
    private val onReply: (suspend (String) -> Unit)? = null,
) {
    public suspend fun flushOnce(): FlushOutcome {
        val context = contextProvider() ?: return FlushOutcome.BLOCKED

        store.deleteOlderThan(clock.nowMillis() - SdkDefaults.EVENT_MAX_AGE_HOURS * 3_600_000L)
        store.trimTo(SdkDefaults.EVENT_QUEUE_MAX)

        var sentAny = false
        repeat(maxBatchesPerFlush) {
            val rows = store.readBatch(batchSize())
            if (rows.isEmpty()) return if (sentAny) FlushOutcome.SENT else FlushOutcome.NOTHING_TO_SEND

            val events = ArrayList<PentabitEvent>(rows.size)
            val corrupt = ArrayList<String>()
            for (row in rows) {
                try {
                    events += PentabitJson.decodeFromString<PentabitEvent>(row.payload)
                } catch (e: SerializationException) {
                    corrupt += row.id
                }
            }
            if (corrupt.isNotEmpty()) store.delete(corrupt)
            if (events.isEmpty()) return@repeat

            val body = PentabitJson.encodeToString(events)
            when (val result = api.post(path, body, timeoutMs = 10_000, retryable = true, extraHeaders = context.toHeaders())) {
                is AdResult.Failure -> return FlushOutcome.RETRY_LATER
                is AdResult.Success -> {
                    val status = result.value.status
                    when {
                        status in 200..299 -> {
                            store.delete(events.map { it.id })
                            sentAny = true
                            try { onReply?.invoke(result.value.body) } catch (e: CancellationException) { throw e } catch (e: Throwable) { /* a bad reply must not break upload */ }
                        }
                        status in 400..499 && status != 408 && status != 429 -> {
                            logger.warn("PentabitEvents", "backend rejected a batch with HTTP $status; dropping it")
                            store.delete(events.map { it.id })
                        }
                        else -> return FlushOutcome.RETRY_LATER
                    }
                }
            }
        }
        return if (sentAny) FlushOutcome.SENT else FlushOutcome.NOTHING_TO_SEND
    }
}
