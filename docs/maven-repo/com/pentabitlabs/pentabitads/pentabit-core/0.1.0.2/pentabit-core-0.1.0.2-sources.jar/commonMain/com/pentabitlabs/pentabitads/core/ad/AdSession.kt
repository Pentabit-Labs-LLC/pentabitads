package com.pentabitlabs.pentabitads.core.ad

import com.pentabitlabs.pentabitads.core.model.AdFormat
import com.pentabitlabs.pentabitads.core.error.AdError
import com.pentabitlabs.pentabitads.core.model.AdResponse
import com.pentabitlabs.pentabitads.core.ports.CachedAsset
import com.pentabitlabs.pentabitads.core.privacy.PrivacyMode
import com.pentabitlabs.pentabitads.core.vast.ResolvedVast
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

public enum class AdStage { IDLE, LOADING, READY, SHOWING, COMPLETED, EXPIRED, FAILED, DESTROYED }

/** Everything needed to show an ad that has finished loading. */
public class LoadedAd(
    public val sessionId: String,
    public val placementId: String,
    public val format: AdFormat,
    public val response: AdResponse,
    public val assets: Map<String, CachedAsset>,
    public val vast: ResolvedVast?,
    public val videoAsset: CachedAsset?,
    public val endCardMarkup: String?,
    public val loadedAtMillis: Long,
    public val expiresAtMillis: Long,
    public val privacyMode: PrivacyMode,
) {
    public val requestId: String get() = response.requestId
}

/**
 * One ad, driven by an explicit state machine. A move is only allowed from certain states, which
 * prevents double shows, shows after expiry and leaks.
 */
public class AdSession(public val id: String) {
    private val _stage = MutableStateFlow(AdStage.IDLE)
    public val stage: StateFlow<AdStage> get() = _stage

    public var error: AdError? = null
        private set
    public var loaded: LoadedAd? = null
        private set

    /** Returns false (and changes nothing) when the move is not allowed. */
    public fun transition(to: AdStage): Boolean {
        val from = _stage.value
        if (to !in allowedFrom(from)) return false
        _stage.value = to
        return true
    }

    public fun markLoaded(ad: LoadedAd): Boolean {
        if (!transition(AdStage.READY)) return false
        loaded = ad
        return true
    }

    public fun markFailed(error: AdError): Boolean {
        if (!transition(AdStage.FAILED)) return false
        this.error = error
        return true
    }

    public fun isExpired(nowMillis: Long): Boolean {
        val ad = loaded ?: return false
        return nowMillis >= ad.expiresAtMillis
    }

    public companion object {
        public fun allowedFrom(from: AdStage): Set<AdStage> = when (from) {
            AdStage.IDLE -> setOf(AdStage.LOADING, AdStage.DESTROYED)
            AdStage.LOADING -> setOf(AdStage.READY, AdStage.FAILED, AdStage.DESTROYED)
            AdStage.READY -> setOf(AdStage.SHOWING, AdStage.EXPIRED, AdStage.FAILED, AdStage.DESTROYED)
            AdStage.SHOWING -> setOf(AdStage.COMPLETED, AdStage.FAILED, AdStage.DESTROYED)
            AdStage.COMPLETED -> setOf(AdStage.DESTROYED)
            AdStage.EXPIRED -> setOf(AdStage.DESTROYED)
            AdStage.FAILED -> setOf(AdStage.DESTROYED)
            AdStage.DESTROYED -> emptySet()
        }
    }
}
