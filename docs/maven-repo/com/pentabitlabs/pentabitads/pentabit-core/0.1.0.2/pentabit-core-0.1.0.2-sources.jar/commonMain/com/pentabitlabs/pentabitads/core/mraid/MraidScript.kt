package com.pentabitlabs.pentabitads.core.mraid

/**
 * The mraid.js the SDK injects into every web creative, plus the small `aks` object used by
 * playables. Native code talks to it through `window.__aks`. Written for MRAID 3.0 without
 * expand and resize, which report an error event.
 */
public object MraidScript {
    public const val JS: String = """
(function () {
  if (window.mraid) { return; }
  var listeners = {};
  var state = 'loading';
  var placement = 'inline';
  var viewable = false;
  var maxSize = { width: 0, height: 0 };
  var screenSize = { width: 0, height: 0 };
  var position = { x: 0, y: 0, width: 0, height: 0 };
  var orientation = { allowOrientationChange: true, forceOrientation: 'none' };

  function post(message) {
    try {
      var s = JSON.stringify(message);
      if (window.AksNative && window.AksNative.post) { window.AksNative.post(s); }
      else if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.aks) {
        window.webkit.messageHandlers.aks.postMessage(s);
      }
    } catch (e) {}
  }
  function fire(name) {
    var args = Array.prototype.slice.call(arguments, 1);
    var list = listeners[name];
    if (!list) { return; }
    list = list.slice();
    for (var i = 0; i < list.length; i++) { try { list[i].apply(null, args); } catch (e) {} }
  }
  function unsupported(name) { fire('error', name + ' is not supported', name); }

  var mraid = {
    getVersion: function () { return '3.0'; },
    getState: function () { return state; },
    getPlacementType: function () { return placement; },
    isViewable: function () { return viewable; },
    addEventListener: function (name, fn) {
      if (typeof fn !== 'function') { return; }
      if (!listeners[name]) { listeners[name] = []; }
      if (listeners[name].indexOf(fn) < 0) { listeners[name].push(fn); }
    },
    removeEventListener: function (name, fn) {
      if (!listeners[name]) { return; }
      if (!fn) { delete listeners[name]; return; }
      var i = listeners[name].indexOf(fn);
      if (i >= 0) { listeners[name].splice(i, 1); }
    },
    open: function (url) {
      if (typeof url !== 'string' || !url) { fire('error', 'open requires a url', 'open'); return; }
      post({ cmd: 'open', url: url });
    },
    close: function () { post({ cmd: 'close' }); },
    unload: function () { post({ cmd: 'unload' }); },
    expand: function () { unsupported('expand'); },
    resize: function () { unsupported('resize'); },
    useCustomClose: function () {},
    getExpandProperties: function () { return { width: 0, height: 0, useCustomClose: false, isModal: true }; },
    setExpandProperties: function () {},
    getResizeProperties: function () { return {}; },
    setResizeProperties: function () {},
    getOrientationProperties: function () { return orientation; },
    setOrientationProperties: function (p) {
      if (p && typeof p === 'object') {
        orientation = {
          allowOrientationChange: p.allowOrientationChange !== false,
          forceOrientation: p.forceOrientation || 'none'
        };
        post({ cmd: 'orientation', allow: orientation.allowOrientationChange, force: orientation.forceOrientation });
      }
    },
    getCurrentAppOrientation: function () {
      return { orientation: screenSize.width > screenSize.height ? 'landscape' : 'portrait', locked: false };
    },
    getMaxSize: function () { return maxSize; },
    getScreenSize: function () { return screenSize; },
    getCurrentPosition: function () { return position; },
    getDefaultPosition: function () { return position; },
    supports: function (feature) { return false; },
    playVideo: function () { unsupported('playVideo'); },
    storePicture: function () { unsupported('storePicture'); },
    createCalendarEvent: function () { unsupported('createCalendarEvent'); }
  };

  window.__aks = {
    init: function (p, w, h, sw, sh) {
      placement = p;
      maxSize = { width: w, height: h };
      screenSize = { width: sw, height: sh };
      position = { x: 0, y: 0, width: w, height: h };
    },
    ready: function () { state = 'default'; fire('ready'); },
    setState: function (s) { if (s === state) { return; } state = s; fire('stateChange', s); },
    setViewable: function (v) { v = !!v; if (v === viewable) { return; } viewable = v; fire('viewableChange', v); },
    setExposure: function (pct) {
      fire('exposureChange', pct, { x: 0, y: 0, width: position.width, height: position.height }, null);
    }
  };

  window.aks = {
    ready: function () { post({ cmd: 'aks.ready' }); },
    complete: function () { post({ cmd: 'aks.complete' }); },
    cta: function () { post({ cmd: 'aks.cta' }); },
    error: function (m) { post({ cmd: 'aks.error', msg: String(m || '') }); }
  };

  window.mraid = mraid;
})();
"""
}
