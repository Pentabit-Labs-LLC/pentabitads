package com.pentabitlabs.pentabitads.core.error

import kotlin.coroutines.cancellation.CancellationException

/** Stable error codes. Publishers can rely on these never changing meaning. */
public enum class AdErrorCode {
    NOT_INITIALIZED,
    PLACEMENT_NOT_FOUND,
    PLACEMENT_DISABLED,
    KILL_SWITCH,
    /** The backend says this app key does not belong to this app (package or bundle ID). */
    APP_NOT_AUTHORIZED,
    CONSENT_BLOCKED,
    NO_FILL,
    TIMEOUT,
    NETWORK,
    ASSET_FAILED,
    EXPIRED,
    INTERNAL,
}

public data class AdError(
    public val code: AdErrorCode,
    public val message: String,
)

/** Result type used across the SDK instead of exceptions. */
public sealed interface AdResult<out T> {
    public data class Success<out T>(public val value: T) : AdResult<T>
    public data class Failure(public val error: AdError) : AdResult<Nothing>
}

public fun failure(code: AdErrorCode, message: String): AdResult.Failure =
    AdResult.Failure(AdError(code, message))

public inline fun <T, R> AdResult<T>.map(transform: (T) -> R): AdResult<R> = when (this) {
    is AdResult.Success -> AdResult.Success(transform(value))
    is AdResult.Failure -> this
}

public inline fun <T, R> AdResult<T>.flatMap(transform: (T) -> AdResult<R>): AdResult<R> = when (this) {
    is AdResult.Success -> transform(value)
    is AdResult.Failure -> this
}

public fun <T> AdResult<T>.getOrNull(): T? = (this as? AdResult.Success)?.value

public fun <T> AdResult<T>.errorOrNull(): AdError? = (this as? AdResult.Failure)?.error

/**
 * Runs [block] and converts any unexpected exception into an INTERNAL failure.
 * Cancellation is always rethrown so structured concurrency keeps working.
 */
public suspend fun <T> guard(block: suspend () -> AdResult<T>): AdResult<T> =
    try {
        block()
    } catch (e: CancellationException) {
        throw e
    } catch (e: Throwable) {
        failure(AdErrorCode.INTERNAL, e.message ?: e::class.simpleName ?: "unexpected error")
    }
