package com.pentabitlabs.pentabitads.core

/**
 * Fixed SDK limits. The SDK makes no decisions: what to show, for how long, whether a reward is
 * granted and what a conversion is worth all come from the server, per ad or per reply.
 * These numbers only protect the device (timeouts, sizes, batching).
 */
public object SdkDefaults {
    public const val REQUEST_TIMEOUT_MS: Long = 8_000
    public const val MAX_ASSET_BYTES: Long = 30L * 1024 * 1024
    public const val MAX_CLOSE_DELAY_SECONDS: Int = 15 // Google Play limit for the close control delay
    public const val MIN_TTL_SECONDS: Int = 30
    public const val MAX_TTL_SECONDS: Int = 86_400

    public const val VAST_MAX_WRAPPER_DEPTH: Int = 5
    public const val VAST_TIMEOUT_MS: Long = 5_000
    public const val VAST_MAX_BITRATE_KBPS: Int = 2_500

    public const val VIEWABLE_AREA_PERCENT: Int = 50
    public const val VIEWABLE_MS: Long = 1_000
    public const val VIEWABLE_VIDEO_MS: Long = 2_000

    public const val EVENT_BATCH_SIZE: Int = 20
    public const val EVENT_FLUSH_SECONDS: Int = 30
    public const val EVENT_QUEUE_MAX: Int = 1_000
    public const val EVENT_MAX_AGE_HOURS: Int = 24
}
