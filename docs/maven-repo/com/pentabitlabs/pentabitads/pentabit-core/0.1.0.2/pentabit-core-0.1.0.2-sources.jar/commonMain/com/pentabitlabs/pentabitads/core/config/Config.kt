package com.pentabitlabs.pentabitads.core.config

import com.pentabitlabs.pentabitads.core.SdkDefaults
import com.pentabitlabs.pentabitads.core.model.AdFormat
import kotlinx.serialization.Serializable

/** One ad slot the app may use. Everything else about an ad comes with the ad itself. */
@Serializable
public data class PlacementConfig(
    val id: String,
    val format: AdFormat,
    val enabled: Boolean = true,
)

@Serializable
public data class EventConfig(
    val batchSize: Int = SdkDefaults.EVENT_BATCH_SIZE,
    val flushIntervalSeconds: Int = SdkDefaults.EVENT_FLUSH_SECONDS,
)

/** The slim config: what the SDK must know before it asks for an ad. */
@Serializable
public data class SdkConfig(
    val version: Long = 0,
    val killSwitch: Boolean = false,
    val refreshIntervalSeconds: Int = 3_600,
    val placements: List<PlacementConfig> = emptyList(),
    val events: EventConfig = EventConfig(),
) {
    public companion object {
        /** Safe default: no placements, so no ad can be requested until a real config arrives. */
        public val SAFE_DEFAULT: SdkConfig = SdkConfig()
    }
}
