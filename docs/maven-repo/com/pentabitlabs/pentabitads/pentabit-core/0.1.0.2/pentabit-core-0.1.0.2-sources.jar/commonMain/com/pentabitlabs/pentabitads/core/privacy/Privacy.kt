package com.pentabitlabs.pentabitads.core.privacy

import com.pentabitlabs.pentabitads.core.ports.DeviceInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Who the app is made for. Declared once by the app at initialize. */
public enum class AudienceProfile { CHILD_DIRECTED, MIXED_AUDIENCE, GENERAL }

public enum class TriState { TRUE, FALSE, UNKNOWN }

/** Signals the publisher (or advertiser) supplies from its own consent and age tools. */
public data class ConsentSignals(
    public val personalizedAdsAllowed: TriState = TriState.UNKNOWN,
    public val gdprApplies: TriState = TriState.UNKNOWN,
    public val tcfString: String? = null,
    public val gppString: String? = null,
    public val usPrivacyOptOut: Boolean = false,
    public val isUnderAgeOfConsent: TriState = TriState.UNKNOWN,
    public val userId: String? = null,
)

/** What the SDK may collect, send and show for the current user. */
public enum class PrivacyMode(
    public val allowAdvertisingId: Boolean,
    public val allowUserId: Boolean,
    public val personalized: Boolean,
    public val persistentEventId: Boolean,
    public val analyticsActionsAllowed: Boolean,
) {
    NORMAL(true, true, true, true, true),
    NON_PERSONALIZED(false, false, false, false, true),
    CHILD_DIRECTED(false, false, false, false, false),
}

public class ConsentPolicy {
    /**
     * Unknown or missing signals fall to the stricter mode, never the looser one.
     */
    public fun mode(
        profile: AudienceProfile,
        signals: ConsentSignals,
        advertisingIdAvailable: Boolean,
    ): PrivacyMode {
        if (profile == AudienceProfile.CHILD_DIRECTED) return PrivacyMode.CHILD_DIRECTED
        if (signals.isUnderAgeOfConsent == TriState.TRUE) return PrivacyMode.CHILD_DIRECTED
        if (profile == AudienceProfile.MIXED_AUDIENCE && signals.isUnderAgeOfConsent == TriState.UNKNOWN) {
            return PrivacyMode.CHILD_DIRECTED
        }
        if (signals.usPrivacyOptOut) return PrivacyMode.NON_PERSONALIZED
        if (signals.personalizedAdsAllowed != TriState.TRUE) return PrivacyMode.NON_PERSONALIZED
        if (!advertisingIdAvailable) return PrivacyMode.NON_PERSONALIZED
        return PrivacyMode.NORMAL
    }

    /** Returns a reason when nothing may be requested or sent, or null when allowed. */
    public fun blockReason(signals: ConsentSignals, mode: PrivacyMode): String? {
        if (mode == PrivacyMode.CHILD_DIRECTED) return null
        if (signals.gdprApplies == TriState.TRUE && signals.tcfString.isNullOrBlank()) {
            return "GDPR applies and no TCF string was supplied"
        }
        return null
    }
}

/** Holds the current audience profile and consent signals, and computes the mode on demand. */
public class PrivacyState(
    public val profile: AudienceProfile,
    private val deviceInfo: DeviceInfo,
    private val policy: ConsentPolicy = ConsentPolicy(),
) {
    private val _signals = MutableStateFlow(ConsentSignals())
    public val signals: StateFlow<ConsentSignals> get() = _signals

    public fun update(signals: ConsentSignals) {
        _signals.value = signals
    }

    public suspend fun currentMode(): PrivacyMode {
        val s = _signals.value
        val adIdAvailable = deviceInfo.advertisingId() != null
        return policy.mode(profile, s, adIdAvailable)
    }

    public fun blockReason(mode: PrivacyMode): String? = policy.blockReason(_signals.value, mode)
}
