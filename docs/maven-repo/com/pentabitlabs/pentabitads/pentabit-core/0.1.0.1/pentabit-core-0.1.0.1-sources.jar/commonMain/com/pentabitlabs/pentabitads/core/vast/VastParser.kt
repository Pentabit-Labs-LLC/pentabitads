package com.pentabitlabs.pentabitads.core.vast

import com.pentabitlabs.pentabitads.core.error.AdErrorCode
import com.pentabitlabs.pentabitads.core.error.AdResult
import com.pentabitlabs.pentabitads.core.error.failure

/** Parses one VAST 2.0 to 4.x document into its first ad. Ad pods are not used in v1. */
public class VastParser {
    public fun parse(xml: String): AdResult<VastAd> {
        if (xml.length > MAX_CHARS) return failure(AdErrorCode.NO_FILL, "VAST document too large")
        val root = MiniXml.parse(xml) ?: return failure(AdErrorCode.NO_FILL, "VAST is not valid XML")
        if (root.name != "VAST") return failure(AdErrorCode.NO_FILL, "root element is not VAST")
        val version = root.attrs["version"].orEmpty()
        if (!(version.startsWith("2.") || version.startsWith("3.") || version.startsWith("4."))) {
            return failure(AdErrorCode.NO_FILL, "unsupported VAST version '$version'")
        }
        val adNode = root.child("Ad") ?: return failure(AdErrorCode.NO_FILL, "VAST has no Ad")
        val inline = adNode.child("InLine")
        val wrapper = adNode.child("Wrapper")
        val body = inline ?: wrapper ?: return failure(AdErrorCode.NO_FILL, "Ad has no InLine or Wrapper")

        val impressions = body.all("Impression").map { it.text }.filter { it.isNotBlank() }
        val errors = body.all("Error").map { it.text }.filter { it.isNotBlank() }
        var linear: VastLinear? = null
        val companions = ArrayList<VastCompanion>()

        for (creative in body.child("Creatives")?.all("Creative").orEmpty()) {
            creative.child("Linear")?.let { if (linear == null) linear = parseLinear(it) }
            for (c in creative.child("CompanionAds")?.all("Companion").orEmpty()) parseCompanion(c)?.let { companions += it }
        }
        return AdResult.Success(
            VastAd(
                isWrapper = wrapper != null && inline == null,
                wrapperUrl = wrapper?.child("VASTAdTagURI")?.text?.takeIf { it.isNotBlank() },
                impressions = impressions,
                errors = errors,
                linear = linear,
                companions = companions,
            ),
        )
    }

    private fun parseLinear(node: XmlNode): VastLinear {
        val media = node.child("MediaFiles")?.all("MediaFile").orEmpty().mapNotNull { m ->
            val url = m.text
            if (url.isBlank()) null
            else VastMedia(
                url = url,
                mime = m.attrs["type"].orEmpty(),
                width = m.attrs["width"]?.toIntOrNull() ?: 0,
                height = m.attrs["height"]?.toIntOrNull() ?: 0,
                bitrateKbps = m.attrs["bitrate"]?.toIntOrNull(),
                delivery = m.attrs["delivery"] ?: "progressive",
            )
        }
        val tracking = node.child("TrackingEvents")?.all("Tracking").orEmpty().mapNotNull {
            val ev = it.attrs["event"]
            if (ev == null || it.text.isBlank()) null else VastTracking(ev, it.text, it.attrs["offset"])
        }
        val clicks = node.child("VideoClicks")
        return VastLinear(
            durationMs = node.child("Duration")?.text?.let { parseTimeMs(it) },
            skipOffset = node.attrs["skipoffset"],
            mediaFiles = media,
            tracking = tracking,
            clickThrough = clicks?.child("ClickThrough")?.text?.takeIf { it.isNotBlank() },
            clickTracking = clicks?.all("ClickTracking").orEmpty().map { it.text }.filter { it.isNotBlank() },
        )
    }

    private fun parseCompanion(node: XmlNode): VastCompanion? {
        val (type, resource) = when {
            node.child("HTMLResource") != null -> "html" to node.child("HTMLResource")!!.text
            node.child("StaticResource") != null -> "static" to node.child("StaticResource")!!.text
            node.child("IFrameResource") != null -> "iframe" to node.child("IFrameResource")!!.text
            else -> return null
        }
        if (resource.isBlank()) return null
        return VastCompanion(
            width = node.attrs["width"]?.toIntOrNull() ?: 0,
            height = node.attrs["height"]?.toIntOrNull() ?: 0,
            resourceType = type,
            resource = resource,
            creativeType = node.child("StaticResource")?.attrs?.get("creativeType"),
            clickThrough = node.child("CompanionClickThrough")?.text?.takeIf { it.isNotBlank() },
            clickTracking = node.all("CompanionClickTracking").map { it.text }.filter { it.isNotBlank() },
            tracking = node.child("TrackingEvents")?.all("Tracking").orEmpty().mapNotNull {
                val ev = it.attrs["event"]
                if (ev == null || it.text.isBlank()) null else VastTracking(ev, it.text, it.attrs["offset"])
            },
        )
    }

    public companion object {
        private const val MAX_CHARS = 1_000_000

        /** Parses "HH:MM:SS" or "HH:MM:SS.mmm" into milliseconds. */
        public fun parseTimeMs(value: String): Long? {
            val parts = value.trim().split(":")
            if (parts.size != 3) return null
            val h = parts[0].toLongOrNull() ?: return null
            val m = parts[1].toLongOrNull() ?: return null
            val secPart = parts[2].split(".")
            val s = secPart[0].toLongOrNull() ?: return null
            val ms = if (secPart.size > 1) secPart[1].padEnd(3, '0').take(3).toLongOrNull() ?: return null else 0L
            return ((h * 60 + m) * 60 + s) * 1000 + ms
        }
    }
}
