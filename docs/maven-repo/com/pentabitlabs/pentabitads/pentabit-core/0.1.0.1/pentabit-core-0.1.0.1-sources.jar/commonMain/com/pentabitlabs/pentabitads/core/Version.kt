package com.pentabitlabs.pentabitads.core

/** Keep in step with `pentabit.version` in gradle.properties. */
public object PentabitVersion {
    public const val VERSION: String = "0.1.0.1"
}
