@file:OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)

package com.pentabitlabs.pentabitads.ads

import com.pentabitlabs.pentabitads.core.mraid.CreativeHtml
import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.useContents
import kotlin.math.PI
import platform.CoreGraphics.CGPointMake
import platform.CoreGraphics.CGRectMake
import platform.QuartzCore.CAShapeLayer
import platform.Foundation.NSNotificationCenter
import platform.Foundation.NSOperationQueue
import platform.UIKit.UIAction
import platform.UIKit.UIApplicationDidBecomeActiveNotification
import platform.UIKit.UIApplicationWillResignActiveNotification
import platform.UIKit.UIButton
import platform.UIKit.UIButtonTypeCustom
import platform.UIKit.UIColor
import platform.UIKit.UIControlEventTouchUpInside
import platform.UIKit.UIFont
import platform.UIKit.UILabel
import platform.UIKit.NSTextAlignmentCenter
import platform.UIKit.UIBezierPath
import platform.UIKit.accessibilityLabel
import platform.UIKit.modalInPresentation
import platform.UIKit.UIControlStateNormal
import platform.UIKit.UIModalPresentationFullScreen
import platform.UIKit.UIViewController

/**
 * The full-screen host for interstitial, rewarded and app open ads. It only draws: every decision
 * lives in [AdScreenModel]. Requires iOS 14 or later (UIAction).
 */
internal class PentabitAdViewController(private val model: AdScreenModel) : UIViewController(nibName = null, bundle = null) {
    private var web: IosAdWebView? = null
    private var player: IosVideoPlayer? = null
    private var closeButton: UIButton? = null
    private var infoButton: UIButton? = null
    private var videoTap: UIButton? = null
    private var simidWeb: IosAdWebView? = null
    private var ringLayer: CAShapeLayer? = null
    private var rewardLabel: UILabel? = null
    private var rewardCard: UIButton? = null
    private val observers = mutableListOf<Any>()

    init {
        modalPresentationStyle = UIModalPresentationFullScreen
        modalInPresentation = true
    }

    override fun prefersStatusBarHidden(): Boolean = true

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.blackColor
        if (model.isFinished) {
            dismissViewControllerAnimated(false, null)
            return
        }
        model.onDismiss = { dismissViewControllerAnimated(true, null) }
        model.onCloseAvailable = {
            closeButton?.setTitle("✕", forState = UIControlStateNormal)
            closeButton?.accessibilityLabel = "Close ad"
            ringLayer?.setHidden(true)
        }
        model.onCountdown = { fraction, secs ->
            if (!model.closeAvailable) {
                closeButton?.setTitle(secs.toString(), forState = UIControlStateNormal)
                ringLayer?.strokeEnd = fraction.toDouble()
            }
        }
        model.onShowEndCard = { showEndCard() }
        addRewardUi()
        addCloseButton()
        if (model.isVideo) startVideo() else startWeb()
        observeAppState()
    }

    private fun startWeb() {
        val w = IosAdWebView(model)
        web = w
        w.view.setFrame(view.bounds)
        view.insertSubview(w.view, atIndex = 0)
        if (!w.showMain()) model.onContentError("the creative has no content")
    }

    private fun startVideo() {
        val factory = IosVideoSupport.factory
        val file = model.ad.videoAsset?.path
        if (factory == null || file == null) {
            model.onContentError("video playback is not available")
            return
        }
        val p = factory.create(file, model.videoListener)
        player = p
        p.view.setFrame(view.bounds)
        view.insertSubview(p.view, atIndex = 0)
        // Tapping the video, or the install button, follows the VAST ClickThrough.
        val tap = UIButton.buttonWithType(UIButtonTypeCustom)
        tap.addAction(UIAction.actionWithHandler { _ -> model.onVideoClick() }, forControlEvents = UIControlEventTouchUpInside)
        videoTap = tap
        view.insertSubview(tap, atIndex = 1)
        if (model.hasSimid) addSimidOverlay()
        p.play()
    }

    /** The SIMID overlay: a transparent web view over the bottom band of the video. It stays hidden until the creative says it is ready. */
    private fun addSimidOverlay() {
        val w = IosAdWebView(model)
        simidWeb = w
        w.view.setHidden(true)
        model.onSimidShow = { simidWeb?.view?.setHidden(false) }
        model.onSimidRemove = { removeSimid() }
        view.insertSubview(w.view, atIndex = 2)
        var width = 0.0; var height = 0.0
        view.bounds.useContents { width = size.width; height = size.height }
        model.configureSimid("$IOS_ASSET_SCHEME://${CreativeHtml.ASSET_HOST}/", width.toInt(), height.toInt(), 120)
        w.showSimid()
    }

    private fun removeSimid() {
        simidWeb?.dispose()
        simidWeb = null
    }

    private fun showEndCard() {
        model.endSimid()
        removeSimid()
        videoTap?.removeFromSuperview(); videoTap = null
        player?.release()
        player?.view?.removeFromSuperview()
        player = null
        val w = IosAdWebView(model)
        web = w
        w.view.setFrame(view.bounds)
        view.insertSubview(w.view, atIndex = 0)
        if (!w.showEndCard()) model.userClose()
    }

    /** Rewarded ads: the countdown ring shows the time left; a "Reward granted" button to continue appears when it is earned. */
    private fun addRewardUi() {
        if (!model.isRewarded) return
        val l = UILabel()
        l.textColor = UIColor.whiteColor
        l.font = UIFont.systemFontOfSize(13.0)
        l.textAlignment = NSTextAlignmentCenter
        l.backgroundColor = UIColor.blackColor.colorWithAlphaComponent(0.6)
        l.layer.cornerRadius = 14.0
        l.layer.masksToBounds = true
        l.setHidden(true)
        val card = UIButton.buttonWithType(UIButtonTypeCustom)
        card.titleLabel?.numberOfLines = 0
        card.setTitleColor(UIColor.whiteColor, forState = UIControlStateNormal)
        card.titleLabel?.font = UIFont.boldSystemFontOfSize(18.0)
        card.backgroundColor = UIColor.blackColor.colorWithAlphaComponent(0.8)
        card.layer.cornerRadius = 16.0
        card.setHidden(true)
        card.addAction(UIAction.actionWithHandler { _ -> model.userClose() }, forControlEvents = UIControlEventTouchUpInside)
        rewardLabel = l; rewardCard = card
        view.addSubview(l); view.addSubview(card)
        model.onReward = { _, text, granted ->
            if (granted && !model.hasEndCard) {
                l.setHidden(true)
                card.setTitle(text + "\nTap to continue", forState = UIControlStateNormal)
                card.setHidden(false)
            } else if (granted || !text.startsWith("Reward in")) { // the ring already shows the countdown
                l.text = text
                l.setHidden(false)
            }
        }
    }

    /** The countdown ring in the top corner; it becomes the close mark when the ad can be closed. */
    private fun addCloseButton() {
        val b = UIButton.buttonWithType(UIButtonTypeCustom)
        b.setTitle(if (model.closeAvailable) "✕" else "", forState = UIControlStateNormal)
        b.setTitleColor(UIColor.whiteColor, forState = UIControlStateNormal)
        b.titleLabel?.font = UIFont.boldSystemFontOfSize(if (model.closeAvailable) 20.0 else 15.0)
        b.backgroundColor = UIColor.blackColor.colorWithAlphaComponent(0.6)
        b.layer.cornerRadius = 22.0
        b.accessibilityLabel = if (model.closeAvailable) "Close ad" else "Ad closes in a moment"
        b.addAction(UIAction.actionWithHandler { _ -> if (model.closeAvailable) model.userClose() }, forControlEvents = UIControlEventTouchUpInside)
        val ring = CAShapeLayer()
        ring.path = UIBezierPath.bezierPathWithArcCenter(CGPointMake(22.0, 22.0), radius = 19.5, startAngle = -PI / 2.0, endAngle = 3.0 * PI / 2.0, clockwise = true).CGPath
        ring.fillColor = null
        ring.strokeColor = UIColor.whiteColor.CGColor
        ring.lineWidth = 2.5
        ring.strokeEnd = 0.0
        ring.setHidden(model.closeAvailable)
        b.layer.addSublayer(ring)
        ringLayer = ring
        closeButton = b
        view.addSubview(b)
        if (model.isVideo) {
            val i = UIButton.buttonWithType(UIButtonTypeCustom)
            i.setTitle("i", forState = UIControlStateNormal)
            i.setTitleColor(UIColor.whiteColor, forState = UIControlStateNormal)
            i.titleLabel?.font = UIFont.italicSystemFontOfSize(12.0)
            i.backgroundColor = UIColor.blackColor.colorWithAlphaComponent(0.4)
            i.layer.cornerRadius = 11.0
            i.layer.borderWidth = 1.0
            i.layer.borderColor = UIColor.whiteColor.colorWithAlphaComponent(0.85).CGColor
            i.accessibilityLabel = "Ad info and privacy policy"
            i.addAction(UIAction.actionWithHandler { _ -> model.openPrivacyPolicy() }, forControlEvents = UIControlEventTouchUpInside)
            infoButton = i
            view.addSubview(i)
        }
    }

    override fun viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        val width = view.bounds.useContents { size.width }
        var top = 0.0
        var right = 0.0
        view.safeAreaInsets.useContents { top = this.top; right = this.right }
        closeButton?.setFrame(CGRectMake(width - 44.0 - 12.0 - right, top + 12.0, 44.0, 44.0))
        videoTap?.setFrame(view.bounds)
        simidWeb?.view?.setFrame(CGRectMake(0.0, view.bounds.useContents { size.height } - 120.0, width, 120.0))
        rewardLabel?.setFrame(CGRectMake(12.0, top + 16.0, 280.0, 28.0))
        rewardCard?.setFrame(CGRectMake(width / 2.0 - 130.0, view.bounds.useContents { size.height } - 230.0, 260.0, 90.0))
        rewardLabel?.let { view.bringSubviewToFront(it) }; rewardCard?.let { view.bringSubviewToFront(it) }
        var bottom = 0.0
        var left = 0.0
        view.safeAreaInsets.useContents { bottom = this.bottom; left = this.left }
        val height = view.bounds.useContents { size.height }
        infoButton?.let { it.setFrame(CGRectMake(left + 12.0, height - bottom - 34.0, 22.0, 22.0)); view.bringSubviewToFront(it) }
        view.bringSubviewToFront(closeButton ?: return)
    }

    private fun observeAppState() {
        val center = NSNotificationCenter.defaultCenter
        observers += center.addObserverForName(UIApplicationWillResignActiveNotification, null, NSOperationQueue.mainQueue) { _ ->
            model.exposurePercent = 0.0
            player?.pause()
        }
        observers += center.addObserverForName(UIApplicationDidBecomeActiveNotification, null, NSOperationQueue.mainQueue) { _ ->
            model.exposurePercent = 100.0
            player?.play()
        }
    }

    override fun viewDidAppear(animated: Boolean) {
        super.viewDidAppear(animated)
        model.exposurePercent = 100.0
    }

    override fun viewWillDisappear(animated: Boolean) {
        model.exposurePercent = 0.0
        super.viewWillDisappear(animated)
    }

    override fun viewDidDisappear(animated: Boolean) {
        super.viewDidDisappear(animated)
        if (isBeingDismissed() || isMovingFromParentViewController()) cleanup()
    }

    private fun cleanup() {
        simidWeb?.dispose()
        observers.forEach { NSNotificationCenter.defaultCenter.removeObserver(it) }
        observers.clear()
        web?.dispose()
        player?.release()
        model.onScreenGone()
    }
}
