package com.pentabitlabs.pentabitads.platform

import okio.FileSystem

/** `FileSystem.SYSTEM` is not visible from common code, so each platform supplies it. */
internal expect fun systemFileSystem(): FileSystem
