package com.pentabitlabs.pentabitads.platform

import com.pentabitlabs.pentabitads.core.concurrency.DefaultDispatcherProvider
import com.pentabitlabs.pentabitads.core.concurrency.DispatcherProvider
import com.pentabitlabs.pentabitads.core.ports.AssetStore
import com.pentabitlabs.pentabitads.core.ports.Clock
import com.pentabitlabs.pentabitads.core.ports.ConnectivityMonitor
import com.pentabitlabs.pentabitads.core.ports.DeviceInfo
import com.pentabitlabs.pentabitads.core.ports.EventStore
import com.pentabitlabs.pentabitads.core.ports.HttpClientPort
import com.pentabitlabs.pentabitads.core.ports.IdGenerator
import com.pentabitlabs.pentabitads.core.ports.KeyValueStore
import com.pentabitlabs.pentabitads.core.ports.Logger
import com.pentabitlabs.pentabitads.core.ports.PlatformModule
import com.pentabitlabs.pentabitads.core.util.SystemIds
import com.pentabitlabs.pentabitads.platform.db.PentabitDatabase
import okio.Path.Companion.toPath

private class SystemClock : com.pentabitlabs.pentabitads.core.ports.Clock {
    override fun nowMillis(): Long = currentTimeMillis()
}

private class RealPlatformModule(
    override val clock: Clock,
    override val ids: IdGenerator,
    override val logger: Logger,
    override val http: HttpClientPort,
    override val keyValueStore: KeyValueStore,
    override val eventStore: EventStore,
    override val assetStore: AssetStore,
    override val connectivity: ConnectivityMonitor,
    override val deviceInfo: DeviceInfo,
    override val dispatchers: DispatcherProvider,
) : PlatformModule

/**
 * Builds every platform implementation. [storeName] names the on-device database, so two Pentabit SDKs in one app keep separate queues.
 * A database that cannot be opened never stops the SDK:
 * events fall back to memory for this run.
 */
public fun createPlatformModule(context: PlatformContext, debug: Boolean = false, storeName: String = "pentabit_ads"): PlatformModule {
    val logger = createLogger(debug)
    val clock = SystemClock()
    val ids = SystemIds
    val httpClient = createHttpClient()

    val db: PentabitDatabase? = try {
        PentabitDatabase(createSqlDriver(context, "$storeName.db"))
    } catch (e: Throwable) {
        logger.error("PentabitPlatform", "database unavailable, using memory storage for this run", e)
        null
    }

    val kv: KeyValueStore = if (db != null) SqlKeyValueStore(db) else MemoryKeyValueStore()
    val events: EventStore = FallbackEventStore(
        primary = db?.let { SqlEventStore(it) },
        fallback = MemoryEventStore(),
        logger = logger,
    )
    val dir = cacheDirectory(context).toPath().resolve("aks-assets")
    val assets = FileAssetStore(httpClient, systemFileSystem(), dir, logger)

    return RealPlatformModule(
        clock = clock,
        ids = ids,
        logger = logger,
        http = KtorHttpClient(httpClient),
        keyValueStore = kv,
        eventStore = events,
        assetStore = assets,
        connectivity = createConnectivityMonitor(context),
        deviceInfo = createDeviceInfo(context, kv, ids),
        dispatchers = DefaultDispatcherProvider(),
    )
}
