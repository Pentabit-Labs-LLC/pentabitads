package com.pentabitlabs.pentabitads.platform.db

import app.cash.sqldelight.ExecutableQuery
import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class PentabitQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> selectBatch(`value`: Long, mapper: (
    id: String,
    created_at: Long,
    payload: String,
  ) -> T): Query<T> = SelectBatchQuery(value) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getLong(1)!!,
      cursor.getString(2)!!
    )
  }

  public fun selectBatch(value_: Long): Query<Event> = selectBatch(value_) { id, created_at,
      payload ->
    Event(
      id,
      created_at,
      payload
    )
  }

  public fun countEvents(): Query<Long> = Query(601_035_833, arrayOf("event"), driver,
      "Pentabit.sq", "countEvents", "SELECT COUNT(*) FROM event") { cursor ->
    cursor.getLong(0)!!
  }

  public fun changes(): ExecutableQuery<Long> = Query(1_586_880_628, driver, "Pentabit.sq",
      "changes", "SELECT changes()") { cursor ->
    cursor.getLong(0)!!
  }

  public fun selectKv(k: String): Query<String> = SelectKvQuery(k) { cursor ->
    cursor.getString(0)!!
  }

  /**
   * @return The number of rows updated.
   */
  public fun insertEvent(
    id: String,
    created_at: Long,
    payload: String,
  ): QueryResult<Long> {
    val result = driver.execute(-1_053_898_606,
        """INSERT OR IGNORE INTO event(id, created_at, payload) VALUES (?, ?, ?)""", 3) {
          bindString(0, id)
          bindLong(1, created_at)
          bindString(2, payload)
        }
    notifyQueries(-1_053_898_606) { emit ->
      emit("event")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteEvent(id: String): QueryResult<Long> {
    val result = driver.execute(-2_072_572_704, """DELETE FROM event WHERE id = ?""", 1) {
          bindString(0, id)
        }
    notifyQueries(-2_072_572_704) { emit ->
      emit("event")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteOlderThan(created_at: Long): QueryResult<Long> {
    val result = driver.execute(-1_643_123_685, """DELETE FROM event WHERE created_at < ?""", 1) {
          bindLong(0, created_at)
        }
    notifyQueries(-1_643_123_685) { emit ->
      emit("event")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun trimTo(`value`: Long): QueryResult<Long> {
    val result = driver.execute(1_655_735_916,
        """DELETE FROM event WHERE id NOT IN (SELECT id FROM event ORDER BY created_at DESC LIMIT ?)""",
        1) {
          bindLong(0, value)
        }
    notifyQueries(1_655_735_916) { emit ->
      emit("event")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun upsertKv(k: String, v: String): QueryResult<Long> {
    val result = driver.execute(-2_023_044_247, """INSERT OR REPLACE INTO kv(k, v) VALUES (?, ?)""",
        2) {
          bindString(0, k)
          bindString(1, v)
        }
    notifyQueries(-2_023_044_247) { emit ->
      emit("kv")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteKv(k: String): QueryResult<Long> {
    val result = driver.execute(1_335_953_637, """DELETE FROM kv WHERE k = ?""", 1) {
          bindString(0, k)
        }
    notifyQueries(1_335_953_637) { emit ->
      emit("kv")
    }
    return result
  }

  private inner class SelectBatchQuery<out T : Any>(
    public val `value`: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("event", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("event", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> =
        driver.executeQuery(-738_677_553,
        """SELECT id, created_at, payload FROM event ORDER BY created_at ASC LIMIT ?""", mapper, 1)
        {
      bindLong(0, value)
    }

    override fun toString(): String = "Pentabit.sq:selectBatch"
  }

  private inner class SelectKvQuery<out T : Any>(
    public val k: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("kv", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("kv", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> =
        driver.executeQuery(1_707_812_854, """SELECT v FROM kv WHERE k = ?""", mapper, 1) {
      bindString(0, k)
    }

    override fun toString(): String = "Pentabit.sq:selectKv"
  }
}
