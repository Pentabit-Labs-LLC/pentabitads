package com.pentabitlabs.pentabitads.platform

import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.driver.native.NativeSqliteDriver
import com.pentabitlabs.pentabitads.core.ports.ConnectivityMonitor
import com.pentabitlabs.pentabitads.core.ports.DeviceInfo
import com.pentabitlabs.pentabitads.core.ports.IdGenerator
import com.pentabitlabs.pentabitads.core.ports.KeyValueStore
import com.pentabitlabs.pentabitads.core.ports.Logger
import com.pentabitlabs.pentabitads.platform.db.PentabitDatabase
import io.ktor.client.HttpClient
import io.ktor.client.engine.darwin.Darwin
import platform.AdSupport.ASIdentifierManager
import platform.AppTrackingTransparency.ATTrackingManager
import platform.AppTrackingTransparency.ATTrackingManagerAuthorizationStatusAuthorized
import platform.Foundation.NSBundle
import platform.Foundation.NSCachesDirectory
import platform.Foundation.NSDate
import platform.Foundation.NSLocale
import platform.Foundation.NSLog
import platform.Foundation.NSProcessInfo
import platform.Foundation.NSSearchPathForDirectoriesInDomains
import platform.Foundation.NSUserDomainMask
import platform.Foundation.countryCode
import platform.Foundation.currentLocale
import platform.Foundation.isLowPowerModeEnabled
import platform.Foundation.languageCode
import platform.Foundation.timeIntervalSince1970
import platform.UIKit.UIDevice
import platform.UIKit.UIUserInterfaceIdiomPad

public actual class PlatformContext

internal actual fun currentTimeMillis(): Long = (NSDate().timeIntervalSince1970 * 1000.0).toLong()

internal actual fun createHttpClient(): HttpClient = HttpClient(Darwin) { pentabitDefaults() }

internal actual fun createSqlDriver(context: PlatformContext, name: String): SqlDriver = NativeSqliteDriver(PentabitDatabase.Schema, name)

internal actual fun cacheDirectory(context: PlatformContext): String =
    (NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, true).firstOrNull() as? String) ?: "/tmp"

internal actual fun createLogger(debug: Boolean): Logger = object : Logger {
    override fun debug(tag: String, message: String) { if (debug) NSLog("[$tag] $message") }
    override fun warn(tag: String, message: String, error: Throwable?) { NSLog("[$tag] WARN $message ${error?.message ?: ""}") }
    override fun error(tag: String, message: String, error: Throwable?) { NSLog("[$tag] ERROR $message ${error?.message ?: ""}") }
}

/**
 * Reachability is not checked on iOS in this version, so the monitor always reports online and
 * the request itself fails fast when there is no connection. A NWPathMonitor-based monitor is a
 * planned improvement.
 */
internal actual fun createConnectivityMonitor(context: PlatformContext): ConnectivityMonitor = object : ConnectivityMonitor {
    override fun isOnline(): Boolean = true
}

internal actual fun createDeviceInfo(context: PlatformContext, store: KeyValueStore, ids: IdGenerator): DeviceInfo =
    IosDeviceInfo(store, ids)

private class IosDeviceInfo(private val store: KeyValueStore, private val ids: IdGenerator) : DeviceInfo {
    override val platform: String = "ios"
    override val osVersion: String = UIDevice.currentDevice.systemVersion
    override val deviceClass: String = if (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad) "tablet" else "phone"
    override val appId: String = NSBundle.mainBundle.bundleIdentifier ?: "unknown"
    override val appVersion: String = (NSBundle.mainBundle.infoDictionary?.get("CFBundleShortVersionString") as? String) ?: "0"
    override val country: String? = NSLocale.currentLocale.countryCode
    override val language: String? = NSLocale.currentLocale.languageCode
    override val isLowPowerMode: Boolean get() = NSProcessInfo.processInfo.isLowPowerModeEnabled()

    /** Only when the user allowed tracking (ATT). The SDK never shows the ATT prompt itself. */
    override suspend fun advertisingId(): String? {
        if (ATTrackingManager.trackingAuthorizationStatus != ATTrackingManagerAuthorizationStatusAuthorized) return null
        val id = ASIdentifierManager.sharedManager().advertisingIdentifier.UUIDString
        return if (id.all { it == '0' || it == '-' }) null else id
    }

    override suspend fun deviceId(): String? = UIDevice.currentDevice.identifierForVendor?.UUIDString

    override suspend fun appInstanceId(): String {
        store.getString(KEY)?.let { return it }
        val id = ids.newId()
        store.putString(KEY, id)
        return id
    }

    private companion object { const val KEY = "aks.instance_id" }
}
