package com.pentabitlabs.pentabitads.platform

import com.pentabitlabs.pentabitads.core.ports.HttpClientPort
import com.pentabitlabs.pentabitads.core.ports.HttpRequest
import com.pentabitlabs.pentabitads.core.ports.HttpResponse
import com.pentabitlabs.pentabitads.core.ports.NetworkException
import io.ktor.client.HttpClient
import io.ktor.client.plugins.HttpRequestTimeoutException
import io.ktor.client.plugins.timeout
import io.ktor.client.request.header
import io.ktor.client.request.request
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpMethod
import kotlin.coroutines.cancellation.CancellationException

internal class KtorHttpClient(private val client: HttpClient) : HttpClientPort {
    override suspend fun execute(request: HttpRequest): HttpResponse =
        try {
            val response = client.request(request.url) {
                method = HttpMethod.parse(request.method)
                for ((k, v) in request.headers) header(k, v)
                if (request.body != null) setBody(request.body)
                timeout {
                    requestTimeoutMillis = request.timeoutMillis
                    connectTimeoutMillis = minOf(request.timeoutMillis, 10_000L)
                    socketTimeoutMillis = request.timeoutMillis
                }
            }
            val headers = HashMap<String, String>()
            for ((name, values) in response.headers.entries()) headers[name.lowercase()] = values.joinToString(",")
            HttpResponse(response.status.value, headers, response.bodyAsText())
        } catch (e: CancellationException) {
            throw e
        } catch (e: HttpRequestTimeoutException) {
            throw NetworkException(NetworkException.Kind.TIMEOUT, "request timed out")
        } catch (e: Throwable) {
            val name = e::class.simpleName.orEmpty()
            val kind = if (name.contains("Timeout")) NetworkException.Kind.TIMEOUT else NetworkException.Kind.NO_CONNECTION
            throw NetworkException(kind, e.message ?: name)
        }
}
