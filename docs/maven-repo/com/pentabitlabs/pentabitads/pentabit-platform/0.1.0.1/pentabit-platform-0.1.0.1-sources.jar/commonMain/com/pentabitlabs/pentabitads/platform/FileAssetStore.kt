package com.pentabitlabs.pentabitads.platform

import com.pentabitlabs.pentabitads.core.error.AdErrorCode
import com.pentabitlabs.pentabitads.core.error.AdResult
import com.pentabitlabs.pentabitads.core.error.failure
import com.pentabitlabs.pentabitads.core.ports.AssetStore
import com.pentabitlabs.pentabitads.core.ports.CachedAsset
import com.pentabitlabs.pentabitads.core.ports.Logger
import io.ktor.client.HttpClient
import io.ktor.client.request.prepareGet
import io.ktor.client.statement.bodyAsChannel
import io.ktor.utils.io.ByteReadChannel
import io.ktor.utils.io.readAvailable
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okio.FileSystem
import okio.HashingSink
import okio.Path
import okio.buffer
import kotlin.coroutines.cancellation.CancellationException

/**
 * Asset cache on disk. Files are named by a sanitised key, written to a temp file and renamed
 * only when complete, so a partial download is never mistaken for an asset. Downloads stream, so
 * a large video never sits in memory.
 */
internal class FileAssetStore(
    private val client: HttpClient,
    private val fs: FileSystem,
    private val dir: Path,
    private val logger: Logger,
) : AssetStore {
    private val mutex = Mutex()

    // How many loaded ads use each cached file. Two ads can load the same picture (three banners of one campaign), and the file may only
    // be deleted when the last of them is released.
    private val users = HashMap<String, Int>()
    private suspend fun retain(key: String) = mutex.withLock { users[key] = (users[key] ?: 0) + 1 }

    override suspend fun download(url: String, key: String, maxBytes: Long, sha256: String?): AdResult<CachedAsset> {
        if (!(url.startsWith("https://") || url.startsWith("http://"))) {
            return failure(AdErrorCode.ASSET_FAILED, "asset URL must be http or https")
        }
        val target = pathFor(key)
        val tmp = dir.resolve(target.name + ".tmp")
        return try {
            fs.createDirectories(dir)
            existing(key)?.let { retain(key); return AdResult.Success(it) }
            var written = 0L
            var hash: String? = null
            var failed: String? = null

            client.prepareGet(url).execute { response ->
                if (response.status.value !in 200..299) { failed = "HTTP ${response.status.value}"; return@execute }
                val declared = response.headers["Content-Length"]?.toLongOrNull()
                if (declared != null && declared > maxBytes) { failed = "asset larger than the limit"; return@execute }
                val channel: ByteReadChannel = response.bodyAsChannel()
                val hashing = HashingSink.sha256(fs.sink(tmp))
                val sink = hashing.buffer()
                val buf = ByteArray(16 * 1024)
                while (true) {
                    val n = channel.readAvailable(buf, 0, buf.size)
                    if (n < 0) break
                    if (n == 0) continue
                    written += n
                    if (written > maxBytes) { failed = "asset larger than the limit"; break }
                    sink.write(buf, 0, n)
                }
                sink.close()
                hash = hashing.hash.hex()
            }

            if (failed != null) { fs.delete(tmp); return failure(AdErrorCode.ASSET_FAILED, failed!!) }
            if (written == 0L) { fs.delete(tmp); return failure(AdErrorCode.ASSET_FAILED, "empty asset") }
            if (sha256 != null && !sha256.equals(hash, ignoreCase = true)) {
                fs.delete(tmp)
                return failure(AdErrorCode.ASSET_FAILED, "asset hash mismatch")
            }
            mutex.withLock { fs.atomicMove(tmp, target) }
            retain(key)
            AdResult.Success(CachedAsset(key, target.toString(), written))
        } catch (e: CancellationException) {
            runCatching { fs.delete(tmp) }
            throw e
        } catch (e: Throwable) {
            runCatching { fs.delete(tmp) }
            logger.warn("PentabitAssets", "download failed", e)
            failure(AdErrorCode.ASSET_FAILED, e.message ?: "download failed")
        }
    }

    override suspend fun get(key: String): CachedAsset? = existing(key)

    override suspend fun release(key: String) {
        mutex.withLock {
            val left = (users[key] ?: 1) - 1
            if (left > 0) users[key] = left else { users.remove(key); runCatching { fs.delete(pathFor(key)) } }
        }
    }

    /** Removes the oldest files until the cache fits in [maxBytes]. */
    override suspend fun trimTo(maxBytes: Long) {
        mutex.withLock {
            if (!fs.exists(dir)) return
            val files = fs.list(dir).mapNotNull { p ->
                val m = fs.metadataOrNull(p) ?: return@mapNotNull null
                if (m.isDirectory) null else Triple(p, m.size ?: 0L, m.lastModifiedAtMillis ?: 0L)
            }.sortedBy { it.third }
            var total = files.sumOf { it.second }
            for ((p, size, _) in files) {
                if (total <= maxBytes) break
                runCatching { fs.delete(p) }
                total -= size
            }
        }
    }

    private fun existing(key: String): CachedAsset? {
        val p = pathFor(key)
        val m = fs.metadataOrNull(p) ?: return null
        val size = m.size ?: return null
        return if (size > 0) CachedAsset(key, p.toString(), size) else null
    }

    private fun pathFor(key: String): Path {
        val safe = key.map { if (it.isLetterOrDigit() || it == '.' || it == '-' || it == '_') it else '_' }.joinToString("").take(80)
        return dir.resolve("$safe-${key.hashCode().toUInt().toString(16)}")
    }
}
