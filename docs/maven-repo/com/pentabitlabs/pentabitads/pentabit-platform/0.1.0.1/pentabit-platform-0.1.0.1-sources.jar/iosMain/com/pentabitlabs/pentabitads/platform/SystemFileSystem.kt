package com.pentabitlabs.pentabitads.platform

import okio.FileSystem

internal actual fun systemFileSystem(): FileSystem = FileSystem.SYSTEM
