package com.pentabitlabs.pentabitads.platform.db

import kotlin.Long
import kotlin.String

public data class Event(
  public val id: String,
  public val created_at: Long,
  public val payload: String,
)
