package com.pentabitlabs.pentabitads.platform.db

import kotlin.String

public data class Kv(
  public val k: String,
  public val v: String,
)
