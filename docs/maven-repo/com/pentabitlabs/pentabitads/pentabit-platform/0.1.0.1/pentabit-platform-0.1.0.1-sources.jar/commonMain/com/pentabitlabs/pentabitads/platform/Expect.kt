package com.pentabitlabs.pentabitads.platform

import app.cash.sqldelight.db.SqlDriver
import com.pentabitlabs.pentabitads.core.ports.ConnectivityMonitor
import com.pentabitlabs.pentabitads.core.ports.DeviceInfo
import com.pentabitlabs.pentabitads.core.ports.IdGenerator
import com.pentabitlabs.pentabitads.core.ports.KeyValueStore
import com.pentabitlabs.pentabitads.core.ports.Logger
import io.ktor.client.HttpClient

/** Android: wraps the application Context. iOS: nothing is needed. */
public expect class PlatformContext

internal expect fun currentTimeMillis(): Long
internal expect fun createHttpClient(): HttpClient
internal expect fun createSqlDriver(context: PlatformContext, name: String): SqlDriver
internal expect fun cacheDirectory(context: PlatformContext): String
internal expect fun createLogger(debug: Boolean): Logger
internal expect fun createConnectivityMonitor(context: PlatformContext): ConnectivityMonitor
internal expect fun createDeviceInfo(context: PlatformContext, store: KeyValueStore, ids: IdGenerator): DeviceInfo
