package com.pentabitlabs.pentabitads.platform.db.pentabitplatform

import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.AfterVersion
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.pentabitlabs.pentabitads.platform.db.PentabitDatabase
import com.pentabitlabs.pentabitads.platform.db.PentabitQueries
import kotlin.Long
import kotlin.Unit
import kotlin.reflect.KClass

internal val KClass<PentabitDatabase>.schema: SqlSchema<QueryResult.Value<Unit>>
  get() = PentabitDatabaseImpl.Schema

internal fun KClass<PentabitDatabase>.newInstance(driver: SqlDriver): PentabitDatabase =
    PentabitDatabaseImpl(driver)

private class PentabitDatabaseImpl(
  driver: SqlDriver,
) : TransacterImpl(driver),
    PentabitDatabase {
  override val pentabitQueries: PentabitQueries = PentabitQueries(driver)

  public object Schema : SqlSchema<QueryResult.Value<Unit>> {
    override val version: Long
      get() = 1

    override fun create(driver: SqlDriver): QueryResult.Value<Unit> {
      driver.execute(null, """
          |CREATE TABLE event (
          |    id TEXT NOT NULL PRIMARY KEY,
          |    created_at INTEGER NOT NULL,
          |    payload TEXT NOT NULL
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE kv (
          |    k TEXT NOT NULL PRIMARY KEY,
          |    v TEXT NOT NULL
          |)
          """.trimMargin(), 0)
      driver.execute(null, "CREATE INDEX event_created_at ON event(created_at)", 0)
      return QueryResult.Unit
    }

    override fun migrate(
      driver: SqlDriver,
      oldVersion: Long,
      newVersion: Long,
      vararg callbacks: AfterVersion,
    ): QueryResult.Value<Unit> = QueryResult.Unit
  }
}
