package com.pentabitlabs.pentabitads.platform

import io.ktor.client.HttpClientConfig
import io.ktor.client.plugins.HttpTimeout

internal fun HttpClientConfig<*>.pentabitDefaults() {
    install(HttpTimeout)
    expectSuccess = false
    followRedirects = true
}
