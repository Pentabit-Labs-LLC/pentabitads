package com.pentabitlabs.pentabitads.platform

import com.pentabitlabs.pentabitads.core.ports.EventStore
import com.pentabitlabs.pentabitads.core.ports.KeyValueStore
import com.pentabitlabs.pentabitads.core.ports.Logger
import com.pentabitlabs.pentabitads.core.ports.StoredEvent
import com.pentabitlabs.pentabitads.platform.db.PentabitDatabase
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** One writer at a time. Reads share the same lock because the queue is small and operations are short. */
internal class SqlEventStore(private val db: PentabitDatabase) : EventStore {
    private val mutex = Mutex()
    private val q get() = db.pentabitQueries

    override suspend fun insert(events: List<StoredEvent>) = mutex.withLock {
        q.transaction { for (e in events) q.insertEvent(e.id, e.createdAtMillis, e.payload) }
    }

    override suspend fun readBatch(limit: Int): List<StoredEvent> = mutex.withLock {
        q.selectBatch(limit.toLong()).executeAsList().map { StoredEvent(it.id, it.created_at, it.payload) }
    }

    override suspend fun delete(ids: List<String>) = mutex.withLock {
        q.transaction { for (id in ids) q.deleteEvent(id) }
    }

    override suspend fun count(): Long = mutex.withLock { q.countEvents().executeAsOne() }

    override suspend fun deleteOlderThan(timestampMillis: Long): Int = mutex.withLock {
        q.transactionWithResult {
            q.deleteOlderThan(timestampMillis)
            q.changes().executeAsOne().toInt()
        }
    }

    override suspend fun trimTo(maxCount: Int): Int = mutex.withLock {
        q.transactionWithResult {
            q.trimTo(maxCount.toLong())
            q.changes().executeAsOne().toInt()
        }
    }
}

internal class SqlKeyValueStore(private val db: PentabitDatabase) : KeyValueStore {
    private val mutex = Mutex()
    override suspend fun getString(key: String): String? = mutex.withLock { db.pentabitQueries.selectKv(key).executeAsOneOrNull() }
    override suspend fun putString(key: String, value: String) { mutex.withLock { db.pentabitQueries.upsertKv(key, value) } }
    override suspend fun remove(key: String) { mutex.withLock { db.pentabitQueries.deleteKv(key) } }
}

internal class MemoryKeyValueStore : KeyValueStore {
    private val map = HashMap<String, String>()
    override suspend fun getString(key: String): String? = map[key]
    override suspend fun putString(key: String, value: String) { map[key] = value }
    override suspend fun remove(key: String) { map.remove(key) }
}

internal class MemoryEventStore : EventStore {
    private val mutex = Mutex()
    private val rows = ArrayList<StoredEvent>()
    override suspend fun insert(events: List<StoredEvent>) = mutex.withLock {
        for (e in events) if (rows.none { it.id == e.id }) rows += e
    }
    override suspend fun readBatch(limit: Int): List<StoredEvent> = mutex.withLock { rows.sortedBy { it.createdAtMillis }.take(limit) }
    override suspend fun delete(ids: List<String>) = mutex.withLock { rows.removeAll { it.id in ids }; Unit }
    override suspend fun count(): Long = mutex.withLock { rows.size.toLong() }
    override suspend fun deleteOlderThan(timestampMillis: Long): Int = mutex.withLock {
        val before = rows.size
        rows.removeAll { it.createdAtMillis < timestampMillis }
        before - rows.size
    }
    override suspend fun trimTo(maxCount: Int): Int = mutex.withLock {
        if (rows.size <= maxCount) return@withLock 0
        val keep = rows.sortedByDescending { it.createdAtMillis }.take(maxCount).map { it.id }.toSet()
        val before = rows.size
        rows.removeAll { it.id !in keep }
        before - rows.size
    }
}

/**
 * Uses the database while it works. After the first database error it switches to memory for the
 * rest of the run, so events are never lost to a corrupt file and the SDK keeps running.
 */
internal class FallbackEventStore(
    private val primary: EventStore?,
    private val fallback: EventStore,
    private val logger: Logger,
) : EventStore {
    private var degraded = primary == null

    private suspend fun <T> run(block: suspend (EventStore) -> T): T {
        val p = primary
        if (p == null || degraded) return block(fallback)
        return try {
            block(p)
        } catch (e: kotlin.coroutines.cancellation.CancellationException) {
            throw e
        } catch (e: Throwable) {
            degraded = true
            logger.error("PentabitStorage", "event database failed, using memory for this run", e)
            block(fallback)
        }
    }

    override suspend fun insert(events: List<StoredEvent>) = run { it.insert(events) }
    override suspend fun readBatch(limit: Int) = run { it.readBatch(limit) }
    override suspend fun delete(ids: List<String>) = run { it.delete(ids) }
    override suspend fun count() = run { it.count() }
    override suspend fun deleteOlderThan(timestampMillis: Long) = run { it.deleteOlderThan(timestampMillis) }
    override suspend fun trimTo(maxCount: Int) = run { it.trimTo(maxCount) }
}
