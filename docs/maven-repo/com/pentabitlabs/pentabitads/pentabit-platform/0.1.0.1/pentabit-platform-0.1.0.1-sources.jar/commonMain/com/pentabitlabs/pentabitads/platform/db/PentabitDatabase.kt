package com.pentabitlabs.pentabitads.platform.db

import app.cash.sqldelight.Transacter
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.pentabitlabs.pentabitads.platform.db.pentabitplatform.newInstance
import com.pentabitlabs.pentabitads.platform.db.pentabitplatform.schema
import kotlin.Unit

public interface PentabitDatabase : Transacter {
  public val pentabitQueries: PentabitQueries

  public companion object {
    public val Schema: SqlSchema<QueryResult.Value<Unit>>
      get() = PentabitDatabase::class.schema

    public operator fun invoke(driver: SqlDriver): PentabitDatabase =
        PentabitDatabase::class.newInstance(driver)
  }
}
