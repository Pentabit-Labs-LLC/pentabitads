package com.pentabitlabs.pentabitads.platform

import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.PowerManager
import android.util.Log
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.driver.android.AndroidSqliteDriver
import com.google.android.gms.ads.identifier.AdvertisingIdClient
import com.pentabitlabs.pentabitads.core.ports.ConnectivityMonitor
import com.pentabitlabs.pentabitads.core.ports.DeviceInfo
import com.pentabitlabs.pentabitads.core.ports.IdGenerator
import com.pentabitlabs.pentabitads.core.ports.KeyValueStore
import com.pentabitlabs.pentabitads.core.ports.Logger
import com.pentabitlabs.pentabitads.platform.db.PentabitDatabase
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

public actual class PlatformContext(public val applicationContext: Context)

internal actual fun currentTimeMillis(): Long = System.currentTimeMillis()

internal actual fun createHttpClient(): HttpClient = HttpClient(OkHttp) { pentabitDefaults() }

internal actual fun createSqlDriver(context: PlatformContext, name: String): SqlDriver {
    val ctx = context.applicationContext
    return try {
        AndroidSqliteDriver(PentabitDatabase.Schema, ctx, name)
    } catch (e: Throwable) {
        // A corrupt database file is deleted and recreated once.
        ctx.deleteDatabase(name)
        AndroidSqliteDriver(PentabitDatabase.Schema, ctx, name)
    }
}

internal actual fun cacheDirectory(context: PlatformContext): String = context.applicationContext.cacheDir.absolutePath

internal actual fun createLogger(debug: Boolean): Logger = object : Logger {
    override fun debug(tag: String, message: String) { if (debug) Log.d(tag, message) }
    override fun warn(tag: String, message: String, error: Throwable?) { Log.w(tag, message, error) }
    override fun error(tag: String, message: String, error: Throwable?) { Log.e(tag, message, error) }
}

internal actual fun createConnectivityMonitor(context: PlatformContext): ConnectivityMonitor {
    val cm = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    return object : ConnectivityMonitor {
        override fun isOnline(): Boolean = try {
            val network = cm?.activeNetwork
            val caps = if (network != null) cm?.getNetworkCapabilities(network) else null
            // If the state cannot be read, assume online and let the request itself fail.
            if (cm == null) true else caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        } catch (e: SecurityException) {
            true
        }
    }
}

internal actual fun createDeviceInfo(context: PlatformContext, store: KeyValueStore, ids: IdGenerator): DeviceInfo =
    AndroidDeviceInfo(context.applicationContext, store, ids)

private class AndroidDeviceInfo(
    private val ctx: Context,
    private val store: KeyValueStore,
    private val ids: IdGenerator,
) : DeviceInfo {
    override val platform: String = "android"
    override val osVersion: String = Build.VERSION.RELEASE ?: Build.VERSION.SDK_INT.toString()
    override val deviceClass: String =
        if (ctx.resources.configuration.smallestScreenWidthDp >= 600) "tablet" else "phone"
    override val appId: String = ctx.packageName
    override val appVersion: String = try {
        @Suppress("DEPRECATION")
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "0"
    } catch (e: PackageManager.NameNotFoundException) {
        "0"
    }
    override val country: String? = Locale.getDefault().country.takeIf { it.isNotBlank() }
    override val language: String? = Locale.getDefault().language.takeIf { it.isNotBlank() }
    override val isLowPowerMode: Boolean
        get() = (ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager)?.isPowerSaveMode == true

    /** Null when the permission is missing, the user opted out, or the ID is zeroed. */
    override suspend fun advertisingId(): String? = withContext(Dispatchers.IO) {
        try {
            val info = AdvertisingIdClient.getAdvertisingIdInfo(ctx)
            val id = info.id
            if (info.isLimitAdTrackingEnabled || id.isNullOrBlank() || id.all { it == '0' || it == '-' }) null else id
        } catch (e: Throwable) {
            null
        }
    }

    @android.annotation.SuppressLint("HardwareIds")
    override suspend fun deviceId(): String? =
        android.provider.Settings.Secure.getString(ctx.contentResolver, android.provider.Settings.Secure.ANDROID_ID)?.takeIf { it.isNotBlank() }

    override suspend fun appInstanceId(): String {
        store.getString(KEY)?.let { return it }
        val id = ids.newId()
        store.putString(KEY, id)
        return id
    }

    private companion object { const val KEY = "aks.instance_id" }
}

