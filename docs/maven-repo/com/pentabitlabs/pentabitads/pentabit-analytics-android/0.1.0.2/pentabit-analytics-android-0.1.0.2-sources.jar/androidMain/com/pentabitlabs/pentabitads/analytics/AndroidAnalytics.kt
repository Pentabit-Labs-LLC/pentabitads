package com.pentabitlabs.pentabitads.analytics

import android.content.Context
import com.android.installreferrer.api.InstallReferrerClient
import com.android.installreferrer.api.InstallReferrerStateListener
import com.pentabitlabs.pentabitads.platform.PlatformContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** Android convenience: `PentabitAnalytics.initialize(applicationContext, options)`. */
public fun PentabitAnalytics.initialize(context: Context, options: AnalyticsOptions) {
    initialize(PlatformContext(context.applicationContext), options)
}

internal actual fun createInstallSource(context: PlatformContext): InstallSource = object : InstallSource {
    override suspend fun referrer(): String? = suspendCancellableCoroutine { cont ->
        val client = try {
            InstallReferrerClient.newBuilder(context.applicationContext).build()
        } catch (e: Exception) {
            cont.resume(null)
            return@suspendCancellableCoroutine
        }
        cont.invokeOnCancellation { runCatching { client.endConnection() } }
        try {
            client.startConnection(object : InstallReferrerStateListener {
                override fun onInstallReferrerSetupFinished(responseCode: Int) {
                    val value = try {
                        if (responseCode == InstallReferrerClient.InstallReferrerResponse.OK) client.installReferrer.installReferrer else null
                    } catch (e: Exception) {
                        null
                    } finally {
                        runCatching { client.endConnection() }
                    }
                    if (cont.isActive) cont.resume(value)
                }

                override fun onInstallReferrerServiceDisconnected() {
                    if (cont.isActive) cont.resume(null)
                }
            })
        } catch (e: Exception) {
            if (cont.isActive) cont.resume(null) // for example SecurityException
        }
    }
}

internal actual fun createConversionValueSink(): ConversionValueSink = object : ConversionValueSink {
    override fun update(value: Int) {} // SKAdNetwork does not exist on Android
}
